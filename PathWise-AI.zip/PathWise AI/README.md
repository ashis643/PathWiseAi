# PathWise AI — Intelligent Course Recommendation & Academic Path Planning System

[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-009688.svg?style=flat&logo=fastapi)](https://fastapi.tiangolo.com)
[![React](https://img.shields.io/badge/React-19.0+-61DAFB.svg?style=flat&logo=react)](https://react.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-3178C6.svg?style=flat&logo=typescript)](https://www.typescriptlang.org)
[![MongoDB](https://img.shields.io/badge/MongoDB-8.0+-47A248.svg?style=flat&logo=mongodb)](https://www.mongodb.com)
[![TailwindCSS](https://img.shields.io/badge/TailwindCSS-3.4+-38B2AC.svg?style=flat&logo=tailwind-css)](https://tailwindcss.com)
[![Pytest](https://img.shields.io/badge/Pytest-8.0+-0A9EDC.svg?style=flat&logo=pytest)](https://pytest.org)

**PathWise AI** is an enterprise-grade academic path planning and course recommendation system built for university students. It solves curriculum discovery, prerequisite management, and career readiness through explainable content-based recommendation algorithms, topological roadmap planning, and real-time skill gap analysis.

---

## 🌟 The Five Core Modules

The system is organized around five modules:

### 1. Student Profile Management
- **Secure Authentication**: Salted bcrypt password hashing with signed HS256 JWT tokens and protected routing.
- **Academic Profiles**: Tracks degree program, department, semester (1–12), GPA/CGPA, self-reported technical and soft skills, interests, and study availability.
- **Guided Onboarding Wizard**: A 4-step progressive onboarding wizard with completion progress tracking.
- **Dynamic Recalculation**: Profile updates trigger real-time recalculation of recommendation scores, prerequisite eligibility, and roadmap timelines.

### 2. Course Management
- **Searchable Catalog**: Full-text and keyword search across title, course ID, category, and skills gained.
- **Multi-Parameter Filtering**: Filter across 12 university categories, 3 difficulty tiers (Beginner, Intermediate, Advanced), and duration constraints.
- **Prerequisite Dependency Engine**: Real-time evaluation of prerequisite readiness with visual status alerts.
- **40 Realistic Seed Courses**: Includes 40 courses with verified learning links, prerequisites, and learning objectives.
- **Role-Based Admin Catalog Tools**: Administrators can publish, update, and manage courses.

### 3. Intelligent Course Recommendation
- **Explainable Weighted Algorithm**: Configurable multi-dimensional normalized scoring:
  - **Career Goal Relevance**: 25%
  - **Target Skill Relevance**: 25%
  - **Interest Alignment (TF-IDF Cosine Similarity)**: 15%
  - **Skill Gap Fill Contribution**: 15%
  - **Prerequisite Progression Fit**: 10%
  - **Difficulty & Study-Time Feasibility**: 10%
- **Prerequisite Separation**: Courses with unmet prerequisites are separated into a dedicated "Prerequisite-Blocked" view detailing which prerequisite to complete first.
- **Completed Course Exclusion**: Completed courses are automatically excluded from new recommendations.
- **Transparent Score Breakdown**: Full mathematical factor breakdown and natural language explanations.

### 4. Academic Path Planning
- **Directed Acyclic Graph (DAG) Modeling**: Represents courses as nodes and prerequisites as directed edges.
- **Topological Sorting**: Uses Kahn's algorithm to resolve prerequisites into a sequential learning plan.
- **Circular Dependency Detection**: Safely catches and handles cyclical dependencies.
- **Four Sequential Progression Phases**:
  - *Phase 1*: Foundational & Computational Thinking
  - *Phase 2*: Core Data Structures, Systems & Databases
  - *Phase 3*: Domain Specialization & Core Technologies
  - *Phase 4*: Advanced Systems, Cloud Deployment & Capstone
- **Workload Estimation**: Estimates total study hours and weekly completion milestones based on available study hours.
- **Interactive Plan Customization**: Add, remove, and reorder courses with state persistence.

### 5. Skill Gap Analysis & Progress Tracking
- **Career Benchmark Standards**: Transparent competency models for:
  - AI/ML Engineer
  - Data Analyst
  - Software Engineer
  - Cloud/DevOps Engineer
  - Cybersecurity Analyst
- **Gap Prioritization**: Classifies competencies into Acquired, In Progress, and High/Medium/Low priority missing gaps.
- **Recharts Visualizations**: Interactive Radar Charts and comparative Bar Charts.
- **Progress Tracking**: Log daily/weekly study hours, update course statuses (Not Started, In Progress, Completed), and view activity history.

---

## 🛠️ Technology Stack

| Layer | Technologies |
| :--- | :--- |
| **Frontend** | React 19, TypeScript, Vite, Tailwind CSS, Lucide React, Recharts, React Router v7, Axios |
| **Backend** | Python 3.12, FastAPI, Pydantic v2, PyJWT, passlib/bcrypt, Uvicorn |
| **AI / ML** | scikit-learn, pandas, numpy, TF-IDF Vectorizer, Kahn's Topological Sort Algorithm |
| **Database** | MongoDB 8.0+, PyMongo (indexed collections: `users`, `student_profiles`, `courses`, `academic_roadmaps`, `progress_records`, `study_logs`) |
| **Testing** | pytest, httpx, Vitest, React Testing Library, jsdom |

---

## 📁 Repository Structure

```text
PathWise AI/
├── backend/
│   ├── app/
│   │   ├── main.py                  # FastAPI app entrypoint, CORS, and lifecycle
│   │   ├── core/
│   │   │   ├── config.py            # Environment settings and recommendation weights
│   │   │   └── security.py          # bcrypt password hashing and JWT token handling
│   │   ├── database/
│   │   │   └── connection.py        # PyMongo connection and index initialization
│   │   ├── schemas/                 # Pydantic schemas for request/response validation
│   │   ├── api/                     # Modular REST API endpoints
│   │   │   ├── auth.py              # Register, login, session
│   │   │   ├── profiles.py          # Student profile CRUD
│   │   │   ├── courses.py           # Catalog search, filter, and administration
│   │   │   ├── recommendations.py   # Explainable recommendation endpoints
│   │   │   ├── roadmaps.py          # Topological roadmap planner
│   │   │   ├── skill_gaps.py        # Career benchmarks and gap analysis
│   │   │   ├── progress.py          # Study logs and completion tracking
│   │   │   └── dashboard.py         # Consolidated dashboard overview
│   │   ├── services/                # Business logic and algorithms
│   │   └── tests/                   # Automated pytest and integration test suites
│   ├── scripts/
│   │   ├── seed_courses.py          # 40 seed courses across 12 categories
│   │   └── seed_users.py            # Demo student and administrator accounts
│   ├── requirements.txt             # Python dependencies
│   ├── pytest.ini                   # Pytest configuration
│   └── .env.example                 # Backend environment variable template
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── layout/              # Sidebar, Navbar, MainLayout
│   │   │   └── ui/                  # Reusable Button, Card, Badge, Modal, ProgressBar, Skeleton
│   │   ├── contexts/                # AuthContext, ThemeContext, ToastContext
│   │   ├── pages/                   # Dashboard, Courses, Recommendations, Roadmap, SkillGaps, Profile, Settings, Auth, Onboarding
│   │   ├── services/api.ts          # Typed Axios client with interceptors
│   │   ├── types/index.ts           # TypeScript domain definitions
│   │   ├── utils/cn.ts              # Tailwind class merging utility
│   │   ├── App.tsx                  # Root application router
│   │   ├── main.tsx                 # React DOM mount point
│   │   └── index.css                # Base typography and design tokens
│   ├── package.json                 # Frontend npm package configuration
│   ├── vite.config.ts               # Vite configuration with API proxy and path aliases
│   ├── tailwind.config.js           # Indigo/blue theme colors and dark mode tokens
│   └── vitest.config.ts             # Frontend unit test configuration
├── .gitignore
├── .env.example
└── README.md
```

---

## 🚀 Quick Start Guide (Windows)

### Prerequisites
- **Python 3.12+** (Installed and available on PATH)
- **Node.js 18+ & npm** (Installed and available on PATH)
- **MongoDB** (Running locally on `mongodb://localhost:27017`)

---

### Step 1: Backend Setup

Open PowerShell and navigate to the project root:

```powershell
cd "c:\Users\bamad\OneDrive\Desktop\PathWise AI"

# Create a Python 3.12 virtual environment
py -3.12 -m venv backend/venv

# Install backend dependencies
backend\venv\Scripts\python -m pip install -r backend\requirements.txt

# Populate MongoDB with 40 realistic seed courses and demo accounts
cd backend
..\backend\venv\Scripts\python scripts\seed_courses.py
..\backend\venv\Scripts\python scripts\seed_users.py
cd ..
```

---

### Step 2: Frontend Setup

In a new terminal window:

```powershell
cd "c:\Users\bamad\OneDrive\Desktop\PathWise AI\frontend"

# Install npm dependencies
npm install

# Verify production build
npm run build
```

---

### Step 3: Run the Servers

#### Terminal 1 — Start Backend Server:
```powershell
cd "c:\Users\bamad\OneDrive\Desktop\PathWise AI\backend"
..\backend\venv\Scripts\uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```
*Backend API will be running at:* `http://127.0.0.1:8000`  
*Interactive Swagger API Docs:* `http://127.0.0.1:8000/docs`

#### Terminal 2 — Start Frontend Application:
```powershell
cd "c:\Users\bamad\OneDrive\Desktop\PathWise AI\frontend"
npm run dev
```
*Frontend Application will be running at:* `http://127.0.0.1:5173`

---

## 🔑 Demo Credentials

| Role | Email | Password |
| :--- | :--- | :--- |
| **Demo Student** | `student@pathwise.ai` | `StudentPass123!` |
| **Administrator** | `admin@pathwise.ai` | `AdminPass123!` |

*(The sign-in page also includes one-click demo login buttons for quick access.)*

---

## 🧪 Running Automated Tests

### 1. Backend & Integration Tests
```powershell
cd "c:\Users\bamad\OneDrive\Desktop\PathWise AI\backend"
..\backend\venv\Scripts\pytest -v
```
**Test Coverage Includes:**
- Bcrypt password hashing & JWT token verification (`test_auth.py`)
- Completed-course exclusion from recommendations (`test_recommendation.py`)
- Prerequisite filtering and blocked course separation (`test_recommendation.py`)
- Weighted relevance scoring & natural language explanation generation (`test_recommendation.py`)
- Directed graph topological sort algorithm (`test_roadmap.py`)
- Circular dependency cycle detection (`test_roadmap.py`)
- Career benchmark profile validation (`test_skill_gap.py`)
- Skill gap percentage calculations (`test_skill_gap.py`)
- Full student end-to-end journey integration test (`test_e2e_integration.py`)

### 2. Frontend Unit Tests
```powershell
cd "c:\Users\bamad\OneDrive\Desktop\PathWise AI\frontend"
npm test
```
**Test Coverage Includes:**
- Button states, variants, loading spinners, and click handlers
- Progress bar value clamping and label rendering

---

## 📊 Database Collections & Indexes

The MongoDB database (`pathwise_ai`) uses indexes to ensure data integrity and query efficiency:

- `users`: Unique index on `email`
- `student_profiles`: Unique index on `user_id`, index on `email`
- `courses`: Unique index on `course_id`, indexes on `category`, `difficulty_level`, `is_active`
- `academic_roadmaps`: Unique index on `user_id`
- `progress_records`: Compound unique index on `(user_id, course_id)`
- `study_logs`: Index on `(user_id, created_at)`

---

## 📝 License & Academic Acknowledgement

Built as a college project demonstrating full-stack engineering, applied machine learning recommendation techniques, and educational UX design principles.
