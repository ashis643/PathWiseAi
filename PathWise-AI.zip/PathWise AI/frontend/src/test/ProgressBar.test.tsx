import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { ProgressBar } from '../components/ui/ProgressBar';

describe('ProgressBar component', () => {
  it('renders label and calculates percentage accurately', () => {
    render(<ProgressBar value={75} max={100} label="Curriculum Progress" />);
    expect(screen.getByText('Curriculum Progress')).toBeInTheDocument();
    expect(screen.getByText('75%')).toBeInTheDocument();
  });

  it('clamps percentage within 0 and 100', () => {
    render(<ProgressBar value={150} max={100} />);
    expect(screen.getByText('100%')).toBeInTheDocument();
  });
});
