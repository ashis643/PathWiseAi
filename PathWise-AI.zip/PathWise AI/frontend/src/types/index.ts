export type DifficultyLevel = 'Beginner' | 'Intermediate' | 'Advanced';
export type CourseStatus = 'not_started' | 'in_progress' | 'completed' | 'blocked';
export type LearningPace = 'Relaxed' | 'Balanced' | 'Intensive';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'student' | 'admin';
  created_at?: string;
}

export interface StudentProfile {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  university: string;
  degree_program: string;
  department: string;
  current_semester: number;
  current_cgpa?: number | null;
  technical_skills: string[];
  soft_skills: string[];
  areas_of_interest: string[];
  completed_courses: string[];
  target_career: string;
  target_skills: string[];
  preferred_difficulty: DifficultyLevel;
  available_study_hours_per_week: number;
  preferred_learning_pace: LearningPace;
  is_onboarding_completed: boolean;
  completion_percentage: number;
  created_at?: string;
  updated_at?: string;
}

export interface Course {
  id: string;
  course_id: string;
  title: string;
  short_description: string;
  category: string;
  difficulty_level: DifficultyLevel;
  estimated_duration_hours: number;
  prerequisite_course_ids: string[];
  prerequisites_detail?: {
    course_id: string;
    title: string;
    difficulty_level: string;
    duration_hours: number;
  }[];
  required_skills: string[];
  skills_gained: string[];
  career_relevance: string[];
  learning_objectives: string[];
  course_type: string;
  learning_resource_url?: string;
  is_active: boolean;
  user_status?: CourseStatus;
}

export interface ScoreBreakdown {
  career_goal_fit: number;
  target_skill_fit: number;
  interest_fit: number;
  skill_gap_fit: number;
  progression_fit: number;
  difficulty_study_fit: number;
}

export interface RecommendedCourseItem {
  course_id: string;
  title: string;
  category: string;
  difficulty_level: DifficultyLevel;
  estimated_duration_hours: number;
  recommendation_score: number;
  score_breakdown: ScoreBreakdown;
  skills_gained: string[];
  career_relevance: string[];
  prerequisites: string[];
  is_prerequisite_met: boolean;
  missing_prerequisites: string[];
  explanation: string;
  course_type: string;
  learning_resource_url?: string;
  user_status: CourseStatus;
}

export interface RecommendationResponse {
  student_career_goal: string;
  profile_completion_percentage: number;
  weights_used: Record<string, number>;
  total_eligible: number;
  top_recommendations: RecommendedCourseItem[];
  prerequisite_blocked_courses: RecommendedCourseItem[];
  insufficient_profile_notice?: string;
}

export interface RoadmapCourse {
  course_id: string;
  title: string;
  category: string;
  duration_hours: number;
  difficulty_level: DifficultyLevel;
  prerequisites: string[];
  status: CourseStatus;
  order_index: number;
  blocked_by: string[];
  rationale: string;
  skills_gained: string[];
  learning_resource_url?: string;
}

export interface RoadmapPhase {
  phase_number: number;
  title: string;
  description: string;
  milestone: string;
  estimated_duration_weeks: number;
  total_hours: number;
  courses: RoadmapCourse[];
}

export interface AcademicRoadmap {
  id?: string;
  user_id: string;
  career_goal: string;
  weekly_hours: number;
  total_hours: number;
  estimated_weeks: number;
  phases: RoadmapPhase[];
  generated_at?: string;
  updated_at?: string;
}

export interface SkillGapItem {
  skill_name: string;
  priority: 'High' | 'Medium' | 'Low';
  current_status: 'acquired' | 'developing' | 'missing';
  target_proficiency: string;
  is_missing: boolean;
  importance_weight: number;
  related_course_ids: string[];
  related_courses: {
    course_id: string;
    title: string;
    difficulty: string;
    duration_hours: string;
  }[];
}

export interface SkillGapAnalysis {
  career_goal: string;
  overall_readiness_percentage: number;
  skill_coverage_percentage: number;
  total_required_skills: number;
  acquired_skills_count: number;
  missing_skills_count: number;
  existing_skills: string[];
  missing_skills: string[];
  skills_to_improve: string[];
  skill_gaps: SkillGapItem[];
  top_gap_closing_courses: {
    course_id: string;
    title: string;
    skills_gained: string;
    difficulty: string;
    gap_impact: string;
  }[];
  methodology_note: string;
}

export interface StudyLog {
  id: string;
  user_id: string;
  course_id: string;
  course_title?: string;
  hours: number;
  notes: string;
  study_date: string;
  created_at?: string;
}

export interface ProgressSummary {
  total_enrolled: number;
  completed_count: number;
  in_progress_count: number;
  not_started_count: number;
  total_hours_logged: number;
  weekly_goal_hours: number;
  current_week_hours: number;
  roadmap_completion_percentage: number;
  recent_logs: StudyLog[];
}

export interface DashboardOverview {
  user: {
    id: string;
    full_name: string;
    email: string;
    target_career: string;
    university?: string;
    current_semester?: number;
  };
  profile_completion: number;
  is_onboarding_completed: boolean;
  progress: ProgressSummary;
  current_phase?: {
    phase_number: number;
    title: string;
    milestone: string;
    total_hours: number;
    estimated_weeks: number;
    courses_count: number;
    completed_count: number;
  };
  skill_metrics: {
    career_readiness: number;
    skill_coverage: number;
    missing_high_priority: string[];
    top_skills_acquired: string[];
  };
  top_recommendations: RecommendedCourseItem[];
  prerequisite_alerts: number;
  weekly_hours_logged: number;
  weekly_hours_target: number;
}
