import axios from 'axios';
import type {
  User,
  StudentProfile,
  Course,
  RecommendationResponse,
  AcademicRoadmap,
  SkillGapAnalysis,
  ProgressSummary,
  DashboardOverview,
  CourseStatus,
} from '../types';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Attach JWT access token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('pathwise_token');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Intercept 401 session expiration
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      const isAuthRoute = error.config?.url?.includes('/auth/login') || error.config?.url?.includes('/auth/register');
      if (!isAuthRoute) {
        localStorage.removeItem('pathwise_token');
        localStorage.removeItem('pathwise_user');
        if (window.location.pathname !== '/login') {
          window.location.href = '/login';
        }
      }
    }
    return Promise.reject(error);
  }
);

export const authApi = {
  register: (data: { email: string; password: string; full_name: string; role?: string }) =>
    api.post<{ access_token: string; token_type: string; user: User }>('/auth/register', data),
  login: (data: { email: string; password: string }) =>
    api.post<{ access_token: string; token_type: string; user: User }>('/auth/login', data),
  getMe: () => api.get<User>('/auth/me'),
};

export const profileApi = {
  getProfile: () => api.get<StudentProfile>('/profiles/me'),
  updateProfile: (data: Partial<StudentProfile>) => api.put<StudentProfile>('/profiles/me', data),
};

export const coursesApi = {
  getCourses: (params?: {
    search?: string;
    category?: string;
    difficulty?: string;
    max_duration?: number;
    sort_by?: string;
    page?: number;
    page_size?: number;
  }) =>
    api.get<{
      courses: Course[];
      total_count: number;
      page: number;
      page_size: number;
      total_pages: number;
    }>('/courses', { params }),
  getCourse: (courseId: string) => api.get<Course>(`/courses/${courseId}`),
  createCourse: (data: Partial<Course>) => api.post<Course>('/courses', data),
  updateCourse: (courseId: string, data: Partial<Course>) => api.put<Course>(`/courses/${courseId}`, data),
};

export const recommendationsApi = {
  getRecommendations: (limit = 10) =>
    api.get<RecommendationResponse>('/recommendations', { params: { limit } }),
};

export const roadmapApi = {
  getRoadmap: () => api.get<AcademicRoadmap>('/roadmaps'),
  regenerateRoadmap: () => api.post<AcademicRoadmap>('/roadmaps/generate'),
  modifyRoadmap: (data: { action: 'add' | 'remove' | 'reset'; course_id?: string; target_phase?: number }) =>
    api.post<AcademicRoadmap>('/roadmaps/modify', data),
};

export const skillGapApi = {
  getSkillGapAnalysis: (careerOverride?: string) =>
    api.get<SkillGapAnalysis>('/skill-gaps', { params: { career_override: careerOverride } }),
  getCareerProfiles: () =>
    api.get<
      {
        title: string;
        description: string;
        skills: { name: string; priority: string; target_level: string; weight: number }[];
      }[]
    >('/skill-gaps/careers'),
};

export const progressApi = {
  getProgressSummary: () => api.get<ProgressSummary>('/progress/summary'),
  updateCourseStatus: (data: { course_id: string; status: CourseStatus; hours_spent?: number; notes?: string }) =>
    api.post('/progress/status', data),
  logStudyHours: (data: { course_id: string; hours: number; notes?: string; study_date?: string }) =>
    api.post('/progress/log-hours', data),
};

export const dashboardApi = {
  getOverview: () => api.get<DashboardOverview>('/dashboard/overview'),
};

export default api;
