import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Menu,
  Sun,
  Moon,
  Search,
  Sparkles,
  ArrowRight,
  User as UserIcon,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { Button } from '../ui/Button';

interface NavbarProps {
  onMenuClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onMenuClick }) => {
  const { user, profile } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/courses?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const showOnboardingReminder = profile && !profile.is_onboarding_completed;

  return (
    <header className="sticky top-0 z-20 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 transition-colors">
      {/* Optional Top Warning / Onboarding Reminder Banner */}
      {showOnboardingReminder && (
        <div className="bg-gradient-to-r from-brand-600 to-indigo-600 text-white px-4 py-2 text-xs flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2 max-w-2xl truncate">
            <Sparkles className="w-3.5 h-3.5 shrink-0 animate-pulse" />
            <span className="font-medium truncate">
              Complete your profile onboarding to unlock 100% precision AI recommendations.
            </span>
          </div>
          <Link
            to="/onboarding"
            className="flex items-center gap-1 font-semibold underline underline-offset-2 hover:opacity-90 ml-2 shrink-0"
          >
            Start Setup <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      )}

      <div className="h-16 px-4 sm:px-6 flex items-center justify-between gap-4">
        {/* Left: Mobile hamburger & search */}
        <div className="flex items-center gap-3 flex-1 max-w-md">
          <button
            onClick={onMenuClick}
            className="md:hidden p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Quick Global Search Bar */}
          <form onSubmit={handleSearchSubmit} className="relative w-full hidden sm:block">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search courses, skills, or prerequisites..."
              className="w-full pl-9 pr-4 py-1.5 text-xs rounded-xl bg-slate-100/80 dark:bg-slate-800/60 border border-transparent focus:border-brand-500/50 focus:bg-white dark:focus:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 transition-all"
            />
          </form>
        </div>

        {/* Right: Actions, Theme Toggle, Profile Menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Academic Roadmap CTA */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/roadmap')}
            className="hidden sm:inline-flex text-xs h-9"
          >
            Roadmap
          </Button>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
            aria-label="Toggle theme"
          >
            {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-amber-400" />}
          </button>

          {/* User profile avatar badge */}
          {user && (
            <Link
              to="/profile"
              className="flex items-center gap-2 p-1.5 sm:px-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-700 dark:text-slate-200"
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-brand-600 to-indigo-500 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-sm">
                {user.full_name?.charAt(0) || 'U'}
              </div>
              <span className="hidden lg:inline text-xs font-semibold max-w-[120px] truncate">
                {user.full_name}
              </span>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};
