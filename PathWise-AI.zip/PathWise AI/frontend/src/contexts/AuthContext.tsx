import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User, StudentProfile } from '../types';
import { authApi, profileApi } from '../services/api';
import { useToast } from './ToastContext';

interface AuthContextType {
  user: User | null;
  profile: StudentProfile | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, fullName: string) => Promise<boolean>;
  logout: () => void;
  refreshProfile: () => Promise<void>;
  updateProfile: (data: Partial<StudentProfile>) => Promise<StudentProfile | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('pathwise_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('pathwise_token'));
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const { success, error } = useToast();

  const refreshProfile = async () => {
    if (!token) {
      setProfile(null);
      return;
    }
    try {
      const res = await profileApi.getProfile();
      setProfile(res.data);
    } catch (err) {
      console.error('Failed to load student profile', err);
    }
  };

  useEffect(() => {
    const initAuth = async () => {
      if (token) {
        try {
          const userRes = await authApi.getMe();
          setUser(userRes.data);
          localStorage.setItem('pathwise_user', JSON.stringify(userRes.data));
          await refreshProfile();
        } catch (err) {
          console.error('Auth verification failed', err);
          logout();
        }
      }
      setIsLoading(false);
    };
    initAuth();
  }, [token]);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const res = await authApi.login({ email, password });
      const { access_token, user: loggedUser } = res.data;
      localStorage.setItem('pathwise_token', access_token);
      localStorage.setItem('pathwise_user', JSON.stringify(loggedUser));
      setToken(access_token);
      setUser(loggedUser);
      await refreshProfile();
      success('Welcome back!', `Logged in as ${loggedUser.full_name}`);
      return true;
    } catch (err: any) {
      const msg = err.response?.data?.detail || 'Invalid email or password.';
      error('Login Failed', msg);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (email: string, password: string, fullName: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const res = await authApi.register({ email, password, full_name: fullName });
      const { access_token, user: newUser } = res.data;
      localStorage.setItem('pathwise_token', access_token);
      localStorage.setItem('pathwise_user', JSON.stringify(newUser));
      setToken(access_token);
      setUser(newUser);
      await refreshProfile();
      success('Account Created!', 'Welcome to PathWise AI.');
      return true;
    } catch (err: any) {
      const msg = err.response?.data?.detail || 'Registration failed. Please try again.';
      error('Registration Failed', msg);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('pathwise_token');
    localStorage.removeItem('pathwise_user');
    setToken(null);
    setUser(null);
    setProfile(null);
    success('Logged Out', 'You have been safely signed out.');
  };

  const updateProfile = async (data: Partial<StudentProfile>): Promise<StudentProfile | null> => {
    try {
      const res = await profileApi.updateProfile(data);
      setProfile(res.data);
      success('Profile Updated', 'Your profile and recommendations have been refreshed.');
      return res.data;
    } catch (err: any) {
      const msg = err.response?.data?.detail || 'Failed to update profile.';
      error('Update Error', msg);
      return null;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        token,
        isLoading,
        login,
        register,
        logout,
        refreshProfile,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
