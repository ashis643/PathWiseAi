import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Sparkles,
  Target,
  BookOpen,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Info,
  ChevronDown,
  ChevronUp,
  Plus,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { recommendationsApi, roadmapApi } from '../services/api';
import type { RecommendationResponse, RecommendedCourseItem } from '../types';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Skeleton } from '../components/ui/Skeleton';
import { Modal } from '../components/ui/Modal';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

export const RecommendationsPage: React.FC = () => {
  const { profile } = useAuth();
  const { success, error } = useToast();

  const [data, setData] = useState<RecommendationResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'eligible' | 'blocked'>('eligible');
  const [expandedCourseId, setExpandedCourseId] = useState<string | null>(null);
  const [addingRoadmapId, setAddingRoadmapId] = useState<string | null>(null);

  const fetchRecommendations = async () => {
    setIsLoading(true);
    try {
      const res = await recommendationsApi.getRecommendations(15);
      setData(res.data);
    } catch (err) {
      console.error('Failed to load recommendations', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRecommendations();
  }, [profile]);

  const handleAddToRoadmap = async (courseId: string) => {
    setAddingRoadmapId(courseId);
    try {
      await roadmapApi.modifyRoadmap({
        action: 'add',
        course_id: courseId,
        target_phase: 2,
      });
      success('Added to Roadmap', `Course ${courseId} has been added to your study plan.`);
    } catch (err: any) {
      error('Failed', err.response?.data?.detail || 'Could not add course to roadmap.');
    } finally {
      setAddingRoadmapId(null);
    }
  };

  const toggleExpand = (courseId: string) => {
    setExpandedCourseId(expandedCourseId === courseId ? null : courseId);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-28 w-full" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-6">
      {/* Header Banner with Algorithm Transparency */}
      <div className="rounded-3xl bg-gradient-to-r from-brand-900 via-indigo-900 to-slate-900 text-white p-6 sm:p-8 border border-brand-800/40 shadow-lg">
        <div className="max-w-3xl">
          <Badge variant="brand" className="mb-3 text-[11px] font-bold">
            Content-Based Explainable Algorithm
          </Badge>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold tracking-tight">
            Intelligent Course Recommendations
          </h1>
          <p className="mt-1.5 text-xs sm:text-sm text-indigo-200/90 leading-relaxed">
            Personalized for your target career in{' '}
            <span className="font-bold text-white underline decoration-brand-400">
              {data.student_career_goal}
            </span>
            . Recommendations exclude already completed coursework and strictly differentiate courses ready for immediate study from prerequisite-blocked courses.
          </p>

          {/* Configurable Formula Pill Bar */}
          <div className="mt-5 pt-4 border-t border-white/10 flex flex-wrap items-center gap-2 text-[11px] font-semibold text-indigo-200">
            <span className="text-white font-bold">Algorithm Weights:</span>
            <span className="px-2 py-0.5 rounded-md bg-white/10">Career Relevance: 25%</span>
            <span className="px-2 py-0.5 rounded-md bg-white/10">Target Skills: 25%</span>
            <span className="px-2 py-0.5 rounded-md bg-white/10">Interest Alignment: 15%</span>
            <span className="px-2 py-0.5 rounded-md bg-white/10">Skill Gap: 15%</span>
            <span className="px-2 py-0.5 rounded-md bg-white/10">Progression Fit: 10%</span>
            <span className="px-2 py-0.5 rounded-md bg-white/10">Study Feasibility: 10%</span>
          </div>
        </div>
      </div>

      {/* Sparse Profile Notice */}
      {data.insufficient_profile_notice && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs">
            <span className="font-bold text-amber-900 dark:text-amber-200">
              Notice on Recommendation Precision:
            </span>
            <p className="text-amber-800 dark:text-amber-300 mt-1 leading-relaxed">
              {data.insufficient_profile_notice}
            </p>
            <Link to="/profile" className="inline-block mt-2 font-bold underline hover:opacity-80">
              Complete Profile Now →
            </Link>
          </div>
        </div>
      )}

      {/* Tab Switcher: Immediately Eligible vs Prerequisite Blocked */}
      <div className="flex rounded-2xl bg-white dark:bg-slate-900 p-1.5 border border-slate-200/80 dark:border-slate-800 max-w-md shadow-sm">
        <button
          type="button"
          onClick={() => setActiveTab('eligible')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
            activeTab === 'eligible'
              ? 'bg-brand-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          Immediately Available ({data.top_recommendations.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('blocked')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
            activeTab === 'blocked'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          Prerequisite-Blocked ({data.prerequisite_blocked_courses.length})
        </button>
      </div>

      {/* Course Cards List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {(activeTab === 'eligible'
          ? data.top_recommendations
          : data.prerequisite_blocked_courses
        ).map((course) => {
          const isExpanded = expandedCourseId === course.course_id;

          return (
            <Card
              key={course.course_id}
              className="p-5 flex flex-col justify-between border-slate-200/80 dark:border-slate-800"
            >
              <div>
                {/* Top Row: Score Badge, Category, Duration */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-950/60 px-2 py-0.5 rounded-md">
                      {course.course_id}
                    </span>
                    <Badge
                      variant={
                        course.difficulty_level === 'Beginner'
                          ? 'success'
                          : course.difficulty_level === 'Intermediate'
                          ? 'brand'
                          : 'danger'
                      }
                      size="sm"
                    >
                      {course.difficulty_level}
                    </Badge>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {course.recommendation_score}% Match
                    </span>
                    <div className="w-16 bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-brand-600 h-full rounded-full"
                        style={{ width: `${course.recommendation_score}%` }}
                      />
                    </div>
                  </div>
                </div>

                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-snug">
                  {course.title}
                </h3>
                <p className="text-xs text-slate-400 font-medium">{course.category}</p>

                {/* Natural Language Explanation Banner */}
                <div className="mt-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-850/80 border border-slate-200/70 dark:border-slate-800 text-xs">
                  <span className="font-semibold text-brand-600 dark:text-brand-400 block mb-0.5">
                    Why Recommended:
                  </span>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {course.explanation}
                  </p>
                </div>

                {/* Blocked Alert if applicable */}
                {!course.is_prerequisite_met && (
                  <div className="mt-2.5 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/80 flex items-start gap-2 text-xs">
                    <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
                    <div className="text-rose-900 dark:text-rose-200">
                      <span className="font-bold">Missing Prerequisites: </span>
                      {course.missing_prerequisites.join(', ')}. Complete these prerequisite courses
                      first before enrolling.
                    </div>
                  </div>
                )}

                {/* Skills Gained Tags */}
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {course.skills_gained.map((sk) => (
                    <Badge key={sk} variant="neutral" size="sm">
                      +{sk}
                    </Badge>
                  ))}
                </div>

                {/* Detailed Score Breakdown Accordion */}
                {isExpanded && (
                  <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800 space-y-2 text-xs animate-fade-in">
                    <span className="font-bold text-slate-900 dark:text-white block mb-1">
                      Weighted Scoring Breakdown:
                    </span>
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div>
                        <span className="text-slate-500">Career Goal Fit (25%):</span>
                        <ProgressBar value={course.score_breakdown.career_goal_fit} size="sm" />
                      </div>
                      <div>
                        <span className="text-slate-500">Target Skills Fit (25%):</span>
                        <ProgressBar value={course.score_breakdown.target_skill_fit} size="sm" />
                      </div>
                      <div>
                        <span className="text-slate-500">Interest Alignment (15%):</span>
                        <ProgressBar value={course.score_breakdown.interest_fit} size="sm" />
                      </div>
                      <div>
                        <span className="text-slate-500">Skill Gap Fill (15%):</span>
                        <ProgressBar value={course.score_breakdown.skill_gap_fit} size="sm" />
                      </div>
                      <div>
                        <span className="text-slate-500">Prereq Progression (10%):</span>
                        <ProgressBar value={course.score_breakdown.progression_fit} size="sm" />
                      </div>
                      <div>
                        <span className="text-slate-500">Study Feasibility (10%):</span>
                        <ProgressBar value={course.score_breakdown.difficulty_study_fit} size="sm" />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => toggleExpand(course.course_id)}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1"
                >
                  {isExpanded ? (
                    <>
                      Hide Breakdown <ChevronUp className="w-3.5 h-3.5" />
                    </>
                  ) : (
                    <>
                      Score Breakdown <ChevronDown className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>

                <div className="flex gap-2">
                  <Link to={`/courses`}>
                    <Button variant="outline" size="sm" className="text-xs">
                      Course Detail
                    </Button>
                  </Link>

                  <Button
                    variant="primary"
                    size="sm"
                    isLoading={addingRoadmapId === course.course_id}
                    onClick={() => handleAddToRoadmap(course.course_id)}
                    leftIcon={<Plus className="w-3.5 h-3.5" />}
                    className="text-xs"
                  >
                    Add to Roadmap
                  </Button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
