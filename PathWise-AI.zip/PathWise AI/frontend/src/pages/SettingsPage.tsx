import React, { useState, useEffect } from 'react';
import {
  Settings as SettingsIcon,
  Moon,
  Sun,
  Shield,
  Database,
  User,
  LogOut,
  RefreshCw,
  CheckCircle2,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import axios from 'axios';

export const SettingsPage: React.FC = () => {
  const { user, profile, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const [backendHealth, setBackendHealth] = useState<{
    status: string;
    database_connected: boolean;
    database_name: string;
  } | null>(null);

  useEffect(() => {
    axios
      .get('/api/health')
      .then((res) => setBackendHealth(res.data))
      .catch((err) => console.error('Health check failed', err));
  }, []);

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <SettingsIcon className="w-6 h-6 text-brand-600" /> System Settings
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Manage your account preferences, theme, and view system diagnostic information.
        </p>
      </div>

      {/* 1. Interface Theme */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            {theme === 'dark' ? <Moon className="w-5 h-5 text-indigo-400" /> : <Sun className="w-5 h-5 text-amber-500" />}
            Visual Theme & Appearance
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
              Active Mode: {theme === 'dark' ? 'Dark Mode' : 'Light Mode'}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              Toggle between comfortable dark contrast and crisp light mode.
            </p>
          </div>
          <Button variant="secondary" size="sm" onClick={toggleTheme}>
            Switch to {theme === 'dark' ? 'Light' : 'Dark'} Mode
          </Button>
        </CardContent>
      </Card>

      {/* 2. Account Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <User className="w-5 h-5 text-brand-600" /> Account Security & Credentials
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="text-slate-400 font-medium block">Account Name:</span>
              <span className="font-bold text-slate-900 dark:text-white">{user?.full_name}</span>
            </div>
            <div>
              <span className="text-slate-400 font-medium block">Registered Email:</span>
              <span className="font-bold text-slate-900 dark:text-white">{user?.email}</span>
            </div>
            <div>
              <span className="text-slate-400 font-medium block">Authorization Role:</span>
              <Badge variant={user?.role === 'admin' ? 'purple' : 'brand'}>{user?.role}</Badge>
            </div>
            <div>
              <span className="text-slate-400 font-medium block">Session Security:</span>
              <span className="text-emerald-600 font-semibold">JWT HS256 Authenticated</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 3. Database & System Status */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Database className="w-5 h-5 text-emerald-600" /> Infrastructure Diagnostics
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-xs">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div>
              <span className="text-slate-400 block font-medium">Backend API:</span>
              <span className="text-emerald-600 font-bold flex items-center gap-1 mt-0.5">
                <CheckCircle2 className="w-3.5 h-3.5" /> Online (FastAPI)
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">MongoDB Cluster:</span>
              <span className="text-emerald-600 font-bold flex items-center gap-1 mt-0.5">
                <CheckCircle2 className="w-3.5 h-3.5" />{' '}
                {backendHealth?.database_connected ? 'Connected' : 'Connecting'}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Active Database:</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5 block">
                {backendHealth?.database_name || 'pathwise_ai'}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sign Out Card */}
      <div className="pt-4 flex justify-end">
        <Button
          variant="danger"
          size="md"
          onClick={logout}
          leftIcon={<LogOut className="w-4 h-4" />}
        >
          Sign Out of PathWise AI
        </Button>
      </div>
    </div>
  );
};
