import React, { useEffect, useState } from 'react';
import {
  Map,
  Layers,
  Clock,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  PlayCircle,
  RefreshCw,
  Plus,
  Trash2,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { roadmapApi, progressApi } from '../services/api';
import type { AcademicRoadmap, RoadmapPhase, RoadmapCourse, CourseStatus } from '../types';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Skeleton } from '../components/ui/Skeleton';
import { Modal } from '../components/ui/Modal';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

export const RoadmapPage: React.FC = () => {
  const { profile, refreshProfile } = useAuth();
  const { success, error } = useToast();

  const [roadmap, setRoadmap] = useState<AcademicRoadmap | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRegenerating, setIsRegenerating] = useState(false);

  // Add course to roadmap modal
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [courseToAdd, setCourseToAdd] = useState('');
  const [phaseToAdd, setPhaseToAdd] = useState(2);
  const [isAdding, setIsAdding] = useState(false);

  const fetchRoadmap = async () => {
    setIsLoading(true);
    try {
      const res = await roadmapApi.getRoadmap();
      setRoadmap(res.data);
    } catch (err) {
      console.error('Failed to load roadmap', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRoadmap();
  }, []);

  const handleRegenerate = async () => {
    setIsRegenerating(true);
    try {
      const res = await roadmapApi.regenerateRoadmap();
      setRoadmap(res.data);
      success('Roadmap Regenerated', 'Your path has been re-sequenced to match your updated profile.');
    } catch (err: any) {
      error('Failed', err.response?.data?.detail || 'Could not regenerate roadmap.');
    } finally {
      setIsRegenerating(false);
    }
  };

  const handleRemoveCourse = async (courseId: string) => {
    try {
      const res = await roadmapApi.modifyRoadmap({
        action: 'remove',
        course_id: courseId,
      });
      setRoadmap(res.data);
      success('Course Removed', `Removed ${courseId} from your study plan.`);
    } catch (err: any) {
      error('Failed', err.response?.data?.detail || 'Could not remove course.');
    }
  };

  const handleAddCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseToAdd.trim()) return;
    setIsAdding(true);
    try {
      const res = await roadmapApi.modifyRoadmap({
        action: 'add',
        course_id: courseToAdd.trim().toUpperCase(),
        target_phase: phaseToAdd,
      });
      setRoadmap(res.data);
      success('Course Added', `Added ${courseToAdd.toUpperCase()} to Phase ${phaseToAdd}.`);
      setAddModalOpen(false);
      setCourseToAdd('');
    } catch (err: any) {
      error('Failed', err.response?.data?.detail || 'Could not add course.');
    } finally {
      setIsAdding(false);
    }
  };

  const handleStatusChange = async (courseId: string, status: CourseStatus) => {
    try {
      await progressApi.updateCourseStatus({ course_id: courseId, status });
      await refreshProfile();
      fetchRoadmap();
      success('Updated', `Marked ${courseId} as ${status.replace('_', ' ')}.`);
    } catch (err: any) {
      error('Error', err.response?.data?.detail || 'Failed to update course status.');
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!roadmap) return null;

  // Calculate completion metrics
  const allCourses = roadmap.phases.flatMap((p) => p.courses);
  const completedCourses = allCourses.filter((c) => c.status === 'completed');
  const overallProgress = allCourses.length > 0 ? Math.round((completedCourses.length / allCourses.length) * 100) : 0;

  // Calculate estimated finish date
  const finishDate = new Date();
  finishDate.setDate(finishDate.getDate() + roadmap.estimated_weeks * 7);

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-brand-800 via-indigo-900 to-slate-900 text-white border border-brand-800/40 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <Badge variant="brand" className="mb-2.5 text-[11px] font-bold">
              Topological Graph Planner
            </Badge>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold tracking-tight">
              Personalized Academic Roadmap
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-indigo-200/90 max-w-xl leading-relaxed">
              Logically sequenced curriculum for{' '}
              <span className="font-bold text-white underline decoration-amber-400">
                {roadmap.career_goal}
              </span>
              . Prerequisite dependencies are resolved to ensure you learn foundations first.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setAddModalOpen(true)}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Course
            </Button>
            <Button
              variant="primary"
              size="sm"
              isLoading={isRegenerating}
              onClick={handleRegenerate}
              leftIcon={<RefreshCw className="w-4 h-4" />}
            >
              Regenerate Plan
            </Button>
          </div>
        </div>

        {/* Timeline Metrics Ribbon */}
        <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <span className="text-indigo-300 block">Total Workload</span>
            <span className="text-base font-bold text-white mt-0.5 block">
              {roadmap.total_hours} Hours
            </span>
          </div>
          <div>
            <span className="text-indigo-300 block">Weekly Pace</span>
            <span className="text-base font-bold text-white mt-0.5 block">
              {roadmap.weekly_hours} hrs / week
            </span>
          </div>
          <div>
            <span className="text-indigo-300 block">Estimated Timeline</span>
            <span className="text-base font-bold text-white mt-0.5 block">
              ~{roadmap.estimated_weeks} Weeks
            </span>
          </div>
          <div>
            <span className="text-indigo-300 block">Target Completion</span>
            <span className="text-base font-bold text-white mt-0.5 block">
              {finishDate.toLocaleDateString(undefined, { month: 'short', year: 'numeric' })}
            </span>
          </div>
        </div>
      </div>

      {/* Vertical Phase Progression Sequence */}
      <div className="space-y-6">
        {roadmap.phases.map((phase) => {
          const phaseCompleted = phase.courses.filter((c) => c.status === 'completed').length;
          const phasePct = phase.courses.length > 0 ? Math.round((phaseCompleted / phase.courses.length) * 100) : 0;

          return (
            <Card key={phase.phase_number} className="overflow-hidden border-slate-200/90 dark:border-slate-800">
              {/* Phase Header */}
              <div className="p-5 sm:p-6 bg-slate-50/80 dark:bg-slate-850/80 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant="brand" size="md">
                      Phase {phase.phase_number}
                    </Badge>
                    <span className="text-xs text-slate-400 font-semibold">
                      ~{phase.estimated_duration_weeks} Weeks ({phase.total_hours} Hours)
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {phase.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed max-w-2xl">
                    <span className="font-semibold text-brand-600 dark:text-brand-400">Milestone: </span>
                    {phase.milestone}
                  </p>
                </div>

                <div className="w-full sm:w-48 shrink-0">
                  <ProgressBar
                    value={phasePct}
                    label={`${phaseCompleted} / ${phase.courses.length} Completed`}
                    size="sm"
                  />
                </div>
              </div>

              {/* Courses inside Phase */}
              <CardContent className="p-4 sm:p-6 space-y-3">
                {phase.courses.map((course, idx) => {
                  const isBlocked = course.status === 'blocked';
                  const isCompleted = course.status === 'completed';
                  const isInProgress = course.status === 'in_progress';

                  return (
                    <div
                      key={course.course_id}
                      className={`p-4 rounded-2xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                        isCompleted
                          ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60'
                          : isBlocked
                          ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800/60'
                          : isInProgress
                          ? 'bg-brand-50/40 dark:bg-brand-950/20 border-brand-200 dark:border-brand-800/60'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      {/* Left Course Information */}
                      <div className="space-y-1.5 flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-bold text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-950/60 px-2 py-0.5 rounded-md">
                            #{course.order_index} • {course.course_id}
                          </span>
                          <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {course.title}
                          </span>
                          <Badge
                            variant={
                              course.difficulty_level === 'Beginner'
                                ? 'success'
                                : course.difficulty_level === 'Intermediate'
                                ? 'brand'
                                : 'danger'
                            }
                            size="sm"
                          >
                            {course.difficulty_level}
                          </Badge>
                        </div>

                        <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                          <span className="font-semibold text-slate-700 dark:text-slate-300">
                            Sequencing Rationale:{' '}
                          </span>
                          {course.rationale}
                        </p>

                        {/* Blocked Warning */}
                        {isBlocked && (
                          <div className="flex items-center gap-1.5 text-[11px] text-rose-600 dark:text-rose-400 font-semibold mt-1">
                            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                            <span>Prerequisites pending: {course.blocked_by.join(', ')}</span>
                          </div>
                        )}

                        {/* Skills Gained */}
                        <div className="flex flex-wrap gap-1 pt-1">
                          {course.skills_gained.slice(0, 3).map((sk) => (
                            <Badge key={sk} variant="neutral" size="sm">
                              +{sk}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Right: Duration, Status Changer, and Delete */}
                      <div className="flex items-center justify-between md:justify-end gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100 dark:border-slate-800">
                        <span className="text-xs font-medium text-slate-500 flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" /> {course.duration_hours}h
                        </span>

                        {/* Status Dropdown */}
                        <select
                          value={course.status}
                          onChange={(e) => handleStatusChange(course.course_id, e.target.value as CourseStatus)}
                          className="text-xs px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-semibold focus:outline-none"
                        >
                          <option value="planned">Planned</option>
                          <option value="in_progress">In Progress</option>
                          <option value="completed">Completed</option>
                        </select>

                        <button
                          onClick={() => handleRemoveCourse(course.course_id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                          title="Remove from plan"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Modal to Add Course to Roadmap */}
      <Modal
        isOpen={addModalOpen}
        onClose={() => setAddModalOpen(false)}
        title="Add Course to Study Plan"
        description="Insert an active catalog course into a specific phase of your learning roadmap."
      >
        <form onSubmit={handleAddCourse} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Course Code / ID
            </label>
            <input
              type="text"
              required
              value={courseToAdd}
              onChange={(e) => setCourseToAdd(e.target.value)}
              placeholder="e.g. CS102 or DB202"
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Target Phase
            </label>
            <select
              value={phaseToAdd}
              onChange={(e) => setPhaseToAdd(Number(e.target.value))}
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 focus:outline-none"
            >
              {roadmap.phases.map((p) => (
                <option key={p.phase_number} value={p.phase_number}>
                  Phase {p.phase_number}: {p.title}
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" size="sm" onClick={() => setAddModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm" isLoading={isAdding}>
              Add to Plan
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
