import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  BookOpen,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Plus,
} from 'lucide-react';
import { coursesApi, progressApi } from '../services/api';
import type { Course, CourseStatus, DifficultyLevel } from '../types';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { Skeleton } from '../components/ui/Skeleton';
import { EmptyState } from '../components/ui/EmptyState';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

const CATEGORIES = [
  'All',
  'Programming Fundamentals',
  'Data Structures and Algorithms',
  'Database Management',
  'Artificial Intelligence',
  'Machine Learning',
  'Data Science and Analytics',
  'Web Development',
  'Cloud Computing',
  'DevOps',
  'Cybersecurity',
  'Mathematics for Computing',
  'Communication and Professional Skills',
];

export const CoursesPage: React.FC = () => {
  const { user, profile, refreshProfile } = useAuth();
  const { success, error } = useToast();

  const [courses, setCourses] = useState<Course[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [difficulty, setDifficulty] = useState('All');
  const [sortBy, setSortBy] = useState('relevance');

  // Selected Course Detail Modal
  const [activeCourse, setActiveCourse] = useState<Course | null>(null);
  const [updatingStatus, setUpdatingStatus] = useState(false);

  // Admin New Course Modal
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [newCourseId, setNewCourseId] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState('Programming Fundamentals');
  const [newDiff, setNewDiff] = useState<DifficultyLevel>('Beginner');
  const [newHours, setNewHours] = useState('30');
  const [newPrereqs, setNewPrereqs] = useState('');
  const [newSkills, setNewSkills] = useState('');
  const [isCreatingCourse, setIsCreatingCourse] = useState(false);

  const fetchCourses = async () => {
    setIsLoading(true);
    try {
      const res = await coursesApi.getCourses({
        search: search.trim() || undefined,
        category: selectedCategory === 'All' ? undefined : selectedCategory,
        difficulty: difficulty === 'All' ? undefined : difficulty,
        sort_by: sortBy,
        page,
        page_size: 12,
      });
      setCourses(res.data.courses);
      setTotalCount(res.data.total_count);
      setTotalPages(res.data.total_pages);
    } catch (err) {
      console.error('Failed to load courses', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, [page, selectedCategory, difficulty, sortBy]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchCourses();
  };

  const handleUpdateStatus = async (courseId: string, status: CourseStatus) => {
    setUpdatingStatus(true);
    try {
      await progressApi.updateCourseStatus({
        course_id: courseId,
        status,
      });
      success('Status Updated', `Course marked as ${status.replace('_', ' ')}.`);
      await refreshProfile();
      fetchCourses();
      if (activeCourse) {
        setActiveCourse({ ...activeCourse, user_status: status });
      }
    } catch (err: any) {
      error('Failed', err.response?.data?.detail || 'Could not update status.');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleCreateCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreatingCourse(true);
    try {
      await coursesApi.createCourse({
        course_id: newCourseId.trim().toUpperCase(),
        title: newTitle.trim(),
        short_description: newDesc.trim(),
        category: newCategory,
        difficulty_level: newDiff,
        estimated_duration_hours: parseInt(newHours, 10) || 30,
        prerequisite_course_ids: newPrereqs
          ? newPrereqs.split(',').map((p) => p.trim().toUpperCase())
          : [],
        skills_gained: newSkills ? newSkills.split(',').map((s) => s.trim()) : [],
        career_relevance: ['Software Engineer'],
        learning_objectives: ['Acquire core engineering competencies'],
        course_type: 'Core',
        is_active: true,
      });
      success('Course Added', `Course ${newCourseId} has been added to catalog.`);
      setAdminModalOpen(false);
      fetchCourses();
    } catch (err: any) {
      error('Error', err.response?.data?.detail || 'Failed to create course.');
    } finally {
      setIsCreatingCourse(false);
    }
  };

  const completedList = profile?.completed_courses || [];

  return (
    <div className="space-y-6">
      {/* Page Title & Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-brand-600" /> Explore Courses
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Browse our catalog of {totalCount} university-grade courses with verifiable prerequisite relationships.
          </p>
        </div>

        {user?.role === 'admin' && (
          <Button
            variant="primary"
            size="sm"
            onClick={() => setAdminModalOpen(true)}
            leftIcon={<Plus className="w-4 h-4" />}
          >
            Add New Course
          </Button>
        )}
      </div>

      {/* Search and Filter Toolbar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by title, description, code, or skill..."
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
            />
          </div>
          <Button type="submit" variant="primary" size="sm">
            Search
          </Button>
        </form>

        {/* Filter Controls Row */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-2">
            {/* Category Select */}
            <select
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                setPage(1);
              }}
              className="text-xs px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat === 'All' ? 'All Categories' : cat}
                </option>
              ))}
            </select>

            {/* Difficulty Select */}
            <select
              value={difficulty}
              onChange={(e) => {
                setDifficulty(e.target.value);
                setPage(1);
              }}
              className="text-xs px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              <option value="All">All Difficulties</option>
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-slate-400">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-xs px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              <option value="relevance">Default (Code)</option>
              <option value="duration_asc">Duration: Short to Long</option>
              <option value="duration_desc">Duration: Long to Short</option>
              <option value="title">Title (A-Z)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Courses Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-56" />
          ))}
        </div>
      ) : courses.length === 0 ? (
        <EmptyState
          icon={<BookOpen className="w-6 h-6" />}
          title="No courses found"
          description="Try adjusting your search keywords or resetting active category filters."
          actionLabel="Reset Filters"
          onAction={() => {
            setSearch('');
            setSelectedCategory('All');
            setDifficulty('All');
            setSortBy('relevance');
          }}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses.map((course) => {
            // Check unmet prerequisites
            const missingPrereqs = course.prerequisite_course_ids.filter(
              (p) => !completedList.includes(p)
            );
            const isBlocked = missingPrereqs.length > 0;
            const isCompleted = course.user_status === 'completed' || completedList.includes(course.course_id);

            return (
              <Card
                key={course.course_id}
                hoverEffect
                className="flex flex-col justify-between p-5 border-slate-200/90 dark:border-slate-800"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-[11px] font-bold text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-950/60 px-2 py-0.5 rounded-md">
                      {course.course_id}
                    </span>
                    <Badge
                      variant={
                        course.difficulty_level === 'Beginner'
                          ? 'success'
                          : course.difficulty_level === 'Intermediate'
                          ? 'brand'
                          : 'danger'
                      }
                      size="sm"
                    >
                      {course.difficulty_level}
                    </Badge>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1 leading-snug">
                    {course.title}
                  </h3>

                  <p className="text-[11px] text-slate-400 font-medium mt-0.5">{course.category}</p>

                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-2 leading-relaxed">
                    {course.short_description}
                  </p>

                  {/* Prerequisites Warnings */}
                  {isBlocked && (
                    <div className="mt-2.5 flex items-center gap-1.5 text-[11px] text-amber-600 dark:text-amber-400 font-semibold bg-amber-50 dark:bg-amber-950/40 px-2 py-1 rounded-lg">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">Requires: {missingPrereqs.join(', ')}</span>
                    </div>
                  )}

                  {/* Skills Gained Tags */}
                  <div className="flex flex-wrap gap-1 mt-3">
                    {course.skills_gained.slice(0, 3).map((sk) => (
                      <Badge key={sk} variant="neutral" size="sm">
                        {sk}
                      </Badge>
                    ))}
                    {course.skills_gained.length > 3 && (
                      <span className="text-[10px] text-slate-400 font-semibold self-center">
                        +{course.skills_gained.length - 3} more
                      </span>
                    )}
                  </div>
                </div>

                {/* Footer with Duration & Action */}
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-1 text-[11px] text-slate-500">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{course.estimated_duration_hours} Hours</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {isCompleted ? (
                      <span className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Completed
                      </span>
                    ) : null}

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setActiveCourse(course)}
                      className="text-xs h-7 px-3"
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500">
            Page {page} of {totalPages} ({totalCount} total courses)
          </span>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() => setPage(page - 1)}
              leftIcon={<ChevronLeft className="w-4 h-4" />}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= totalPages}
              onClick={() => setPage(page + 1)}
              rightIcon={<ChevronRight className="w-4 h-4" />}
            >
              Next
            </Button>
          </div>
        </div>
      )}

      {/* Course Detail Modal */}
      {activeCourse && (
        <Modal
          isOpen={!!activeCourse}
          onClose={() => setActiveCourse(null)}
          title={`${activeCourse.course_id} — ${activeCourse.title}`}
          description={`${activeCourse.category} • ${activeCourse.difficulty_level} • ${activeCourse.estimated_duration_hours} Hours`}
          maxWidth="xl"
        >
          <div className="space-y-4 text-xs">
            <div>
              <span className="font-bold text-slate-900 dark:text-white block mb-1">
                Overview & Description
              </span>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                {activeCourse.short_description}
              </p>
            </div>

            {/* Prerequisites Section */}
            <div>
              <span className="font-bold text-slate-900 dark:text-white block mb-1.5">
                Prerequisite Dependencies:
              </span>
              {activeCourse.prerequisite_course_ids.length > 0 ? (
                <div className="space-y-1.5">
                  {activeCourse.prerequisite_course_ids.map((pId) => {
                    const isMet = completedList.includes(pId);
                    return (
                      <div
                        key={pId}
                        className={`p-2.5 rounded-xl border flex items-center justify-between ${
                          isMet
                            ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
                            : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300'
                        }`}
                      >
                        <span className="font-semibold">{pId}</span>
                        <span className="text-[11px] font-medium">
                          {isMet ? '✓ Satisfied' : '⚠️ Missing (Must take first)'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <span className="text-slate-500 italic">None — direct foundational enrollment.</span>
              )}
            </div>

            {/* Skills Gained */}
            <div>
              <span className="font-bold text-slate-900 dark:text-white block mb-1.5">
                Skills You Will Gain:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {activeCourse.skills_gained.map((sk) => (
                  <Badge key={sk} variant="brand">
                    {sk}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Learning Objectives */}
            {activeCourse.learning_objectives && activeCourse.learning_objectives.length > 0 && (
              <div>
                <span className="font-bold text-slate-900 dark:text-white block mb-1">
                  Core Learning Objectives:
                </span>
                <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-300">
                  {activeCourse.learning_objectives.map((obj, i) => (
                    <li key={i}>{obj}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Learning Resource Link */}
            {activeCourse.learning_resource_url && (
              <div className="pt-2">
                <a
                  href={activeCourse.learning_resource_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-brand-600 dark:text-brand-400 font-semibold hover:underline"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Verified Syllabus & Learning Resource Link
                </a>
              </div>
            )}

            {/* Change Status Action Bar */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-semibold">Your Status:</span>
                <select
                  value={activeCourse.user_status || 'not_started'}
                  onChange={(e) => handleUpdateStatus(activeCourse.course_id, e.target.value as CourseStatus)}
                  disabled={updatingStatus}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-semibold text-slate-800 dark:text-slate-200"
                >
                  <option value="not_started">Not Started</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                </select>
              </div>

              <Button variant="outline" size="sm" onClick={() => setActiveCourse(null)}>
                Close
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Admin Add Course Modal */}
      <Modal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        title="Admin: Create New Course"
        description="Add a new verified course to the curriculum catalog."
      >
        <form onSubmit={handleCreateCourse} className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block font-semibold mb-1">Course Code</label>
              <input
                type="text"
                required
                value={newCourseId}
                onChange={(e) => setNewCourseId(e.target.value)}
                placeholder="e.g. AI501"
                className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">Category</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700"
              >
                {CATEGORIES.filter((c) => c !== 'All').map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1">Course Title</label>
            <input
              type="text"
              required
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="e.g. Advanced Reinforcement Learning"
              className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1">Description</label>
            <textarea
              required
              rows={2}
              value={newDesc}
              onChange={(e) => setNewDesc(e.target.value)}
              placeholder="Comprehensive course syllabus description..."
              className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block font-semibold mb-1">Difficulty</label>
              <select
                value={newDiff}
                onChange={(e) => setNewDiff(e.target.value as DifficultyLevel)}
                className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700"
              >
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold mb-1">Duration (Hours)</label>
              <input
                type="number"
                required
                value={newHours}
                onChange={(e) => setNewHours(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1">Prerequisites (Comma separated IDs)</label>
            <input
              type="text"
              value={newPrereqs}
              onChange={(e) => setNewPrereqs(e.target.value)}
              placeholder="e.g. CS101, ML301"
              className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1">Skills Gained (Comma separated)</label>
            <input
              type="text"
              value={newSkills}
              onChange={(e) => setNewSkills(e.target.value)}
              placeholder="e.g. Q-Learning, Policy Gradients"
              className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3">
            <Button type="button" variant="outline" size="sm" onClick={() => setAdminModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm" isLoading={isCreatingCourse}>
              Publish Course
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
