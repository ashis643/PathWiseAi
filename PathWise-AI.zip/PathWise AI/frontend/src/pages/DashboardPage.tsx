import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Sparkles,
  BookOpen,
  Clock,
  Target,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Plus,
  PlayCircle,
  Compass,
  Calendar,
  Layers,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts';
import { dashboardApi, progressApi } from '../services/api';
import type { DashboardOverview, RecommendedCourseItem } from '../types';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Skeleton } from '../components/ui/Skeleton';
import { Modal } from '../components/ui/Modal';
import { useToast } from '../contexts/ToastContext';

export const DashboardPage: React.FC = () => {
  const [data, setData] = useState<DashboardOverview | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCourse, setSelectedCourse] = useState<RecommendedCourseItem | null>(null);

  // Quick Log Hours Modal
  const [logModalOpen, setLogModalOpen] = useState(false);
  const [logCourseId, setLogCourseId] = useState('');
  const [logHours, setLogHours] = useState('2');
  const [logNotes, setLogNotes] = useState('');
  const [isLogging, setIsLogging] = useState(false);

  const navigate = useNavigate();
  const { success, error } = useToast();

  const fetchDashboard = async () => {
    try {
      const res = await dashboardApi.getOverview();
      setData(res.data);
    } catch (err) {
      console.error('Failed to load dashboard', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  const handleLogHours = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!logCourseId) {
      error('Course Required', 'Please select or enter a course ID.');
      return;
    }
    setIsLogging(true);
    try {
      await progressApi.logStudyHours({
        course_id: logCourseId,
        hours: parseFloat(logHours) || 1,
        notes: logNotes,
      });
      success('Hours Logged', `Successfully logged ${logHours} study hours!`);
      setLogModalOpen(false);
      setLogCourseId('');
      setLogNotes('');
      fetchDashboard();
    } catch (err: any) {
      error('Failed', err.response?.data?.detail || 'Could not log study hours.');
    } finally {
      setIsLogging(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-32 w-full" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Skeleton className="h-28" />
          <Skeleton className="h-28" />
          <Skeleton className="h-28" />
          <Skeleton className="h-28" />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Skeleton className="h-80 lg:col-span-2" />
          <Skeleton className="h-80" />
        </div>
      </div>
    );
  }

  if (!data) return null;

  // Prepare radar chart data for skills
  const radarData = [
    { subject: 'Readiness', score: data.skill_metrics.career_readiness, fullMark: 100 },
    { subject: 'Coverage', score: data.skill_metrics.skill_coverage, fullMark: 100 },
    { subject: 'Profile', score: data.profile_completion, fullMark: 100 },
    { subject: 'Roadmap', score: data.progress.roadmap_completion_percentage, fullMark: 100 },
    {
      subject: 'Weekly Effort',
      score: Math.min(100, Math.round((data.weekly_hours_logged / (data.weekly_hours_target || 15)) * 100)),
      fullMark: 100,
    },
  ];

  return (
    <div className="space-y-6">
      {/* 1. Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-brand-700 via-indigo-700 to-blue-800 text-white p-6 sm:p-8 shadow-xl shadow-brand-500/10">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-[11px] font-semibold text-brand-100 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" /> AI-Powered Academic Workspace
          </div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold tracking-tight">
            Welcome back, {data.user.full_name}
          </h1>
          <p className="mt-1.5 text-xs sm:text-sm text-indigo-100/90 leading-relaxed max-w-2xl">
            You are targeting <span className="font-bold text-white underline decoration-amber-400 decoration-2">{data.user.target_career}</span>.
            {data.current_phase
              ? ` You are currently progressing through ${data.current_phase.title}.`
              : ' Your personalized learning sequence is ready.'}
          </p>

          {/* Profile Completion Meter */}
          <div className="mt-5 max-w-md bg-black/20 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <div className="flex justify-between items-center text-xs font-semibold mb-1.5">
              <span className="text-indigo-200">Profile Readiness Score</span>
              <span className="text-white font-bold">{data.profile_completion}%</span>
            </div>
            <div className="w-full bg-white/20 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-emerald-400 to-teal-300 h-full rounded-full transition-all duration-500"
                style={{ width: `${data.profile_completion}%` }}
              />
            </div>
          </div>
        </div>

        {/* Decorative circular blur background */}
        <div className="absolute right-0 top-0 -mt-10 -mr-10 w-80 h-80 rounded-full bg-indigo-500/30 blur-3xl pointer-events-none" />
      </div>

      {/* 2. Key Metric Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Career Readiness */}
        <Card hoverEffect className="p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Career Readiness
            </span>
            <div className="w-9 h-9 rounded-xl bg-brand-50 dark:bg-brand-950/60 text-brand-600 flex items-center justify-center">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {data.skill_metrics.career_readiness}%
            </span>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
              Industry Match
            </span>
          </div>
          <ProgressBar value={data.skill_metrics.career_readiness} showPercentage={false} size="sm" className="mt-2.5" />
        </Card>

        {/* Courses Completed */}
        <Card hoverEffect className="p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Courses Completed
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {data.progress.completed_count}
            </span>
            <span className="text-[11px] text-slate-500 font-medium">
              / {data.progress.total_enrolled} enrolled
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">
            {data.progress.in_progress_count} course(s) currently in progress
          </div>
        </Card>

        {/* Weekly Study Hours */}
        <Card hoverEffect className="p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Weekly Study Effort
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {data.weekly_hours_logged}h
            </span>
            <span className="text-[11px] text-slate-500 font-medium">
              / {data.weekly_hours_target}h target
            </span>
          </div>
          <ProgressBar
            value={(data.weekly_hours_logged / (data.weekly_hours_target || 15)) * 100}
            showPercentage={false}
            size="sm"
            variant="brand"
            className="mt-2.5"
          />
        </Card>

        {/* Roadmap Progress */}
        <Card hoverEffect className="p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Roadmap Progress
            </span>
            <div className="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {data.progress.roadmap_completion_percentage}%
            </span>
            <span className="text-[11px] text-purple-600 dark:text-purple-400 font-semibold">
              Phase {data.current_phase?.phase_number || 1}
            </span>
          </div>
          <ProgressBar
            value={data.progress.roadmap_completion_percentage}
            showPercentage={false}
            size="sm"
            variant="purple"
            className="mt-2.5"
          />
        </Card>
      </div>

      {/* 3. Middle Section: Current Phase & Radar Skill Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Current Roadmap Phase Highlight */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base">Current Academic Phase</CardTitle>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Topologically ordered according to prerequisite prerequisites.
              </p>
            </div>
            <Link to="/roadmap">
              <Button variant="outline" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                Full Roadmap
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-4">
            {data.current_phase ? (
              <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-50 to-indigo-50/40 dark:from-slate-850 dark:to-brand-950/30 border border-slate-200/80 dark:border-slate-800">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <Badge variant="brand" size="sm" className="mb-2">
                      Phase {data.current_phase.phase_number}
                    </Badge>
                    <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                      {data.current_phase.title}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                      <span className="font-semibold text-brand-600 dark:text-brand-400">Milestone: </span>
                      {data.current_phase.milestone}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                      ~{data.current_phase.estimated_weeks} weeks
                    </span>
                    <span className="text-[11px] text-slate-500 block">
                      {data.current_phase.total_hours} study hours
                    </span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs">
                  <span className="text-slate-500">
                    Completed {data.current_phase.completed_count} of {data.current_phase.courses_count} courses
                  </span>
                  <div className="flex gap-2">
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => setLogModalOpen(true)}
                      leftIcon={<Plus className="w-3.5 h-3.5" />}
                    >
                      Log Study Session
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500">No active roadmap generated yet.</p>
            )}

            {/* Missing Critical Skills Warning */}
            {data.skill_metrics.missing_high_priority.length > 0 && (
              <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 flex items-start gap-3">
                <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-bold text-amber-900 dark:text-amber-200">
                    Priority Skill Gaps for {data.user.target_career}:
                  </span>
                  <div className="flex flex-wrap gap-1.5 mt-1.5">
                    {data.skill_metrics.missing_high_priority.map((sk) => (
                      <Badge key={sk} variant="warning" size="sm">
                        {sk}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Skill Competency Radar */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Readiness Radar</CardTitle>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Coverage vs industry target
            </p>
          </CardHeader>
          <CardContent className="h-64 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="#94a3b8" strokeOpacity={0.25} />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 11 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                <Radar
                  name="Metrics"
                  dataKey="score"
                  stroke="#4f46e5"
                  fill="#6366f1"
                  fillOpacity={0.4}
                />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* 4. Top Explainable Course Recommendations */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-brand-600" /> Recommended For You
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Ranked with normalized weighted scoring: career fit (25%), skills (25%), interests (15%), gaps (15%).
            </p>
          </div>
          <Link to="/recommendations">
            <Button variant="ghost" size="sm" rightIcon={<ArrowRight className="w-4 h-4" />}>
              View All ({data.top_recommendations.length})
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {data.top_recommendations.slice(0, 4).map((rec) => (
            <Card
              key={rec.course_id}
              hoverEffect
              className="flex flex-col justify-between p-4 border-slate-200/90 dark:border-slate-800"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <Badge variant="brand" size="sm">
                    {rec.recommendation_score}% Match
                  </Badge>
                  <span className="text-[11px] font-semibold text-slate-400">
                    {rec.estimated_duration_hours} hrs
                  </span>
                </div>

                <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug">
                  {rec.title}
                </h4>

                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                  {rec.explanation}
                </p>

                <div className="flex flex-wrap gap-1 mt-3">
                  {rec.skills_gained.slice(0, 2).map((sk) => (
                    <Badge key={sk} variant="neutral" size="sm">
                      +{sk}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                <Badge
                  variant={
                    rec.difficulty_level === 'Beginner'
                      ? 'success'
                      : rec.difficulty_level === 'Intermediate'
                      ? 'brand'
                      : 'danger'
                  }
                  size="sm"
                >
                  {rec.difficulty_level}
                </Badge>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedCourse(rec)}
                  className="text-[11px] h-7 px-2.5"
                >
                  Details
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Course Detail Modal */}
      {selectedCourse && (
        <Modal
          isOpen={!!selectedCourse}
          onClose={() => setSelectedCourse(null)}
          title={selectedCourse.title}
          description={`${selectedCourse.category} • ${selectedCourse.difficulty_level} • ${selectedCourse.estimated_duration_hours} Hours`}
        >
          <div className="space-y-4 text-xs">
            {/* Recommendation Score Breakdown */}
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800">
              <div className="flex justify-between items-center mb-2">
                <span className="font-bold text-slate-900 dark:text-white">
                  Why PathWise AI recommends this:
                </span>
                <Badge variant="brand">{selectedCourse.recommendation_score}% Score</Badge>
              </div>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                {selectedCourse.explanation}
              </p>
            </div>

            {/* Skills Gained */}
            <div>
              <span className="font-bold text-slate-900 dark:text-white block mb-1.5">
                Competencies & Skills Gained:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {selectedCourse.skills_gained.map((sk) => (
                  <Badge key={sk} variant="brand">
                    {sk}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Prerequisites */}
            <div>
              <span className="font-bold text-slate-900 dark:text-white block mb-1">
                Prerequisites:
              </span>
              {selectedCourse.prerequisites.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {selectedCourse.prerequisites.map((p) => (
                    <Badge key={p} variant="warning">
                      Required: {p}
                    </Badge>
                  ))}
                </div>
              ) : (
                <span className="text-slate-500 italic">None (Foundational Entry Level)</span>
              )}
            </div>

            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setSelectedCourse(null)}>
                Close
              </Button>
              <Link to="/roadmap">
                <Button variant="primary" size="sm">
                  Add to Academic Roadmap
                </Button>
              </Link>
            </div>
          </div>
        </Modal>
      )}

      {/* Quick Log Hours Modal */}
      <Modal
        isOpen={logModalOpen}
        onClose={() => setLogModalOpen(false)}
        title="Record Study Session"
        description="Track your learning effort to keep weekly progress on target."
      >
        <form onSubmit={handleLogHours} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Course Code / Title
            </label>
            <input
              type="text"
              required
              value={logCourseId}
              onChange={(e) => setLogCourseId(e.target.value.toUpperCase())}
              placeholder="e.g. CS101 or ML301"
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Hours Spent
            </label>
            <input
              type="number"
              step="0.5"
              min="0.5"
              max="16"
              required
              value={logHours}
              onChange={(e) => setLogHours(e.target.value)}
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Session Notes / Topics Covered
            </label>
            <textarea
              rows={2}
              value={logNotes}
              onChange={(e) => setLogNotes(e.target.value)}
              placeholder="e.g. Solved binary tree problems and recursion review"
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" size="sm" onClick={() => setLogModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm" isLoading={isLogging}>
              Save Study Hours
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
