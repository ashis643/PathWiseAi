import React, { useState, useEffect } from 'react';
import {
  User,
  GraduationCap,
  Target,
  Briefcase,
  Clock,
  Sparkles,
  Save,
  Check,
  Plus,
  X,
  BookOpen,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { ProgressBar } from '../components/ui/ProgressBar';
import type { DifficultyLevel, LearningPace } from '../types';

const CAREERS = [
  'AI/ML Engineer',
  'Data Analyst',
  'Software Engineer',
  'Cloud/DevOps Engineer',
  'Cybersecurity Analyst',
];

export const ProfilePage: React.FC = () => {
  const { profile, user, updateProfile } = useAuth();
  const [isSaving, setIsSaving] = useState(false);

  // Profile Form States
  const [fullName, setFullName] = useState('');
  const [university, setUniversity] = useState('');
  const [degreeProgram, setDegreeProgram] = useState('');
  const [department, setDepartment] = useState('');
  const [currentSemester, setCurrentSemester] = useState(1);
  const [currentCgpa, setCurrentCgpa] = useState('');
  const [targetCareer, setTargetCareer] = useState('AI/ML Engineer');

  const [technicalSkills, setTechnicalSkills] = useState<string[]>([]);
  const [softSkills, setSoftSkills] = useState<string[]>([]);
  const [interests, setInterests] = useState<string[]>([]);
  const [targetSkills, setTargetSkills] = useState<string[]>([]);
  const [completedCourses, setCompletedCourses] = useState<string[]>([]);

  const [availableHours, setAvailableHours] = useState(15);
  const [preferredDifficulty, setPreferredDifficulty] = useState<DifficultyLevel>('Intermediate');
  const [preferredPace, setPreferredPace] = useState<LearningPace>('Balanced');

  // Input helpers for badge chips
  const [techInput, setTechInput] = useState('');
  const [softInput, setSoftInput] = useState('');
  const [interestInput, setInterestInput] = useState('');
  const [targetSkillInput, setTargetSkillInput] = useState('');
  const [completedInput, setCompletedInput] = useState('');

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setUniversity(profile.university || '');
      setDegreeProgram(profile.degree_program || '');
      setDepartment(profile.department || '');
      setCurrentSemester(profile.current_semester || 1);
      setCurrentCgpa(profile.current_cgpa ? String(profile.current_cgpa) : '');
      setTargetCareer(profile.target_career || 'AI/ML Engineer');
      setTechnicalSkills(profile.technical_skills || []);
      setSoftSkills(profile.soft_skills || []);
      setInterests(profile.areas_of_interest || []);
      setTargetSkills(profile.target_skills || []);
      setCompletedCourses(profile.completed_courses || []);
      setAvailableHours(profile.available_study_hours_per_week || 15);
      setPreferredDifficulty(profile.preferred_difficulty || 'Intermediate');
      setPreferredPace(profile.preferred_learning_pace || 'Balanced');
    }
  }, [profile]);

  const addTag = (
    value: string,
    list: string[],
    setter: React.Dispatch<React.SetStateAction<string[]>>,
    inputSetter: React.Dispatch<React.SetStateAction<string>>
  ) => {
    const val = value.trim();
    if (val && !list.includes(val)) {
      setter([...list, val]);
    }
    inputSetter('');
  };

  const removeTag = (
    value: string,
    list: string[],
    setter: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    setter(list.filter((item) => item !== value));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    await updateProfile({
      full_name: fullName,
      university,
      degree_program: degreeProgram,
      department,
      current_semester: Number(currentSemester),
      current_cgpa: currentCgpa ? parseFloat(currentCgpa) : null,
      target_career: targetCareer,
      technical_skills: technicalSkills,
      soft_skills: softSkills,
      areas_of_interest: interests,
      target_skills: targetSkills,
      completed_courses: completedCourses,
      available_study_hours_per_week: Number(availableHours),
      preferred_difficulty: preferredDifficulty,
      preferred_learning_pace: preferredPace,
    });
    setIsSaving(false);
  };

  return (
    <div className="space-y-6">
      {/* Header and Profile Strength */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-500 text-white flex items-center justify-center font-extrabold text-2xl shadow-md shrink-0">
            {fullName ? fullName.charAt(0) : 'U'}
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {fullName || 'Student Profile'}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {degreeProgram} • {university}
            </p>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="brand">{targetCareer}</Badge>
              <Badge variant="neutral">Semester {currentSemester}</Badge>
            </div>
          </div>
        </div>

        <div className="w-full md:w-64 bg-slate-50 dark:bg-slate-850 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-800">
          <div className="flex justify-between items-center text-xs font-semibold mb-2">
            <span className="text-slate-600 dark:text-slate-300">Profile Completeness</span>
            <span className="font-bold text-brand-600 dark:text-brand-400">
              {profile?.completion_percentage || 0}%
            </span>
          </div>
          <ProgressBar value={profile?.completion_percentage || 0} size="sm" />
          <p className="text-[10px] text-slate-400 mt-2">
            Updating your skills directly recalculates your AI recommendations and roadmap.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* 1. Academic & Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-brand-600" /> Academic & Personal Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address (Account ID)
                </label>
                <input
                  type="email"
                  disabled
                  value={user?.email || ''}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 opacity-70 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  University / Institution
                </label>
                <input
                  type="text"
                  value={university}
                  onChange={(e) => setUniversity(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Degree Program
                </label>
                <input
                  type="text"
                  value={degreeProgram}
                  onChange={(e) => setDegreeProgram(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Department / Specialization
                </label>
                <input
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Semester
                  </label>
                  <select
                    value={currentSemester}
                    onChange={(e) => setCurrentSemester(Number(e.target.value))}
                    className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                      <option key={s} value={s}>
                        Semester {s}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    CGPA (Optional)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="10"
                    value={currentCgpa}
                    onChange={(e) => setCurrentCgpa(e.target.value)}
                    placeholder="3.8"
                    className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 2. Target Career & Completed Courses */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="w-5 h-5 text-brand-600" /> Career Goal & Completed Courses
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Primary Target Career
              </label>
              <select
                value={targetCareer}
                onChange={(e) => setTargetCareer(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-semibold text-slate-800 dark:text-slate-200"
              >
                {CAREERS.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Completed Courses Badge Tags */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Completed Course IDs (Excludes from recommendations and satisfies prerequisites)
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={completedInput}
                  onChange={(e) => setCompletedInput(e.target.value.toUpperCase())}
                  onKeyDown={(e) =>
                    e.key === 'Enter' &&
                    (e.preventDefault(),
                    addTag(completedInput, completedCourses, setCompletedCourses, setCompletedInput))
                  }
                  placeholder="e.g. CS101, DB201 (Press Enter)"
                  className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() =>
                    addTag(completedInput, completedCourses, setCompletedCourses, setCompletedInput)
                  }
                >
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200/60 dark:border-slate-800 min-h-[36px]">
                {completedCourses.map((c) => (
                  <Badge key={c} variant="success" className="gap-1.5 py-1">
                    ✓ {c}
                    <button
                      type="button"
                      onClick={() => removeTag(c, completedCourses, setCompletedCourses)}
                      className="hover:text-rose-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 3. Skills & Interests */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-brand-600" /> Technical Competencies & Interests
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Technical Skills */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Technical Skills Known
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={techInput}
                  onChange={(e) => setTechInput(e.target.value)}
                  onKeyDown={(e) =>
                    e.key === 'Enter' &&
                    (e.preventDefault(), addTag(techInput, technicalSkills, setTechnicalSkills, setTechInput))
                  }
                  placeholder="e.g. Python, SQL, Git (Press Enter)"
                  className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => addTag(techInput, technicalSkills, setTechnicalSkills, setTechInput)}
                >
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200/60 dark:border-slate-800 min-h-[36px]">
                {technicalSkills.map((s) => (
                  <Badge key={s} variant="brand" className="gap-1.5 py-1">
                    {s}
                    <button
                      type="button"
                      onClick={() => removeTag(s, technicalSkills, setTechnicalSkills)}
                      className="hover:text-rose-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            {/* Target Skills */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Target Competencies (Skills You Want to Acquire)
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={targetSkillInput}
                  onChange={(e) => setTargetSkillInput(e.target.value)}
                  onKeyDown={(e) =>
                    e.key === 'Enter' &&
                    (e.preventDefault(),
                    addTag(targetSkillInput, targetSkills, setTargetSkills, setTargetSkillInput))
                  }
                  placeholder="e.g. PyTorch, MLOps, Docker (Press Enter)"
                  className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() =>
                    addTag(targetSkillInput, targetSkills, setTargetSkills, setTargetSkillInput)
                  }
                >
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200/60 dark:border-slate-800 min-h-[36px]">
                {targetSkills.map((s) => (
                  <Badge key={s} variant="purple" className="gap-1.5 py-1">
                    {s}
                    <button
                      type="button"
                      onClick={() => removeTag(s, targetSkills, setTargetSkills)}
                      className="hover:text-rose-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            {/* Areas of Interest */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Areas of Interest
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={interestInput}
                  onChange={(e) => setInterestInput(e.target.value)}
                  onKeyDown={(e) =>
                    e.key === 'Enter' &&
                    (e.preventDefault(), addTag(interestInput, interests, setInterests, setInterestInput))
                  }
                  placeholder="e.g. Artificial Intelligence, Cloud (Press Enter)"
                  className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => addTag(interestInput, interests, setInterests, setInterestInput)}
                >
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200/60 dark:border-slate-800 min-h-[36px]">
                {interests.map((s) => (
                  <Badge key={s} variant="cyan" className="gap-1.5 py-1">
                    {s}
                    <button
                      type="button"
                      onClick={() => removeTag(s, interests, setInterests)}
                      className="hover:text-rose-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 4. Study Schedule & Preferences */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="w-5 h-5 text-brand-600" /> Study Availability & Preferences
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Available Study Hours per Week
                </label>
                <span className="text-xs font-bold text-brand-600 dark:text-brand-400">
                  {availableHours} Hours
                </span>
              </div>
              <input
                type="range"
                min="5"
                max="40"
                value={availableHours}
                onChange={(e) => setAvailableHours(Number(e.target.value))}
                className="w-full accent-brand-600 cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Preferred Difficulty
                </label>
                <select
                  value={preferredDifficulty}
                  onChange={(e) => setPreferredDifficulty(e.target.value as DifficultyLevel)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                >
                  <option value="Beginner">Beginner (Foundations first)</option>
                  <option value="Intermediate">Intermediate (Standard pace)</option>
                  <option value="Advanced">Advanced (Fast-track)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Learning Pace
                </label>
                <select
                  value={preferredPace}
                  onChange={(e) => setPreferredPace(e.target.value as LearningPace)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                >
                  <option value="Relaxed">Relaxed</option>
                  <option value="Balanced">Balanced</option>
                  <option value="Intensive">Intensive</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Submit Actions */}
        <div className="flex justify-end gap-3">
          <Button
            type="submit"
            variant="primary"
            size="md"
            isLoading={isSaving}
            leftIcon={<Save className="w-4 h-4" />}
          >
            Save Profile & Recalculate AI Engine
          </Button>
        </div>
      </form>
    </div>
  );
};
