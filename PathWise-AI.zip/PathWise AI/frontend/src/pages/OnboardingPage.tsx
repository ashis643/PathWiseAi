import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  GraduationCap,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Check,
  Plus,
  X,
  Target,
  BookOpen,
  Clock,
  Briefcase,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import type { DifficultyLevel, LearningPace } from '../types';

const CAREER_OPTIONS = [
  'AI/ML Engineer',
  'Data Analyst',
  'Software Engineer',
  'Cloud/DevOps Engineer',
  'Cybersecurity Analyst',
];

const PREDEFINED_INTERESTS = [
  'Machine Learning',
  'Artificial Intelligence',
  'Deep Learning',
  'Web Development',
  'Cloud Architecture',
  'Algorithms & Optimization',
  'Cybersecurity',
  'Data Science',
  'DevOps & CI/CD',
  'Database Engineering',
];

const SUGGESTED_SKILLS = [
  'Python',
  'Java',
  'C++',
  'JavaScript',
  'TypeScript',
  'SQL',
  'Git',
  'Docker',
  'AWS',
  'Linux',
  'Pandas',
  'Scikit-Learn',
  'PyTorch',
  'React',
  'FastAPI',
  'Algorithmic Thinking',
];

export const OnboardingPage: React.FC = () => {
  const { profile, updateProfile } = useAuth();
  const navigate = useNavigate();

  const [step, setStep] = useState(1);
  const [isSaving, setIsSaving] = useState(false);

  // Form State
  const [university, setUniversity] = useState(profile?.university || 'State University');
  const [degreeProgram, setDegreeProgram] = useState(profile?.degree_program || 'B.S. in Computer Science');
  const [department, setDepartment] = useState(profile?.department || 'Computer Science & Engineering');
  const [currentSemester, setCurrentSemester] = useState(profile?.current_semester || 3);
  const [currentCgpa, setCurrentCgpa] = useState<string>(profile?.current_cgpa ? String(profile.current_cgpa) : '3.8');

  const [targetCareer, setTargetCareer] = useState(profile?.target_career || 'AI/ML Engineer');
  const [interests, setInterests] = useState<string[]>(profile?.areas_of_interest || ['Machine Learning', 'Artificial Intelligence']);

  const [technicalSkills, setTechnicalSkills] = useState<string[]>(profile?.technical_skills || ['Python', 'Git']);
  const [targetSkills, setTargetSkills] = useState<string[]>(profile?.target_skills || ['PyTorch', 'Deep Learning', 'Scikit-Learn']);
  const [skillInput, setSkillInput] = useState('');
  const [targetSkillInput, setTargetSkillInput] = useState('');

  const [availableHours, setAvailableHours] = useState(profile?.available_study_hours_per_week || 15);
  const [preferredDifficulty, setPreferredDifficulty] = useState<DifficultyLevel>(profile?.preferred_difficulty || 'Intermediate');
  const [preferredPace, setPreferredPace] = useState<LearningPace>(profile?.preferred_learning_pace || 'Balanced');

  const toggleInterest = (interest: string) => {
    if (interests.includes(interest)) {
      setInterests(interests.filter((i) => i !== interest));
    } else {
      setInterests([...interests, interest]);
    }
  };

  const addSkill = (skill: string) => {
    const s = skill.trim();
    if (s && !technicalSkills.includes(s)) {
      setTechnicalSkills([...technicalSkills, s]);
    }
    setSkillInput('');
  };

  const removeSkill = (skill: string) => {
    setTechnicalSkills(technicalSkills.filter((s) => s !== skill));
  };

  const addTargetSkill = (skill: string) => {
    const s = skill.trim();
    if (s && !targetSkills.includes(s)) {
      setTargetSkills([...targetSkills, s]);
    }
    setTargetSkillInput('');
  };

  const removeTargetSkill = (skill: string) => {
    setTargetSkills(targetSkills.filter((s) => s !== skill));
  };

  const handleFinish = async (markComplete = true) => {
    setIsSaving(true);
    await updateProfile({
      university,
      degree_program: degreeProgram,
      department,
      current_semester: Number(currentSemester),
      current_cgpa: currentCgpa ? parseFloat(currentCgpa) : null,
      target_career: targetCareer,
      areas_of_interest: interests,
      technical_skills: technicalSkills,
      target_skills: targetSkills,
      available_study_hours_per_week: Number(availableHours),
      preferred_difficulty: preferredDifficulty,
      preferred_learning_pace: preferredPace,
      is_onboarding_completed: markComplete,
    });
    setIsSaving(false);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-10 px-4 sm:px-6 lg:px-8 transition-colors">
      <div className="max-w-2xl mx-auto">
        {/* Top Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-500 text-white shadow-md mb-3">
            <Sparkles className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Academic Profile Setup
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
            PathWise AI customizes course recommendations, prerequisite sequencing, and career skill roadmaps using your academic profile.
          </p>

          {/* Stepper Progress Bar */}
          <div className="flex items-center justify-center gap-3 mt-6 max-w-sm mx-auto">
            {[1, 2, 3, 4].map((stepIdx) => (
              <div key={stepIdx} className="flex-1 flex flex-col items-center gap-1.5">
                <div
                  className={`w-full h-1.5 rounded-full transition-all duration-300 ${
                    step >= stepIdx ? 'bg-brand-600 dark:bg-brand-500' : 'bg-slate-200 dark:bg-slate-800'
                  }`}
                />
                <span className="text-[10px] font-semibold text-slate-400">Step {stepIdx}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Wizard Step Cards */}
        <Card className="p-6 sm:p-8">
          {/* STEP 1: Academic Background */}
          {step === 1 && (
            <div className="space-y-4 animate-fade-in">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <GraduationCap className="w-5 h-5 text-brand-600" /> Academic Background
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Tell us where you are currently studying.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  University / College
                </label>
                <input
                  type="text"
                  value={university}
                  onChange={(e) => setUniversity(e.target.value)}
                  placeholder="e.g. State University of Technology"
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Degree Program
                  </label>
                  <input
                    type="text"
                    value={degreeProgram}
                    onChange={(e) => setDegreeProgram(e.target.value)}
                    placeholder="e.g. B.S. in Computer Science"
                    className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Department / Major
                  </label>
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    placeholder="e.g. Computer Science & Eng."
                    className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Current Semester
                  </label>
                  <select
                    value={currentSemester}
                    onChange={(e) => setCurrentSemester(Number(e.target.value))}
                    className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((sem) => (
                      <option key={sem} value={sem}>
                        Semester {sem}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Current GPA / CGPA (Optional)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="10"
                    value={currentCgpa}
                    onChange={(e) => setCurrentCgpa(e.target.value)}
                    placeholder="e.g. 3.75"
                    className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Target Career & Interests */}
          {step === 2 && (
            <div className="space-y-4 animate-fade-in">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Target className="w-5 h-5 text-brand-600" /> Target Career & Interests
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Select your dream career path and the technology areas you love.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Primary Career Goal
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {CAREER_OPTIONS.map((career) => (
                    <button
                      key={career}
                      type="button"
                      onClick={() => setTargetCareer(career)}
                      className={`p-3 rounded-xl text-left border text-xs font-semibold flex items-center justify-between transition-all ${
                        targetCareer === career
                          ? 'border-brand-600 bg-brand-50 dark:bg-brand-950/60 text-brand-700 dark:text-brand-300 shadow-sm'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <span>{career}</span>
                      {targetCareer === career && <Check className="w-4 h-4 text-brand-600" />}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Areas of Interest (Select all that apply)
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {PREDEFINED_INTERESTS.map((interest) => {
                    const selected = interests.includes(interest);
                    return (
                      <button
                        key={interest}
                        type="button"
                        onClick={() => toggleInterest(interest)}
                        className={`text-xs px-3 py-1.5 rounded-lg border font-medium transition-all ${
                          selected
                            ? 'bg-brand-600 text-white border-brand-600 shadow-sm'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-brand-500/40'
                        }`}
                      >
                        {interest}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Skills & Target Competencies */}
          {step === 3 && (
            <div className="space-y-4 animate-fade-in">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-brand-600" /> Current & Target Skills
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Help the AI identify your skill gaps by declaring your current and desired skills.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Skills You Already Know
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={skillInput}
                    onChange={(e) => setSkillInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill(skillInput))}
                    placeholder="Type a skill and press Enter or Add..."
                    className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
                  />
                  <Button variant="secondary" size="sm" onClick={() => addSkill(skillInput)}>
                    Add
                  </Button>
                </div>
                <div className="flex flex-wrap gap-1.5 min-h-[36px] p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800">
                  {technicalSkills.length === 0 && (
                    <span className="text-xs text-slate-400 italic">No skills added yet.</span>
                  )}
                  {technicalSkills.map((s) => (
                    <Badge key={s} variant="brand" className="gap-1.5 py-1">
                      {s}
                      <button onClick={() => removeSkill(s)} className="hover:text-rose-500">
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Target Competencies You Want to Learn
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={targetSkillInput}
                    onChange={(e) => setTargetSkillInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTargetSkill(targetSkillInput))}
                    placeholder="e.g. PyTorch, MLOps, Docker..."
                    className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
                  />
                  <Button variant="secondary" size="sm" onClick={() => addTargetSkill(targetSkillInput)}>
                    Add
                  </Button>
                </div>
                <div className="flex flex-wrap gap-1.5 min-h-[36px] p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800">
                  {targetSkills.length === 0 && (
                    <span className="text-xs text-slate-400 italic">No target skills added yet.</span>
                  )}
                  {targetSkills.map((s) => (
                    <Badge key={s} variant="purple" className="gap-1.5 py-1">
                      {s}
                      <button onClick={() => removeTargetSkill(s)} className="hover:text-rose-500">
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: Study Schedule & Preferences */}
          {step === 4 && (
            <div className="space-y-4 animate-fade-in">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Clock className="w-5 h-5 text-brand-600" /> Study Availability & Pace
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Customize the weekly workload used to generate your academic completion timelines.
                </p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Available Study Hours per Week
                  </label>
                  <span className="text-xs font-bold text-brand-600 dark:text-brand-400">
                    {availableHours} hours / week
                  </span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="40"
                  step="1"
                  value={availableHours}
                  onChange={(e) => setAvailableHours(Number(e.target.value))}
                  className="w-full accent-brand-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>5 hrs (Part-time)</span>
                  <span>20 hrs (Recommended)</span>
                  <span>40 hrs (Full-time)</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Preferred Difficulty Level
                  </label>
                  <select
                    value={preferredDifficulty}
                    onChange={(e) => setPreferredDifficulty(e.target.value as DifficultyLevel)}
                    className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
                  >
                    <option value="Beginner">Beginner (Foundations first)</option>
                    <option value="Intermediate">Intermediate (Standard)</option>
                    <option value="Advanced">Advanced (Fast-track rigor)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Learning Pace
                  </label>
                  <select
                    value={preferredPace}
                    onChange={(e) => setPreferredPace(e.target.value as LearningPace)}
                    className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500/20 text-slate-900 dark:text-white"
                  >
                    <option value="Relaxed">Relaxed (Self-paced)</option>
                    <option value="Balanced">Balanced (Steady milestones)</option>
                    <option value="Intensive">Intensive (Accelerated)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-6 border-t border-slate-100 dark:border-slate-800 mt-6">
            {step > 1 ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setStep(step - 1)}
                leftIcon={<ArrowLeft className="w-4 h-4" />}
              >
                Back
              </Button>
            ) : (
              <button
                type="button"
                onClick={() => handleFinish(false)}
                className="text-xs font-medium text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
              >
                Skip for now
              </button>
            )}

            {step < 4 ? (
              <Button
                variant="primary"
                size="sm"
                onClick={() => setStep(step + 1)}
                rightIcon={<ArrowRight className="w-4 h-4" />}
              >
                Next Step
              </Button>
            ) : (
              <Button
                variant="primary"
                size="md"
                isLoading={isSaving}
                onClick={() => handleFinish(true)}
                rightIcon={<Sparkles className="w-4 h-4" />}
              >
                Complete & Build Roadmap
              </Button>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};
