import React, { useEffect, useState } from 'react';
import {
  Target,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Clock,
  BookOpen,
  TrendingUp,
  Plus,
  ArrowRight,
  ShieldCheck,
  Calendar,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  Legend,
} from 'recharts';
import { skillGapApi, progressApi } from '../services/api';
import type { SkillGapAnalysis, ProgressSummary } from '../types';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Skeleton } from '../components/ui/Skeleton';
import { Modal } from '../components/ui/Modal';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

export const SkillGapsPage: React.FC = () => {
  const { profile, refreshProfile } = useAuth();
  const { success, error } = useToast();

  const [careerOverride, setCareerOverride] = useState<string>(profile?.target_career || 'AI/ML Engineer');
  const [analysis, setAnalysis] = useState<SkillGapAnalysis | null>(null);
  const [progress, setProgress] = useState<ProgressSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Log Hours Modal
  const [logModalOpen, setLogModalOpen] = useState(false);
  const [logCourseId, setLogCourseId] = useState('');
  const [logHours, setLogHours] = useState('2');
  const [logNotes, setLogNotes] = useState('');
  const [isLogging, setIsLogging] = useState(false);

  const fetchAnalysis = async (career = careerOverride) => {
    setIsLoading(true);
    try {
      const [gapRes, progRes] = await Promise.all([
        skillGapApi.getSkillGapAnalysis(career),
        progressApi.getProgressSummary(),
      ]);
      setAnalysis(gapRes.data);
      setProgress(progRes.data);
    } catch (err) {
      console.error('Failed to load skill gaps', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (profile?.target_career) {
      setCareerOverride(profile.target_career);
    }
    fetchAnalysis(profile?.target_career || careerOverride);
  }, [profile]);

  const handleCareerChange = (newCareer: string) => {
    setCareerOverride(newCareer);
    fetchAnalysis(newCareer);
  };

  const handleLogHours = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!logCourseId.trim()) return;
    setIsLogging(true);
    try {
      await progressApi.logStudyHours({
        course_id: logCourseId.trim().toUpperCase(),
        hours: parseFloat(logHours) || 1,
        notes: logNotes,
      });
      success('Logged Hours', `Recorded ${logHours} study hours.`);
      setLogModalOpen(false);
      setLogCourseId('');
      setLogNotes('');
      await refreshProfile();
      fetchAnalysis();
    } catch (err: any) {
      error('Failed', err.response?.data?.detail || 'Could not log hours.');
    } finally {
      setIsLogging(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-32 w-full" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-28" />
          <Skeleton className="h-28" />
          <Skeleton className="h-28" />
        </div>
        <Skeleton className="h-80 w-full" />
      </div>
    );
  }

  if (!analysis) return null;

  // Chart Data: Required Skills vs Acquired Status
  const chartData = analysis.skill_gaps.map((item) => ({
    name: item.skill_name,
    weight: Math.round(item.importance_weight * 10),
    acquired: item.current_status === 'acquired' ? 10 : item.current_status === 'developing' ? 5 : 0,
    priority: item.priority,
  }));

  return (
    <div className="space-y-6">
      {/* Top Banner with Career Benchmark Selector */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-indigo-900 via-brand-900 to-slate-900 text-white border border-brand-800/40 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <Badge variant="brand" className="mb-2.5 text-[11px] font-bold">
              Module 5: Gap Analysis & Progress Tracking
            </Badge>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold tracking-tight">
              Skill Gap & Progress Intelligence
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-indigo-200/90 max-w-xl leading-relaxed">
              Transparent skill benchmarking against industry requirements. Monitor your learning hours and see how coursework closes competency gaps.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <span className="text-xs font-semibold text-indigo-200">Benchmark Career:</span>
            <select
              value={careerOverride}
              onChange={(e) => handleCareerChange(e.target.value)}
              className="text-xs font-bold px-3.5 py-2 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 text-white focus:outline-none cursor-pointer"
            >
              <option value="AI/ML Engineer" className="text-slate-900">
                AI/ML Engineer
              </option>
              <option value="Data Analyst" className="text-slate-900">
                Data Analyst
              </option>
              <option value="Software Engineer" className="text-slate-900">
                Software Engineer
              </option>
              <option value="Cloud/DevOps Engineer" className="text-slate-900">
                Cloud/DevOps Engineer
              </option>
              <option value="Cybersecurity Analyst" className="text-slate-900">
                Cybersecurity Analyst
              </option>
            </select>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setLogModalOpen(true)}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Log Hours
            </Button>
          </div>
        </div>
      </div>

      {/* KPI Cards: Skill Coverage & Readiness */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card hoverEffect className="p-5">
          <span className="text-xs font-medium text-slate-500">Career Readiness Score</span>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {analysis.overall_readiness_percentage}%
            </span>
            <span className="text-xs font-semibold text-brand-600">Weighted Proficiency</span>
          </div>
          <ProgressBar value={analysis.overall_readiness_percentage} size="sm" className="mt-3" />
        </Card>

        <Card hoverEffect className="p-5">
          <span className="text-xs font-medium text-slate-500">Competencies Acquired</span>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {analysis.acquired_skills_count}
            </span>
            <span className="text-xs text-slate-500 font-medium">
              / {analysis.total_required_skills} Required Skills
            </span>
          </div>
          <ProgressBar value={analysis.skill_coverage_percentage} size="sm" variant="success" className="mt-3" />
        </Card>

        <Card hoverEffect className="p-5">
          <span className="text-xs font-medium text-slate-500">Weekly Study Effort</span>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {progress?.current_week_hours || 0}h
            </span>
            <span className="text-xs text-slate-500 font-medium">
              / {progress?.weekly_goal_hours || 15}h Weekly Target
            </span>
          </div>
          <ProgressBar
            value={((progress?.current_week_hours || 0) / (progress?.weekly_goal_hours || 15)) * 100}
            size="sm"
            variant="purple"
            className="mt-3"
          />
        </Card>
      </div>

      {/* Recharts Bar Visualization: Required vs Current */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Skill Competency Benchmark Comparison</CardTitle>
          <p className="text-xs text-slate-500">
            Green indicates acquired skills; blue indicates importance weight required by the {analysis.career_goal} role.
          </p>
        </CardHeader>
        <CardContent className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 25 }}>
              <XAxis dataKey="name" angle={-30} textAnchor="end" tick={{ fontSize: 10, fill: '#64748b' }} />
              <YAxis tick={{ fontSize: 10, fill: '#64748b' }} domain={[0, 15]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderRadius: '12px',
                  border: '1px solid #334155',
                  color: '#fff',
                  fontSize: '11px',
                }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              <Bar dataKey="weight" name="Role Importance Weight" fill="#6366f1" radius={[4, 4, 0, 0]} />
              <Bar dataKey="acquired" name="Your Current Status" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Skill Gap Matrix Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Target Skills Breakdown & Gap-Closing Courses</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="text-[11px] uppercase bg-slate-100 dark:bg-slate-800 text-slate-500">
                <tr>
                  <th className="p-3 rounded-l-xl">Competency</th>
                  <th className="p-3">Priority</th>
                  <th className="p-3">Target Level</th>
                  <th className="p-3">Current Status</th>
                  <th className="p-3 rounded-r-xl">Recommended Catalog Courses</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {analysis.skill_gaps.map((item) => (
                  <tr key={item.skill_name} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="p-3 font-bold text-slate-900 dark:text-white">
                      {item.skill_name}
                    </td>
                    <td className="p-3">
                      <Badge
                        variant={
                          item.priority === 'High'
                            ? 'danger'
                            : item.priority === 'Medium'
                            ? 'warning'
                            : 'neutral'
                        }
                        size="sm"
                      >
                        {item.priority}
                      </Badge>
                    </td>
                    <td className="p-3 text-slate-500">{item.target_proficiency}</td>
                    <td className="p-3">
                      {item.current_status === 'acquired' ? (
                        <span className="text-emerald-600 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Acquired
                        </span>
                      ) : item.current_status === 'developing' ? (
                        <span className="text-amber-600 font-semibold flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" /> In Progress
                        </span>
                      ) : (
                        <span className="text-rose-600 font-semibold flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> Missing Gap
                        </span>
                      )}
                    </td>
                    <td className="p-3">
                      <div className="flex flex-wrap gap-1">
                        {item.related_courses.map((c) => (
                          <span
                            key={c.course_id}
                            className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[11px] font-semibold text-brand-600 dark:text-brand-400"
                            title={c.title}
                          >
                            {c.course_id}
                          </span>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Recent Study Activity History */}
      {progress && progress.recent_logs && progress.recent_logs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Study Activity History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {progress.recent_logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-brand-600">{log.course_id}</span>
                    <span className="text-slate-700 dark:text-slate-300 font-medium">
                      {log.course_title}
                    </span>
                    {log.notes && (
                      <span className="text-slate-400 italic truncate max-w-xs">
                        "{log.notes}"
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-slate-500 shrink-0">
                    <span className="font-bold text-slate-900 dark:text-white">{log.hours}h</span>
                    <span>{log.study_date}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Study Hour Logging Modal */}
      <Modal
        isOpen={logModalOpen}
        onClose={() => setLogModalOpen(false)}
        title="Record Learning Session"
        description="Log your daily or weekly study hours to keep your roadmap estimates accurate."
      >
        <form onSubmit={handleLogHours} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Course ID / Code
            </label>
            <input
              type="text"
              required
              value={logCourseId}
              onChange={(e) => setLogCourseId(e.target.value)}
              placeholder="e.g. ML301 or CS101"
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Hours Studied
            </label>
            <input
              type="number"
              step="0.5"
              min="0.5"
              max="16"
              required
              value={logHours}
              onChange={(e) => setLogHours(e.target.value)}
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Notes (Optional)
            </label>
            <textarea
              rows={2}
              value={logNotes}
              onChange={(e) => setLogNotes(e.target.value)}
              placeholder="Topics covered, problem sets solved, or lab exercises..."
              className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" size="sm" onClick={() => setLogModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm" isLoading={isLogging}>
              Save Hours
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
