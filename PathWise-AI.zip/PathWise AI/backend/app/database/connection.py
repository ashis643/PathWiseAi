import logging
from pymongo import MongoClient, ASCENDING
from pymongo.database import Database
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from app.core.config import settings

logger = logging.getLogger("pathwise.database")

class DatabaseManager:
    client: MongoClient = None
    db: Database = None
    is_connected: bool = False

    def connect(self):
        """Initializes the MongoDB client and verifies connection with ping."""
        try:
            self.client = MongoClient(settings.MONGODB_URL, serverSelectionTimeoutMS=3000)
            # Verify connectivity
            self.client.admin.command('ping')
            self.db = self.client[settings.DATABASE_NAME]
            self.is_connected = True
            self.init_indexes()
            logger.info(f"Connected successfully to MongoDB database: {settings.DATABASE_NAME}")
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            self.is_connected = False
            logger.error(f"Failed to connect to MongoDB at {settings.MONGODB_URL}: {e}")
            raise e

    def init_indexes(self):
        """Creates unique and lookup indexes for performance and data integrity."""
        if self.db is None:
            return
        try:
            # Users collection
            self.db.users.create_index([("email", ASCENDING)], unique=True)
            
            # Profiles collection
            self.db.student_profiles.create_index([("user_id", ASCENDING)], unique=True)
            self.db.student_profiles.create_index([("email", ASCENDING)])
            
            # Courses collection
            self.db.courses.create_index([("course_id", ASCENDING)], unique=True)
            self.db.courses.create_index([("category", ASCENDING)])
            self.db.courses.create_index([("difficulty_level", ASCENDING)])
            self.db.courses.create_index([("is_active", ASCENDING)])
            
            # Academic roadmaps collection
            self.db.academic_roadmaps.create_index([("user_id", ASCENDING)], unique=True)
            
            # Progress records
            self.db.progress_records.create_index([("user_id", ASCENDING), ("course_id", ASCENDING)], unique=True)
            
            # Study logs
            self.db.study_logs.create_index([("user_id", ASCENDING), ("created_at", ASCENDING)])
            
            logger.info("Database indexes initialized successfully.")
        except Exception as e:
            logger.warning(f"Notice while creating indexes: {e}")

    def close(self):
        """Closes the MongoDB connection."""
        if self.client:
            self.client.close()
            self.is_connected = False
            logger.info("MongoDB connection closed.")

db_manager = DatabaseManager()

def get_database() -> Database:
    """Dependency / helper to get database handle."""
    if not db_manager.is_connected or db_manager.db is None:
        db_manager.connect()
    return db_manager.db
