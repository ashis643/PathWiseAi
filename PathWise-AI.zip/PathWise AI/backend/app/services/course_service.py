import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from bson import ObjectId
from app.database.connection import get_database

logger = logging.getLogger("pathwise.courses")

class CourseService:
    @staticmethod
    def get_courses(
        search: Optional[str] = None,
        category: Optional[str] = None,
        difficulty: Optional[str] = None,
        skills: Optional[List[str]] = None,
        max_duration: Optional[int] = None,
        sort_by: Optional[str] = "relevance",
        page: int = 1,
        page_size: int = 12,
        user_id: Optional[str] = None,
        include_inactive: bool = False
    ) -> Dict[str, Any]:
        """Fetches paginated courses with multiple search filters, user progress mapping, and sorting."""
        db = get_database()
        query: Dict[str, Any] = {}

        if not include_inactive:
            query["is_active"] = True

        if search and search.strip():
            s = search.strip()
            query["$or"] = [
                {"title": {"$regex": s, "$options": "i"}},
                {"short_description": {"$regex": s, "$options": "i"}},
                {"course_id": {"$regex": s, "$options": "i"}},
                {"skills_gained": {"$regex": s, "$options": "i"}},
            ]

        if category and category != "All":
            query["category"] = category

        if difficulty and difficulty != "All":
            query["difficulty_level"] = difficulty

        if max_duration:
            query["estimated_duration_hours"] = {"$lte": max_duration}

        if skills and len(skills) > 0:
            query["skills_gained"] = {"$in": skills}

        total_count = db.courses.count_documents(query)

        # Sorting logic
        sort_field = [("course_id", 1)]
        if sort_by == "duration_asc":
            sort_field = [("estimated_duration_hours", 1)]
        elif sort_by == "duration_desc":
            sort_field = [("estimated_duration_hours", -1)]
        elif sort_by == "title":
            sort_field = [("title", 1)]
        elif sort_by == "difficulty":
            sort_field = [("difficulty_level", 1)]

        skip = max(0, (page - 1) * page_size)
        cursor = db.courses.find(query).sort(sort_field).skip(skip).limit(page_size)
        
        # User progress lookup for status annotation
        user_progress_map = {}
        if user_id:
            records = db.progress_records.find({"user_id": user_id})
            for r in records:
                user_progress_map[r["course_id"]] = r.get("status", "not_started")

        courses = []
        for doc in cursor:
            c_id = doc.get("course_id")
            courses.append({
                "id": str(doc["_id"]),
                "course_id": c_id,
                "title": doc.get("title"),
                "short_description": doc.get("short_description"),
                "category": doc.get("category"),
                "difficulty_level": doc.get("difficulty_level"),
                "estimated_duration_hours": doc.get("estimated_duration_hours"),
                "prerequisite_course_ids": doc.get("prerequisite_course_ids", []),
                "required_skills": doc.get("required_skills", []),
                "skills_gained": doc.get("skills_gained", []),
                "career_relevance": doc.get("career_relevance", []),
                "learning_objectives": doc.get("learning_objectives", []),
                "course_type": doc.get("course_type", "Core"),
                "learning_resource_url": doc.get("learning_resource_url"),
                "is_active": doc.get("is_active", True),
                "user_status": user_progress_map.get(c_id, "not_started"),
                "created_at": doc.get("created_at"),
                "updated_at": doc.get("updated_at")
            })

        return {
            "courses": courses,
            "total_count": total_count,
            "page": page,
            "page_size": page_size,
            "total_pages": max(1, (total_count + page_size - 1) // page_size)
        }

    @staticmethod
    def get_course_by_id(course_id: str, user_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Retrieves a single course by its unique course_id, including detailed prerequisite info."""
        db = get_database()
        doc = db.courses.find_one({"course_id": course_id})
        if not doc:
            return None

        user_status = "not_started"
        if user_id:
            rec = db.progress_records.find_one({"user_id": user_id, "course_id": course_id})
            if rec:
                user_status = rec.get("status", "not_started")

        # Fetch prerequisite course titles and details
        prereqs = []
        if doc.get("prerequisite_course_ids"):
            prereq_docs = db.courses.find({"course_id": {"$in": doc["prerequisite_course_ids"]}})
            for pd in prereq_docs:
                prereqs.append({
                    "course_id": pd["course_id"],
                    "title": pd["title"],
                    "difficulty_level": pd["difficulty_level"],
                    "duration_hours": pd["estimated_duration_hours"]
                })

        return {
            "id": str(doc["_id"]),
            "course_id": doc.get("course_id"),
            "title": doc.get("title"),
            "short_description": doc.get("short_description"),
            "category": doc.get("category"),
            "difficulty_level": doc.get("difficulty_level"),
            "estimated_duration_hours": doc.get("estimated_duration_hours"),
            "prerequisite_course_ids": doc.get("prerequisite_course_ids", []),
            "prerequisites_detail": prereqs,
            "required_skills": doc.get("required_skills", []),
            "skills_gained": doc.get("skills_gained", []),
            "career_relevance": doc.get("career_relevance", []),
            "learning_objectives": doc.get("learning_objectives", []),
            "course_type": doc.get("course_type", "Core"),
            "learning_resource_url": doc.get("learning_resource_url"),
            "is_active": doc.get("is_active", True),
            "user_status": user_status
        }

    @staticmethod
    def get_all_active_courses() -> List[Dict[str, Any]]:
        """Retrieves all active courses for graph and recommendation computations."""
        db = get_database()
        cursor = db.courses.find({"is_active": True})
        return list(cursor)

    @staticmethod
    def create_course(course_data: Dict[str, Any]) -> Dict[str, Any]:
        """Admin creates a new course."""
        db = get_database()
        now = datetime.now(timezone.utc)
        doc = dict(course_data)
        doc["created_at"] = now
        doc["updated_at"] = now
        res = db.courses.insert_one(doc)
        doc["id"] = str(res.inserted_id)
        return doc

    @staticmethod
    def update_course(course_id: str, update_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Admin updates an existing course."""
        db = get_database()
        clean_update = {k: v for k, v in update_data.items() if v is not None}
        clean_update["updated_at"] = datetime.now(timezone.utc)
        res = db.courses.find_one_and_update(
            {"course_id": course_id},
            {"$set": clean_update},
            return_document=True
        )
        if res:
            res["id"] = str(res["_id"])
        return res
