import logging
from typing import List, Dict, Any, Optional, Set, Tuple
from collections import defaultdict, deque
from datetime import datetime, timezone
from app.database.connection import get_database

logger = logging.getLogger("pathwise.roadmap")

class RoadmapService:
    @staticmethod
    def detect_cycles_and_sort(course_ids: List[str], course_map: Dict[str, Dict[str, Any]]) -> Tuple[List[str], bool]:
        """
        Builds a directed dependency graph and executes Kahn's topological sort algorithm.
        Returns sorted sequence and a boolean indicating whether a circular dependency was detected.
        """
        # in_degree: count of prerequisites required within the subset
        in_degree: Dict[str, int] = {c_id: 0 for c_id in course_ids}
        adj_list: Dict[str, List[str]] = defaultdict(list)

        course_set = set(course_ids)

        for c_id in course_ids:
            c = course_map.get(c_id)
            if not c:
                continue
            for prereq in c.get("prerequisite_course_ids", []):
                if prereq in course_set:
                    # prereq must precede c_id
                    adj_list[prereq].append(c_id)
                    in_degree[c_id] += 1

        # Queue of nodes with in-degree 0 (no outstanding prerequisites)
        queue = deque([c_id for c_id in course_ids if in_degree[c_id] == 0])
        # Sort queue deterministically (Foundational first, then beginner, then title)
        sorted_order: List[str] = []

        while queue:
            curr = queue.popleft()
            sorted_order.append(curr)

            for neighbor in adj_list[curr]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # If sorted_order contains all nodes, no cycle
        has_cycle = len(sorted_order) < len(course_ids)
        if has_cycle:
            # Append remaining to avoid crashing, but flag cycle
            remaining = [c for c in course_ids if c not in sorted_order]
            sorted_order.extend(remaining)

        return sorted_order, has_cycle

    @classmethod
    def generate_roadmap_for_student(
        cls, 
        user_id: str, 
        profile: Dict[str, Any], 
        all_courses: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Generates a structured, topological-sorted academic roadmap customized to
        the student's target career, skill gaps, and completed course history.
        """
        db = get_database()
        course_map = {c["course_id"]: c for c in all_courses}
        completed_set = set(profile.get("completed_courses", []))
        user_progress_map = {}
        for r in db.progress_records.find({"user_id": user_id}):
            user_progress_map[r["course_id"]] = r.get("status", "not_started")

        target_career = profile.get("target_career", "AI/ML Engineer")
        weekly_hours = max(5, profile.get("available_study_hours_per_week", 15))

        # Select relevant courses for the roadmap:
        # Include courses matching target_career or foundational prerequisites
        relevant_course_ids = []
        for c in all_courses:
            c_id = c["course_id"]
            career_matches = target_career.lower() in [cr.lower() for cr in c.get("career_relevance", [])]
            is_foundational = c.get("course_type") == "Foundational"
            is_completed = c_id in completed_set

            if career_matches or is_foundational or is_completed:
                relevant_course_ids.append(c_id)

        # Ensure all prerequisites of chosen courses are also in the set
        extended_ids = set(relevant_course_ids)
        for c_id in list(relevant_course_ids):
            c = course_map.get(c_id)
            if c:
                for prereq in c.get("prerequisite_course_ids", []):
                    if prereq in course_map:
                        extended_ids.add(prereq)

        # Topologically sort the courses
        sorted_course_ids, has_cycle = cls.detect_cycles_and_sort(list(extended_ids), course_map)

        # Partition sorted courses into logical progression phases
        # Phase 1: Foundational & Programming Essentials
        # Phase 2: Core Engineering & Systems
        # Phase 3: Advanced Disciplines & Methodologies
        # Phase 4: Specialization & Applied Projects
        phases_definition = [
            {
                "phase_number": 1,
                "title": "Phase 1: Foundational & Computational Thinking",
                "description": "Establish core programming fluency, mathematical reasoning, and version control discipline.",
                "milestone": "Master foundational syntax, algorithms, and git collaboration.",
                "courses": []
            },
            {
                "phase_number": 2,
                "title": "Phase 2: Core Data Structures, Systems & Databases",
                "description": "Build scalable data structures, master relational querying, and understand memory architectures.",
                "milestone": "Design normalized databases and implement optimal algorithmic traversals.",
                "courses": []
            },
            {
                "phase_number": 3,
                "title": "Phase 3: Domain Specialization & Core Technologies",
                "description": "Transition to domain-specific competencies in your selected career path.",
                "milestone": "Develop complete end-to-end applications or machine learning pipelines.",
                "courses": []
            },
            {
                "phase_number": 4,
                "title": "Phase 4: Advanced Systems, Cloud Deployment & Capstone",
                "description": "Enterprise-grade architectures, distributed cloud deployments, and capstone excellence.",
                "milestone": "Deploy production-ready microservices or deep learning models to the cloud.",
                "courses": []
            }
        ]

        total_hours = 0
        currently_satisfied_prereqs = set(completed_set)

        for idx, c_id in enumerate(sorted_course_ids):
            c = course_map.get(c_id)
            if not c:
                continue

            duration = c.get("estimated_duration_hours", 30)
            total_hours += duration
            prereqs = c.get("prerequisite_course_ids", [])

            # Check status
            if c_id in completed_set or user_progress_map.get(c_id) == "completed":
                status = "completed"
                blocked_by = []
            elif user_progress_map.get(c_id) == "in_progress":
                status = "in_progress"
                blocked_by = []
            else:
                missing_for_course = [p for p in prereqs if p not in currently_satisfied_prereqs]
                if missing_for_course:
                    status = "blocked"
                    blocked_by = missing_for_course
                else:
                    status = "planned"
                    blocked_by = []

            # Generate order rationale
            if not prereqs:
                rationale = "Entry-level foundational course without prerequisites; recommended for immediate study."
            elif status == "completed":
                rationale = "Already completed; serves as prerequisite basis for downstream courses."
            else:
                rationale = f"Sequenced after satisfying prerequisite(s): {', '.join(prereqs)}."

            item = {
                "course_id": c_id,
                "title": c.get("title"),
                "category": c.get("category"),
                "duration_hours": duration,
                "difficulty_level": c.get("difficulty_level", "Intermediate"),
                "prerequisites": prereqs,
                "status": status,
                "order_index": idx + 1,
                "blocked_by": blocked_by,
                "rationale": rationale,
                "skills_gained": c.get("skills_gained", []),
                "learning_resource_url": c.get("learning_resource_url")
            }

            # Assign to phase based on level and category
            diff = c.get("difficulty_level")
            c_type = c.get("course_type")
            
            if c_type == "Foundational" or (diff == "Beginner" and idx < 4):
                phases_definition[0]["courses"].append(item)
            elif diff == "Intermediate" and idx < 8:
                phases_definition[1]["courses"].append(item)
            elif diff in ["Intermediate", "Advanced"] and idx < 12:
                phases_definition[2]["courses"].append(item)
            else:
                phases_definition[3]["courses"].append(item)

            if status == "completed":
                currently_satisfied_prereqs.add(c_id)

        # Remove empty phases or ensure balance
        non_empty_phases = [p for p in phases_definition if len(p["courses"]) > 0]
        if not non_empty_phases:
            non_empty_phases = phases_definition[:1]

        # Calculate phase metrics
        for p in non_empty_phases:
            p_hours = sum(c["duration_hours"] for c in p["courses"])
            p["total_hours"] = p_hours
            p["estimated_duration_weeks"] = round(p_hours / weekly_hours, 1)

        estimated_weeks = max(1, round(total_hours / weekly_hours, 1))

        now = datetime.now(timezone.utc)
        roadmap_doc = {
            "user_id": user_id,
            "career_goal": target_career,
            "weekly_hours": weekly_hours,
            "total_hours": total_hours,
            "estimated_weeks": int(estimated_weeks),
            "phases": non_empty_phases,
            "has_circular_dependency": has_cycle,
            "generated_at": now,
            "updated_at": now
        }

        # Persist or update in MongoDB
        db.academic_roadmaps.update_one(
            {"user_id": user_id},
            {"$set": roadmap_doc},
            upsert=True
        )

        roadmap_doc["id"] = user_id
        return roadmap_doc

    @classmethod
    def get_or_generate_roadmap(cls, user_id: str, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Fetches existing roadmap or generates a new one if not yet present."""
        db = get_database()
        existing = db.academic_roadmaps.find_one({"user_id": user_id})
        all_courses = list(db.courses.find({"is_active": True}))

        if not existing:
            return cls.generate_roadmap_for_student(user_id, profile, all_courses)

        existing["id"] = str(existing.get("_id", user_id))
        return existing

    @classmethod
    def modify_roadmap(
        cls, 
        user_id: str, 
        action: str, 
        course_id: Optional[str] = None, 
        target_phase: Optional[int] = None,
        profile: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Supports user customization (add, remove, or reset) while validating prerequisites.
        """
        db = get_database()
        if action == "reset":
            all_courses = list(db.courses.find({"is_active": True}))
            return cls.generate_roadmap_for_student(user_id, profile or {}, all_courses)

        existing = db.academic_roadmaps.find_one({"user_id": user_id})
        if not existing:
            all_courses = list(db.courses.find({"is_active": True}))
            return cls.generate_roadmap_for_student(user_id, profile or {}, all_courses)

        all_courses = {c["course_id"]: c for c in db.courses.find({})}

        if action == "add" and course_id:
            c = all_courses.get(course_id)
            if c:
                # Find if course already exists
                already_present = any(
                    any(cr["course_id"] == course_id for cr in p["courses"])
                    for p in existing["phases"]
                )
                if not already_present:
                    new_item = {
                        "course_id": course_id,
                        "title": c.get("title"),
                        "category": c.get("category"),
                        "duration_hours": c.get("estimated_duration_hours", 30),
                        "difficulty_level": c.get("difficulty_level", "Intermediate"),
                        "prerequisites": c.get("prerequisite_course_ids", []),
                        "status": "planned",
                        "order_index": 99,
                        "blocked_by": [],
                        "rationale": "Manually added by student to study plan.",
                        "skills_gained": c.get("skills_gained", []),
                        "learning_resource_url": c.get("learning_resource_url")
                    }
                    target_p_idx = min(len(existing["phases"]) - 1, (target_phase or 1) - 1)
                    existing["phases"][target_p_idx]["courses"].append(new_item)
                    existing["total_hours"] += new_item["duration_hours"]

        elif action == "remove" and course_id:
            for p in existing["phases"]:
                p["courses"] = [cr for cr in p["courses"] if cr["course_id"] != course_id]

        # Recalculate phase hours and weeks
        w_hours = max(5, existing.get("weekly_hours", 15))
        tot = 0
        for p in existing["phases"]:
            p_h = sum(cr["duration_hours"] for cr in p["courses"])
            p["total_hours"] = p_h
            p["estimated_duration_weeks"] = round(p_h / w_hours, 1)
            tot += p_h
        existing["total_hours"] = tot
        existing["estimated_weeks"] = max(1, round(tot / w_hours, 1))
        existing["updated_at"] = datetime.now(timezone.utc)

        db.academic_roadmaps.update_one({"user_id": user_id}, {"$set": existing})
        existing["id"] = str(existing.get("_id", user_id))
        return existing
