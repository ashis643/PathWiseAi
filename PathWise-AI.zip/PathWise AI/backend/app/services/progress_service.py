import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone, timedelta
from app.database.connection import get_database

logger = logging.getLogger("pathwise.progress")

class ProgressService:
    @classmethod
    def update_course_status(
        cls, 
        user_id: str, 
        course_id: str, 
        status: str, 
        hours_spent: Optional[float] = None,
        notes: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Updates or creates a progress record for a course, ensuring no duplicates.
        When status is 'completed', updates student's completed_courses profile list.
        """
        db = get_database()
        now = datetime.now(timezone.utc)

        existing = db.progress_records.find_one({"user_id": user_id, "course_id": course_id})
        
        update_fields: Dict[str, Any] = {
            "status": status,
            "updated_at": now
        }
        if hours_spent is not None and hours_spent >= 0:
            update_fields["hours_spent"] = hours_spent
        if notes:
            update_fields["notes"] = notes

        if status == "in_progress" and (not existing or not existing.get("started_at")):
            update_fields["started_at"] = now
        elif status == "completed":
            update_fields["completed_at"] = now

        db.progress_records.update_one(
            {"user_id": user_id, "course_id": course_id},
            {"$set": update_fields, "$setOnInsert": {"created_at": now}},
            upsert=True
        )

        # Update profile completed_courses array
        if status == "completed":
            db.student_profiles.update_one(
                {"user_id": user_id},
                {"$addToSet": {"completed_courses": course_id}}
            )
            # Also update any roadmap records marked for this course
            db.academic_roadmaps.update_many(
                {"user_id": user_id, "phases.courses.course_id": course_id},
                {"$set": {"phases.$[].courses.$[c].status": "completed"}},
                array_filters=[{"c.course_id": course_id}]
            )
        elif status in ["not_started", "in_progress"]:
            # If changed back from completed, remove from profile completed_courses
            db.student_profiles.update_one(
                {"user_id": user_id},
                {"$pull": {"completed_courses": course_id}}
            )

        updated_record = db.progress_records.find_one({"user_id": user_id, "course_id": course_id})
        updated_record["id"] = str(updated_record["_id"])
        updated_record["_id"] = str(updated_record["_id"])
        return updated_record

    @classmethod
    def log_study_hours(
        cls, 
        user_id: str, 
        course_id: str, 
        hours: float, 
        notes: str = "",
        study_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """Logs daily/session study hours for a course and updates total hours spent."""
        db = get_database()
        now = datetime.now(timezone.utc)
        date_str = study_date or now.strftime("%Y-%m-%d")

        log_doc = {
            "user_id": user_id,
            "course_id": course_id,
            "hours": round(hours, 2),
            "notes": notes,
            "study_date": date_str,
            "created_at": now
        }
        res = db.study_logs.insert_one(log_doc)
        log_doc["id"] = str(res.inserted_id)
        log_doc["_id"] = str(res.inserted_id)

        # Increment total hours in progress_records
        db.progress_records.update_one(
            {"user_id": user_id, "course_id": course_id},
            {
                "$inc": {"hours_spent": hours},
                "$set": {"updated_at": now},
                "$setOnInsert": {"status": "in_progress", "started_at": now, "created_at": now}
            },
            upsert=True
        )

        return log_doc

    @classmethod
    def get_progress_summary(cls, user_id: str) -> Dict[str, Any]:
        """Generates comprehensive progress metrics, weekly study hours, and recent activity logs."""
        db = get_database()
        records = list(db.progress_records.find({"user_id": user_id}))

        completed_count = sum(1 for r in records if r.get("status") == "completed")
        in_progress_count = sum(1 for r in records if r.get("status") == "in_progress")
        not_started_count = sum(1 for r in records if r.get("status") == "not_started")
        total_hours = sum(r.get("hours_spent", 0.0) for r in records)

        # Calculate current week hours from study_logs
        seven_days_ago = datetime.now(timezone.utc) - timedelta(days=7)
        recent_logs_cursor = db.study_logs.find(
            {"user_id": user_id, "created_at": {"$gte": seven_days_ago}}
        )
        current_week_hours = sum(l.get("hours", 0.0) for l in recent_logs_cursor)

        profile = db.student_profiles.find_one({"user_id": user_id})
        weekly_goal = profile.get("available_study_hours_per_week", 15) if profile else 15

        # Fetch recent logs with course titles
        all_logs = list(db.study_logs.find({"user_id": user_id}).sort([("created_at", -1)]).limit(10))
        course_ids = list(set(l["course_id"] for l in all_logs))
        courses_map = {c["course_id"]: c["title"] for c in db.courses.find({"course_id": {"$in": course_ids}})}

        formatted_logs = []
        for l in all_logs:
            formatted_logs.append({
                "id": str(l["_id"]),
                "user_id": user_id,
                "course_id": l["course_id"],
                "course_title": courses_map.get(l["course_id"], l["course_id"]),
                "hours": l.get("hours", 0.0),
                "notes": l.get("notes", ""),
                "study_date": l.get("study_date", ""),
                "created_at": l.get("created_at")
            })

        # Roadmap completion percentage
        roadmap = db.academic_roadmaps.find_one({"user_id": user_id})
        roadmap_completion_pct = 0.0
        if roadmap and roadmap.get("phases"):
            all_r_courses = [c for p in roadmap["phases"] for c in p.get("courses", [])]
            if all_r_courses:
                r_comp = sum(1 for c in all_r_courses if c.get("status") == "completed" or c.get("course_id") in [r["course_id"] for r in records if r.get("status") == "completed"])
                roadmap_completion_pct = round((r_comp / len(all_r_courses)) * 100, 1)

        return {
            "total_enrolled": len(records),
            "completed_count": completed_count,
            "in_progress_count": in_progress_count,
            "not_started_count": not_started_count,
            "total_hours_logged": round(total_hours, 1),
            "weekly_goal_hours": weekly_goal,
            "current_week_hours": round(current_week_hours, 1),
            "roadmap_completion_percentage": roadmap_completion_pct,
            "recent_logs": formatted_logs
        }
