import logging
from typing import List, Dict, Any, Tuple
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from app.core.config import settings
from app.database.connection import get_database

logger = logging.getLogger("pathwise.recommendation")

class RecommendationService:
    @staticmethod
    def _compute_career_relevance(course: Dict[str, Any], target_career: str) -> float:
        """Computes relevance of course to student's target career (0.0 to 1.0)."""
        if not target_career:
            return 0.5  # Neutral default
        career_tags = [c.lower() for c in course.get("career_relevance", [])]
        target_lower = target_career.lower()
        if target_lower in career_tags:
            return 1.0
        # Partial keyword match
        target_tokens = set(target_lower.split())
        for tag in career_tags:
            tag_tokens = set(tag.split())
            if target_tokens.intersection(tag_tokens):
                return 0.75
        return 0.1

    @staticmethod
    def _compute_target_skill_fit(course: Dict[str, Any], target_skills: List[str]) -> float:
        """Computes overlap between course skills gained and student's target skills (0.0 to 1.0)."""
        if not target_skills:
            return 0.5
        course_skills = set(s.lower() for s in course.get("skills_gained", []))
        user_targets = set(s.lower() for s in target_skills)
        matched = course_skills.intersection(user_targets)
        if not user_targets:
            return 0.5
        # Ratio of matched targets, boosted if course provides key target skills
        overlap_ratio = len(matched) / len(user_targets)
        return min(1.0, overlap_ratio * 1.5) if matched else 0.05

    @staticmethod
    def _compute_interest_alignment(course: Dict[str, Any], areas_of_interest: List[str]) -> float:
        """Uses TF-IDF semantic cosine similarity between student interests and course text."""
        if not areas_of_interest:
            return 0.5
        
        user_interest_text = " ".join(areas_of_interest).lower()
        course_text = f"{course.get('title', '')} {course.get('category', '')} {course.get('short_description', '')} {' '.join(course.get('skills_gained', []))}".lower()
        
        try:
            vectorizer = TfidfVectorizer(stop_words='english')
            tfidf_matrix = vectorizer.fit_transform([user_interest_text, course_text])
            sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            # Rescale similarity (0.0 to 1.0)
            return float(min(1.0, max(0.05, sim * 2.2)))
        except Exception:
            # Fallback simple keyword match
            course_lower = course_text.lower()
            matches = sum(1 for interest in areas_of_interest if interest.lower() in course_lower)
            return min(1.0, matches / max(1, len(areas_of_interest)))

    @staticmethod
    def _compute_skill_gap_fit(course: Dict[str, Any], technical_skills: List[str], target_skills: List[str]) -> float:
        """Measures whether the course fills a genuine missing gap (high if student lacks the skill)."""
        current_skills_set = set(s.lower() for s in technical_skills)
        course_skills = set(s.lower() for s in course.get("skills_gained", []))
        
        # New skills gained that student doesn't have yet
        genuinely_new = course_skills - current_skills_set
        if not course_skills:
            return 0.2
        new_ratio = len(genuinely_new) / len(course_skills)
        
        # If any of the new skills are in target_skills, boost
        target_set = set(s.lower() for s in target_skills)
        gap_targets = genuinely_new.intersection(target_set)
        if gap_targets:
            return min(1.0, 0.4 + (0.6 * (len(gap_targets) / max(1, len(target_set)))))
        
        return float(new_ratio * 0.8)

    @staticmethod
    def _compute_progression_fit(course: Dict[str, Any], completed_courses: List[str], current_skills: List[str]) -> float:
        """Measures whether the student has the prerequisite background and foundational skills."""
        prereqs = course.get("prerequisite_course_ids", [])
        if not prereqs:
            # No prerequisites needed: ideal foundational entry
            return 0.95
        
        completed_set = set(completed_courses)
        prereqs_met = sum(1 for p in prereqs if p in completed_set)
        if prereqs_met == len(prereqs):
            # All prerequisites fulfilled!
            return 1.0
        elif prereqs_met > 0:
            # Partially fulfilled
            return 0.5 * (prereqs_met / len(prereqs))
        else:
            return 0.1

    @staticmethod
    def _compute_difficulty_study_fit(course: Dict[str, Any], preferred_difficulty: str, weekly_hours: int) -> float:
        """Evaluates whether the course matches the student's study availability and difficulty level."""
        course_diff = course.get("difficulty_level", "Intermediate")
        diff_score = 0.5
        if preferred_difficulty == course_diff:
            diff_score = 1.0
        elif (preferred_difficulty == "Intermediate" and course_diff in ["Beginner", "Advanced"]):
            diff_score = 0.75
        elif (preferred_difficulty == "Beginner" and course_diff == "Intermediate") or (preferred_difficulty == "Advanced" and course_diff == "Intermediate"):
            diff_score = 0.65
        else:
            diff_score = 0.35

        # Study time feasibility: estimated duration vs weekly study hours
        duration = course.get("estimated_duration_hours", 30)
        # Assuming typical course completion over 3 to 6 weeks
        weekly_demand = duration / 4.0
        if weekly_demand <= weekly_hours:
            time_score = 1.0
        elif weekly_demand <= weekly_hours * 1.5:
            time_score = 0.7
        else:
            time_score = 0.4

        return (diff_score * 0.6) + (time_score * 0.4)

    @classmethod
    def generate_explanation(
        cls, 
        course: Dict[str, Any], 
        breakdown: Dict[str, float], 
        target_career: str, 
        target_skills: List[str],
        missing_prereqs: List[str]
    ) -> str:
        """Generates clear, natural language explanation of why the course was recommended."""
        reasons = []
        if breakdown["career_goal_fit"] >= 0.75:
            reasons.append(f"Directly relevant to your target career as an {target_career}")
        
        matched_targets = [s for s in course.get("skills_gained", []) if s.lower() in [t.lower() for t in target_skills]]
        if matched_targets:
            reasons.append(f"Teaches target competencies you want to acquire: {', '.join(matched_targets[:3])}")
        
        if breakdown["interest_fit"] >= 0.7:
            reasons.append(f"Aligns strongly with your declared learning interests in {course.get('category')}")
            
        if breakdown["progression_fit"] >= 0.9 and course.get("prerequisite_course_ids"):
            reasons.append("You have completed all prerequisite courses and have optimal foundational readiness")
            
        if missing_prereqs:
            reasons.append(f"Requires completing prerequisite course(s) first: {', '.join(missing_prereqs)}")
            
        if not reasons:
            reasons.append(f"Provides foundational skills in {course.get('category')} suitable for your academic curriculum")

        return ". ".join(reasons) + "."

    @classmethod
    def calculate_recommendations(
        cls, 
        profile: Dict[str, Any], 
        courses: List[Dict[str, Any]],
        limit: int = 10
    ) -> Dict[str, Any]:
        """
        Executes the content-based explainable recommendation algorithm.
        Returns top eligible recommendations and separate prerequisite-blocked courses.
        """
        completed = set(profile.get("completed_courses", []))
        technical_skills = profile.get("technical_skills", [])
        target_skills = profile.get("target_skills", [])
        areas_of_interest = profile.get("areas_of_interest", [])
        target_career = profile.get("target_career", "AI/ML Engineer")
        preferred_diff = profile.get("preferred_difficulty", "Intermediate")
        weekly_hours = profile.get("available_study_hours_per_week", 15)

        # Check if profile is sparse
        insufficient_notice = None
        if not technical_skills and not target_skills and not areas_of_interest:
            insufficient_notice = "Your profile has limited skill and interest data. Recommendations are currently using foundational defaults. Complete your profile onboarding for tailored precision."

        weights = {
            "career_goal": settings.WEIGHT_CAREER_GOAL,
            "target_skill": settings.WEIGHT_TARGET_SKILL,
            "interest": settings.WEIGHT_INTEREST_ALIGNMENT,
            "skill_gap": settings.WEIGHT_SKILL_GAP,
            "progression": settings.WEIGHT_PROGRESSION_FIT,
            "difficulty_study": settings.WEIGHT_DIFFICULTY_STUDY_TIME
        }

        eligible_list = []
        blocked_list = []

        for course in courses:
            c_id = course.get("course_id")
            # 1. Exclude completed courses from recommendations!
            if c_id in completed:
                continue

            prereqs = course.get("prerequisite_course_ids", [])
            missing_prereqs = [p for p in prereqs if p not in completed]
            is_prereq_met = len(missing_prereqs) == 0

            # Compute individual sub-scores (0.0 to 1.0)
            career_fit = cls._compute_career_relevance(course, target_career)
            target_skill_fit = cls._compute_target_skill_fit(course, target_skills)
            interest_fit = cls._compute_interest_alignment(course, areas_of_interest)
            gap_fit = cls._compute_skill_gap_fit(course, technical_skills, target_skills)
            progression_fit = cls._compute_progression_fit(course, list(completed), technical_skills)
            diff_study_fit = cls._compute_difficulty_study_fit(course, preferred_diff, weekly_hours)

            # Normalized weighted sum
            raw_score = (
                (weights["career_goal"] * career_fit) +
                (weights["target_skill"] * target_skill_fit) +
                (weights["interest"] * interest_fit) +
                (weights["skill_gap"] * gap_fit) +
                (weights["progression"] * progression_fit) +
                (weights["difficulty_study"] * diff_study_fit)
            )

            # Convert to 0 - 100 percentage
            final_score = round(raw_score * 100, 1)

            breakdown_dict = {
                "career_goal_fit": round(career_fit * 100, 1),
                "target_skill_fit": round(target_skill_fit * 100, 1),
                "interest_fit": round(interest_fit * 100, 1),
                "skill_gap_fit": round(gap_fit * 100, 1),
                "progression_fit": round(progression_fit * 100, 1),
                "difficulty_study_fit": round(diff_study_fit * 100, 1),
            }

            explanation = cls.generate_explanation(
                course, 
                {
                    "career_goal_fit": career_fit,
                    "target_skill_fit": target_skill_fit,
                    "interest_fit": interest_fit,
                    "skill_gap_fit": gap_fit,
                    "progression_fit": progression_fit,
                    "difficulty_study_fit": diff_study_fit
                },
                target_career,
                target_skills,
                missing_prereqs
            )

            item = {
                "course_id": c_id,
                "title": course.get("title"),
                "category": course.get("category"),
                "difficulty_level": course.get("difficulty_level"),
                "estimated_duration_hours": course.get("estimated_duration_hours"),
                "recommendation_score": final_score,
                "score_breakdown": breakdown_dict,
                "skills_gained": course.get("skills_gained", []),
                "career_relevance": course.get("career_relevance", []),
                "prerequisites": prereqs,
                "is_prerequisite_met": is_prereq_met,
                "missing_prerequisites": missing_prereqs,
                "explanation": explanation,
                "course_type": course.get("course_type", "Core"),
                "learning_resource_url": course.get("learning_resource_url"),
                "user_status": "not_started"
            }

            if is_prereq_met:
                eligible_list.append(item)
            else:
                blocked_list.append(item)

        # Sort both lists descending by recommendation_score
        eligible_list.sort(key=lambda x: x["recommendation_score"], reverse=True)
        blocked_list.sort(key=lambda x: x["recommendation_score"], reverse=True)

        return {
            "student_career_goal": target_career,
            "profile_completion_percentage": profile.get("completion_percentage", 0),
            "weights_used": weights,
            "total_eligible": len(eligible_list),
            "top_recommendations": eligible_list[:limit],
            "prerequisite_blocked_courses": blocked_list[:6],
            "insufficient_profile_notice": insufficient_notice
        }
