import logging
from typing import List, Dict, Any, Optional
from app.database.connection import get_database

logger = logging.getLogger("pathwise.skill_gap")

# Career Skill Profiles with transparent importance weighting and target levels
CAREER_PROFILES: Dict[str, Dict[str, Any]] = {
    "AI/ML Engineer": {
        "title": "AI/ML Engineer",
        "description": "Designs and deploys scalable machine learning models, deep neural networks, and AI architectures.",
        "skills": [
            {"name": "Python", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "Linear Algebra", "priority": "High", "target_level": "Core", "weight": 1.0},
            {"name": "Probability Theory", "priority": "High", "target_level": "Core", "weight": 1.0},
            {"name": "Scikit-Learn", "priority": "High", "target_level": "Advanced", "weight": 1.1},
            {"name": "PyTorch", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "Deep Learning", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "Data Structures", "priority": "Medium", "target_level": "Core", "weight": 0.9},
            {"name": "Pandas", "priority": "Medium", "target_level": "Core", "weight": 0.8},
            {"name": "MLOps", "priority": "Medium", "target_level": "Core", "weight": 0.8},
            {"name": "Docker", "priority": "Low", "target_level": "Foundational", "weight": 0.6},
        ]
    },
    "Data Analyst": {
        "title": "Data Analyst",
        "description": "Transforms raw enterprise data into actionable visual insights, exploratory analysis, and business intelligence.",
        "skills": [
            {"name": "SQL", "priority": "High", "target_level": "Advanced", "weight": 1.3},
            {"name": "Python", "priority": "High", "target_level": "Core", "weight": 1.1},
            {"name": "Pandas", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "Data Visualization", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "Inferential Statistics", "priority": "Medium", "target_level": "Core", "weight": 1.0},
            {"name": "Exploratory Data Analysis", "priority": "Medium", "target_level": "Core", "weight": 0.9},
            {"name": "Executive Dashboards", "priority": "Medium", "target_level": "Core", "weight": 0.8},
            {"name": "PostgreSQL", "priority": "Low", "target_level": "Core", "weight": 0.7},
            {"name": "Technical Writing", "priority": "Low", "target_level": "Foundational", "weight": 0.6},
        ]
    },
    "Software Engineer": {
        "title": "Software Engineer",
        "description": "Architects, develops, tests, and maintains scalable software applications, backend services, and algorithms.",
        "skills": [
            {"name": "Data Structures", "priority": "High", "target_level": "Advanced", "weight": 1.3},
            {"name": "Object-Oriented Design", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "Python", "priority": "High", "target_level": "Core", "weight": 1.0},
            {"name": "SQL", "priority": "High", "target_level": "Core", "weight": 1.0},
            {"name": "REST APIs", "priority": "High", "target_level": "Advanced", "weight": 1.1},
            {"name": "Git", "priority": "Medium", "target_level": "Core", "weight": 0.9},
            {"name": "React", "priority": "Medium", "target_level": "Core", "weight": 0.9},
            {"name": "TypeScript", "priority": "Medium", "target_level": "Core", "weight": 0.8},
            {"name": "CI/CD", "priority": "Low", "target_level": "Foundational", "weight": 0.7},
            {"name": "Docker", "priority": "Low", "target_level": "Foundational", "weight": 0.7},
        ]
    },
    "Cloud/DevOps Engineer": {
        "title": "Cloud/DevOps Engineer",
        "description": "Builds resilient cloud infrastructure, automates CI/CD deployment pipelines, and manages container orchestration.",
        "skills": [
            {"name": "Linux", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "Docker", "priority": "High", "target_level": "Advanced", "weight": 1.3},
            {"name": "Kubernetes", "priority": "High", "target_level": "Advanced", "weight": 1.3},
            {"name": "AWS", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "CI/CD", "priority": "High", "target_level": "Core", "weight": 1.1},
            {"name": "Terraform", "priority": "Medium", "target_level": "Core", "weight": 1.0},
            {"name": "Bash Scripting", "priority": "Medium", "target_level": "Core", "weight": 0.9},
            {"name": "Git", "priority": "Medium", "target_level": "Core", "weight": 0.8},
            {"name": "Network Security", "priority": "Low", "target_level": "Core", "weight": 0.7},
        ]
    },
    "Cybersecurity Analyst": {
        "title": "Cybersecurity Analyst",
        "description": "Protects organizational systems, monitors network anomalies, conducts vulnerability audits, and coordinates incident response.",
        "skills": [
            {"name": "Security Principles", "priority": "High", "target_level": "Advanced", "weight": 1.3},
            {"name": "Network Security", "priority": "High", "target_level": "Advanced", "weight": 1.3},
            {"name": "Application Security", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "OWASP Top 10", "priority": "High", "target_level": "Advanced", "weight": 1.2},
            {"name": "Linux", "priority": "Medium", "target_level": "Core", "weight": 1.0},
            {"name": "Wireshark", "priority": "Medium", "target_level": "Core", "weight": 0.9},
            {"name": "SIEM", "priority": "Medium", "target_level": "Core", "weight": 0.9},
            {"name": "Incident Response", "priority": "Medium", "target_level": "Core", "weight": 0.9},
            {"name": "Penetration Testing", "priority": "Low", "target_level": "Foundational", "weight": 0.8},
        ]
    }
}

class SkillGapService:
    @classmethod
    def get_career_profiles(cls) -> List[Dict[str, Any]]:
        return list(CAREER_PROFILES.values())

    @classmethod
    def analyze_student_gaps(
        cls, 
        profile: Dict[str, Any], 
        career_override: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Calculates skill gap breakdown, coverage percentage, and maps
        gap-closing courses from the active catalog.
        """
        db = get_database()
        target_career = career_override or profile.get("target_career", "AI/ML Engineer")
        career_spec = CAREER_PROFILES.get(target_career, CAREER_PROFILES["AI/ML Engineer"])

        # Student's acquired skills (from self-reported technical_skills and completed courses)
        user_skills = set(s.lower() for s in profile.get("technical_skills", []))
        completed_course_ids = profile.get("completed_courses", [])
        if completed_course_ids:
            completed_docs = db.courses.find({"course_id": {"$in": completed_course_ids}})
            for cd in completed_docs:
                for sk in cd.get("skills_gained", []):
                    user_skills.add(sk.lower())

        required_skills = career_spec["skills"]
        total_weighted_points = sum(s["weight"] for s in required_skills)
        acquired_weighted_points = 0.0

        skill_gap_items = []
        missing_skills_list = []
        skills_to_improve_list = []
        existing_skills_list = []

        all_courses = list(db.courses.find({"is_active": True}))

        for req in required_skills:
            s_name = req["name"]
            s_lower = s_name.lower()
            weight = req["weight"]
            priority = req["priority"]
            target_level = req["target_level"]

            is_present = s_lower in user_skills
            # Check if partially acquired (e.g. substring match)
            is_partial = False
            if not is_present:
                for us in user_skills:
                    if us in s_lower or s_lower in us:
                        is_partial = True
                        break

            # Find courses that teach this missing skill
            related_courses = []
            for c in all_courses:
                course_skills = [sk.lower() for sk in c.get("skills_gained", [])]
                if s_lower in course_skills or any(s_lower in c_sk for c_sk in course_skills):
                    related_courses.append({
                        "course_id": c["course_id"],
                        "title": c["title"],
                        "difficulty": c["difficulty_level"],
                        "duration_hours": str(c["estimated_duration_hours"])
                    })

            if is_present:
                current_status = "acquired"
                acquired_weighted_points += weight
                existing_skills_list.append(s_name)
            elif is_partial:
                current_status = "developing"
                acquired_weighted_points += (weight * 0.5)
                skills_to_improve_list.append(s_name)
            else:
                current_status = "missing"
                missing_skills_list.append(s_name)

            skill_gap_items.append({
                "skill_name": s_name,
                "priority": priority,
                "current_status": current_status,
                "target_proficiency": target_level,
                "is_missing": (current_status != "acquired"),
                "importance_weight": weight,
                "related_course_ids": [rc["course_id"] for rc in related_courses[:3]],
                "related_courses": related_courses[:3]
            })

        # Calculate coverage and career readiness estimates
        coverage_pct = round((len(existing_skills_list) / max(1, len(required_skills))) * 100, 1)
        readiness_pct = round((acquired_weighted_points / max(0.1, total_weighted_points)) * 100, 1)

        # Prioritize courses that close the most critical missing gaps
        course_gap_score = {}
        for item in skill_gap_items:
            if item["is_missing"]:
                p_mult = 1.5 if item["priority"] == "High" else (1.0 if item["priority"] == "Medium" else 0.7)
                for rc in item["related_courses"]:
                    cid = rc["course_id"]
                    course_gap_score[cid] = course_gap_score.get(cid, 0.0) + p_mult

        top_gap_courses = []
        for cid, sc in sorted(course_gap_score.items(), key=lambda x: x[1], reverse=True)[:5]:
            c_doc = next((c for c in all_courses if c["course_id"] == cid), None)
            if c_doc:
                top_gap_courses.append({
                    "course_id": cid,
                    "title": c_doc["title"],
                    "skills_gained": ", ".join(c_doc.get("skills_gained", [])[:3]),
                    "difficulty": c_doc["difficulty_level"],
                    "gap_impact": "High Impact" if sc >= 2.0 else "Targeted Impact"
                })

        return {
            "career_goal": target_career,
            "overall_readiness_percentage": readiness_pct,
            "skill_coverage_percentage": coverage_pct,
            "total_required_skills": len(required_skills),
            "acquired_skills_count": len(existing_skills_list),
            "missing_skills_count": len(missing_skills_list),
            "existing_skills": existing_skills_list,
            "missing_skills": missing_skills_list,
            "skills_to_improve": skills_to_improve_list,
            "skill_gaps": skill_gap_items,
            "top_gap_closing_courses": top_gap_courses,
            "methodology_note": "Readiness scores are explainable estimates calculated by weighting your self-reported skills and verified completed coursework against the industry competency benchmark for this career."
        }
