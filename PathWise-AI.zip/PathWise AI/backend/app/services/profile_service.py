import logging
from typing import Dict, Any, Optional
from datetime import datetime, timezone
from bson import ObjectId
from app.database.connection import get_database

logger = logging.getLogger("pathwise.profiles")

class ProfileService:
    @staticmethod
    def calculate_completion(profile: Dict[str, Any]) -> int:
        """Calculates profile completion percentage based on field completeness."""
        weights = {
            "full_name": 10,
            "university": 5,
            "degree_program": 5,
            "department": 5,
            "current_semester": 5,
            "target_career": 20,
            "technical_skills": 15,
            "target_skills": 15,
            "areas_of_interest": 10,
            "available_study_hours_per_week": 5,
            "preferred_difficulty": 5,
        }
        total_score = 0
        for field, weight in weights.items():
            val = profile.get(field)
            if val is not None:
                if isinstance(val, list):
                    if len(val) > 0:
                        total_score += weight
                elif isinstance(val, (int, float)):
                    if val > 0:
                        total_score += weight
                elif isinstance(val, str) and val.strip():
                    total_score += weight
        return min(100, total_score)

    @classmethod
    def get_or_create_profile(cls, user_id: str, email: str, full_name: str) -> Dict[str, Any]:
        """Retrieves user profile or initializes a default profile for first-time login."""
        db = get_database()
        profile = db.student_profiles.find_one({"user_id": user_id})
        now = datetime.now(timezone.utc)
        
        if not profile:
            default_doc = {
                "user_id": user_id,
                "email": email,
                "full_name": full_name,
                "university": "State University",
                "degree_program": "B.S. in Computer Science",
                "department": "Computer Science & Engineering",
                "current_semester": 1,
                "current_cgpa": None,
                "technical_skills": [],
                "soft_skills": [],
                "areas_of_interest": [],
                "completed_courses": [],
                "target_career": "AI/ML Engineer",
                "target_skills": [],
                "preferred_difficulty": "Intermediate",
                "available_study_hours_per_week": 15,
                "preferred_learning_pace": "Balanced",
                "is_onboarding_completed": False,
                "created_at": now,
                "updated_at": now
            }
            res = db.student_profiles.insert_one(default_doc)
            default_doc["id"] = str(res.inserted_id)
            default_doc["completion_percentage"] = cls.calculate_completion(default_doc)
            return default_doc

        profile["id"] = str(profile["_id"])
        profile["completion_percentage"] = cls.calculate_completion(profile)
        return profile

    @classmethod
    def update_profile(cls, user_id: str, update_data: Dict[str, Any]) -> Dict[str, Any]:
        """Updates a student's profile and recalculates completion status."""
        db = get_database()
        clean_data = {k: v for k, v in update_data.items() if v is not None}
        clean_data["updated_at"] = datetime.now(timezone.utc)
        
        updated_doc = db.student_profiles.find_one_and_update(
            {"user_id": user_id},
            {"$set": clean_data},
            return_document=True
        )
        if not updated_doc:
            raise ValueError("Student profile not found.")

        updated_doc["id"] = str(updated_doc["_id"])
        updated_doc["completion_percentage"] = cls.calculate_completion(updated_doc)
        return updated_doc

    @classmethod
    def get_profile_by_user_id(cls, user_id: str) -> Optional[Dict[str, Any]]:
        """Retrieves student profile by user_id."""
        db = get_database()
        profile = db.student_profiles.find_one({"user_id": user_id})
        if not profile:
            return None
        profile["id"] = str(profile["_id"])
        profile["completion_percentage"] = cls.calculate_completion(profile)
        return profile
