from pydantic import BaseModel
from typing import List, Dict, Optional

class SkillGapItem(BaseModel):
    skill_name: str
    priority: str  # High, Medium, Low
    current_status: str  # acquired, developing, missing
    target_proficiency: str  # Proficient, Advanced, Core
    is_missing: bool
    importance_weight: float
    related_course_ids: List[str]
    related_courses: List[Dict[str, str]]

class SkillGapAnalysisResponse(BaseModel):
    career_goal: str
    overall_readiness_percentage: float
    skill_coverage_percentage: float
    total_required_skills: int
    acquired_skills_count: int
    missing_skills_count: int
    existing_skills: List[str]
    missing_skills: List[str]
    skills_to_improve: List[str]
    skill_gaps: List[SkillGapItem]
    top_gap_closing_courses: List[Dict[str, str]]
    methodology_note: str
