from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class CourseStatusUpdate(BaseModel):
    course_id: str
    status: str = Field(..., pattern="^(not_started|in_progress|completed)$")
    hours_spent: Optional[float] = Field(default=None, ge=0.0)
    notes: Optional[str] = None

class StudyLogCreate(BaseModel):
    course_id: str
    hours: float = Field(..., gt=0.0, le=24.0)
    notes: Optional[str] = Field(default="", max_length=200)
    study_date: Optional[str] = None

class StudyLogResponse(BaseModel):
    id: str
    user_id: str
    course_id: str
    course_title: Optional[str] = None
    hours: float
    notes: str
    study_date: str
    created_at: Optional[datetime] = None

class ProgressSummaryResponse(BaseModel):
    total_enrolled: int
    completed_count: int
    in_progress_count: int
    not_started_count: int
    total_hours_logged: float
    weekly_goal_hours: int
    current_week_hours: float
    roadmap_completion_percentage: float
    recent_logs: List[StudyLogResponse]
