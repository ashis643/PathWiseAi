from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime

class StudentProfileBase(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    university: str = Field(default="State University", max_length=150)
    degree_program: str = Field(default="B.S. in Computer Science", max_length=150)
    department: str = Field(default="Computer Science & Engineering", max_length=150)
    current_semester: int = Field(default=1, ge=1, le=12)
    current_cgpa: Optional[float] = Field(default=None, ge=0.0, le=10.0)
    technical_skills: List[str] = Field(default_factory=list)
    soft_skills: List[str] = Field(default_factory=list)
    areas_of_interest: List[str] = Field(default_factory=list)
    completed_courses: List[str] = Field(default_factory=list)
    target_career: str = Field(default="AI/ML Engineer")
    target_skills: List[str] = Field(default_factory=list)
    preferred_difficulty: str = Field(default="Intermediate", pattern="^(Beginner|Intermediate|Advanced)$")
    available_study_hours_per_week: int = Field(default=15, ge=1, le=80)
    preferred_learning_pace: str = Field(default="Balanced", pattern="^(Relaxed|Balanced|Intensive)$")
    is_onboarding_completed: bool = Field(default=False)

class StudentProfileCreate(StudentProfileBase):
    pass

class StudentProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    university: Optional[str] = None
    degree_program: Optional[str] = None
    department: Optional[str] = None
    current_semester: Optional[int] = Field(default=None, ge=1, le=12)
    current_cgpa: Optional[float] = Field(default=None, ge=0.0, le=10.0)
    technical_skills: Optional[List[str]] = None
    soft_skills: Optional[List[str]] = None
    areas_of_interest: Optional[List[str]] = None
    completed_courses: Optional[List[str]] = None
    target_career: Optional[str] = None
    target_skills: Optional[List[str]] = None
    preferred_difficulty: Optional[str] = Field(default=None, pattern="^(Beginner|Intermediate|Advanced)$")
    available_study_hours_per_week: Optional[int] = Field(default=None, ge=1, le=80)
    preferred_learning_pace: Optional[str] = Field(default=None, pattern="^(Relaxed|Balanced|Intensive)$")
    is_onboarding_completed: Optional[bool] = None

class StudentProfileResponse(StudentProfileBase):
    id: str
    user_id: str
    completion_percentage: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
