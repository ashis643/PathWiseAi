from pydantic import BaseModel
from typing import List, Optional, Dict

class ScoreBreakdown(BaseModel):
    career_goal_fit: float
    target_skill_fit: float
    interest_fit: float
    skill_gap_fit: float
    progression_fit: float
    difficulty_study_fit: float

class RecommendedCourseItem(BaseModel):
    course_id: str
    title: str
    category: str
    difficulty_level: str
    estimated_duration_hours: int
    recommendation_score: float  # 0 to 100
    score_breakdown: ScoreBreakdown
    skills_gained: List[str]
    career_relevance: List[str]
    prerequisites: List[str]
    is_prerequisite_met: bool
    missing_prerequisites: List[str]
    explanation: str
    course_type: str
    learning_resource_url: Optional[str] = None
    user_status: str = "not_started"  # not_started, in_progress, completed

class RecommendationResponse(BaseModel):
    student_career_goal: str
    profile_completion_percentage: int
    weights_used: Dict[str, float]
    total_eligible: int
    top_recommendations: List[RecommendedCourseItem]
    prerequisite_blocked_courses: List[RecommendedCourseItem]
    insufficient_profile_notice: Optional[str] = None
