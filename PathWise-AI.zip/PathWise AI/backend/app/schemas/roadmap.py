from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class RoadmapPhaseCourse(BaseModel):
    course_id: str
    title: str
    category: str
    duration_hours: int
    difficulty_level: str
    prerequisites: List[str] = Field(default_factory=list)
    status: str = "planned"  # planned, in_progress, completed, blocked
    order_index: int
    blocked_by: List[str] = Field(default_factory=list)
    rationale: str
    skills_gained: List[str] = Field(default_factory=list)
    learning_resource_url: Optional[str] = None

class RoadmapPhase(BaseModel):
    phase_number: int
    title: str
    description: str
    milestone: str
    estimated_duration_weeks: float
    total_hours: int
    courses: List[RoadmapPhaseCourse]

class AcademicRoadmapResponse(BaseModel):
    id: Optional[str] = None
    user_id: str
    career_goal: str
    weekly_hours: int
    total_hours: int
    estimated_weeks: int
    phases: List[RoadmapPhase]
    generated_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class RoadmapUpdateRequest(BaseModel):
    action: str = Field(..., pattern="^(add|remove|reorder|reset)$")
    course_id: Optional[str] = None
    target_phase: Optional[int] = None
    new_order: Optional[List[str]] = None
