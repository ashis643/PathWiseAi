from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class CourseBase(BaseModel):
    course_id: str = Field(..., description="Unique course identifier e.g. CS101, ML201")
    title: str = Field(..., min_length=3, max_length=150)
    short_description: str = Field(..., min_length=10, max_length=500)
    category: str = Field(...)
    difficulty_level: str = Field(..., pattern="^(Beginner|Intermediate|Advanced)$")
    estimated_duration_hours: int = Field(..., ge=1, le=200)
    prerequisite_course_ids: List[str] = Field(default_factory=list)
    required_skills: List[str] = Field(default_factory=list)
    skills_gained: List[str] = Field(default_factory=list)
    career_relevance: List[str] = Field(default_factory=list)
    learning_objectives: List[str] = Field(default_factory=list)
    course_type: str = Field(default="Core", pattern="^(Foundational|Core|Specialization|Elective)$")
    learning_resource_url: Optional[str] = None
    is_active: bool = True

class CourseCreate(CourseBase):
    pass

class CourseUpdate(BaseModel):
    title: Optional[str] = None
    short_description: Optional[str] = None
    category: Optional[str] = None
    difficulty_level: Optional[str] = Field(default=None, pattern="^(Beginner|Intermediate|Advanced)$")
    estimated_duration_hours: Optional[int] = Field(default=None, ge=1, le=200)
    prerequisite_course_ids: Optional[List[str]] = None
    required_skills: Optional[List[str]] = None
    skills_gained: Optional[List[str]] = None
    career_relevance: Optional[List[str]] = None
    learning_objectives: Optional[List[str]] = None
    course_type: Optional[str] = Field(default=None, pattern="^(Foundational|Core|Specialization|Elective)$")
    learning_resource_url: Optional[str] = None
    is_active: Optional[bool] = None

class CourseResponse(CourseBase):
    id: str
    user_status: Optional[str] = "not_started"  # not_started, in_progress, completed
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class CourseFilterQuery(BaseModel):
    search: Optional[str] = None
    category: Optional[str] = None
    difficulty: Optional[str] = None
    skills: Optional[List[str]] = None
    max_duration: Optional[int] = None
    sort_by: Optional[str] = "relevance"  # relevance, duration_asc, duration_desc, difficulty, title
    page: int = 1
    page_size: int = 12
