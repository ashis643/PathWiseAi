import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.core.config import settings
from app.database.connection import db_manager
from app.api import auth, profiles, courses, recommendations, roadmaps, skill_gaps, progress, dashboard

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("pathwise.main")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Connect to MongoDB
    logger.info("Initializing PathWise AI Backend...")
    try:
        db_manager.connect()
    except Exception as e:
        logger.error(f"Could not connect to MongoDB at startup: {e}")
    yield
    # Shutdown: Close database connection
    logger.info("Shutting down PathWise AI Backend...")
    db_manager.close()

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Intelligent Course Recommendation & Academic Path Planning System — FastAPI Backend",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Exception Handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception on {request.method} {request.url}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "An internal server error occurred. Please try again later."}
    )

# Include API Routers under settings.API_V1_STR ("/api")
api_prefix = settings.API_V1_STR
app.include_router(auth.router, prefix=api_prefix)
app.include_router(profiles.router, prefix=api_prefix)
app.include_router(courses.router, prefix=api_prefix)
app.include_router(recommendations.router, prefix=api_prefix)
app.include_router(roadmaps.router, prefix=api_prefix)
app.include_router(skill_gaps.router, prefix=api_prefix)
app.include_router(progress.router, prefix=api_prefix)
app.include_router(dashboard.router, prefix=api_prefix)

@app.get("/")
def root():
    return {
        "system": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "status": "online",
        "documentation": "/docs"
    }

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "database_connected": db_manager.is_connected,
        "database_name": settings.DATABASE_NAME
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
