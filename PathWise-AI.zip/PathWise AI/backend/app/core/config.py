import os
from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    PROJECT_NAME: str = "PathWise AI"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api"
    
    # Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", "pathwise-ai-super-secret-jwt-key-development-2026-secure")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    
    # MongoDB
    MONGODB_URL: str = os.getenv("MONGODB_URL", "mongodb://localhost:27017")
    DATABASE_NAME: str = os.getenv("DATABASE_NAME", "pathwise_ai")
    
    # CORS
    BACKEND_CORS_ORIGINS: List[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
    ]

    # Recommendation Weights (Normalized to 1.0)
    WEIGHT_CAREER_GOAL: float = 0.25
    WEIGHT_TARGET_SKILL: float = 0.25
    WEIGHT_INTEREST_ALIGNMENT: float = 0.15
    WEIGHT_SKILL_GAP: float = 0.15
    WEIGHT_PROGRESSION_FIT: float = 0.10
    WEIGHT_DIFFICULTY_STUDY_TIME: float = 0.10

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=True, extra="ignore")

settings = Settings()
