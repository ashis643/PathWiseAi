from fastapi import APIRouter, Depends, HTTPException, status
from app.schemas.roadmap import AcademicRoadmapResponse, RoadmapUpdateRequest
from app.services.profile_service import ProfileService
from app.services.roadmap_service import RoadmapService
from app.api.deps import get_current_user

router = APIRouter(prefix="/roadmaps", tags=["Academic Roadmaps"])

@router.get("", response_model=AcademicRoadmapResponse)
@router.get("/", response_model=AcademicRoadmapResponse)
def get_roadmap(current_user: dict = Depends(get_current_user)):
    """Retrieves the personalized academic roadmap, with topological prerequisite sequencing and study phases."""
    user_id = current_user["id"]
    profile = ProfileService.get_or_create_profile(
        user_id=user_id,
        email=current_user["email"],
        full_name=current_user["full_name"]
    )
    return RoadmapService.get_or_generate_roadmap(user_id, profile)

@router.post("/generate", response_model=AcademicRoadmapResponse)
def regenerate_roadmap(current_user: dict = Depends(get_current_user)):
    """Regenerates the learning roadmap from the updated profile while preserving completed courses."""
    user_id = current_user["id"]
    profile = ProfileService.get_or_create_profile(
        user_id=user_id,
        email=current_user["email"],
        full_name=current_user["full_name"]
    )
    from app.services.course_service import CourseService
    all_courses = CourseService.get_all_active_courses()
    return RoadmapService.generate_roadmap_for_student(user_id, profile, all_courses)

@router.post("/modify", response_model=AcademicRoadmapResponse)
def modify_roadmap_courses(req: RoadmapUpdateRequest, current_user: dict = Depends(get_current_user)):
    """Allows student to add, remove, or reset courses within their roadmap."""
    user_id = current_user["id"]
    profile = ProfileService.get_or_create_profile(
        user_id=user_id,
        email=current_user["email"],
        full_name=current_user["full_name"]
    )
    return RoadmapService.modify_roadmap(
        user_id=user_id,
        action=req.action,
        course_id=req.course_id,
        target_phase=req.target_phase,
        profile=profile
    )
