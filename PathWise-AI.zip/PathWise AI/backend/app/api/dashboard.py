from fastapi import APIRouter, Depends
from typing import Dict, Any
from app.services.profile_service import ProfileService
from app.services.course_service import CourseService
from app.services.recommendation_service import RecommendationService
from app.services.roadmap_service import RoadmapService
from app.services.skill_gap_service import SkillGapService
from app.services.progress_service import ProgressService
from app.api.deps import get_current_user

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/overview")
def get_dashboard_overview(current_user: dict = Depends(get_current_user)) -> Dict[str, Any]:
    """Combines metrics, active courses, recommendations, roadmap phase, and skill gap into a unified dashboard response."""
    user_id = current_user["id"]
    profile = ProfileService.get_or_create_profile(
        user_id=user_id,
        email=current_user["email"],
        full_name=current_user["full_name"]
    )
    all_courses = CourseService.get_all_active_courses()

    # Recommendations
    recs = RecommendationService.calculate_recommendations(profile, all_courses, limit=4)
    
    # Roadmap
    roadmap = RoadmapService.get_or_generate_roadmap(user_id, profile)
    
    # Skill gap
    gaps = SkillGapService.analyze_student_gaps(profile)

    # Progress summary
    prog = ProgressService.get_progress_summary(user_id)

    # Determine current active phase
    current_phase = None
    if roadmap and roadmap.get("phases"):
        for p in roadmap["phases"]:
            has_pending = any(c.get("status") in ["in_progress", "planned"] for c in p.get("courses", []))
            if has_pending:
                current_phase = {
                    "phase_number": p["phase_number"],
                    "title": p["title"],
                    "milestone": p["milestone"],
                    "total_hours": p["total_hours"],
                    "estimated_weeks": p["estimated_duration_weeks"],
                    "courses_count": len(p["courses"]),
                    "completed_count": sum(1 for c in p["courses"] if c.get("status") == "completed")
                }
                break
        if not current_phase and len(roadmap["phases"]) > 0:
            last_p = roadmap["phases"][-1]
            current_phase = {
                "phase_number": last_p["phase_number"],
                "title": last_p["title"],
                "milestone": last_p["milestone"],
                "total_hours": last_p["total_hours"],
                "estimated_weeks": last_p["estimated_duration_weeks"],
                "courses_count": len(last_p["courses"]),
                "completed_count": sum(1 for c in last_p["courses"] if c.get("status") == "completed")
            }

    return {
        "user": {
            "id": user_id,
            "full_name": profile.get("full_name", current_user.get("full_name")),
            "email": current_user["email"],
            "target_career": profile.get("target_career", "AI/ML Engineer"),
            "university": profile.get("university"),
            "current_semester": profile.get("current_semester")
        },
        "profile_completion": profile.get("completion_percentage", 0),
        "is_onboarding_completed": profile.get("is_onboarding_completed", False),
        "progress": prog,
        "current_phase": current_phase,
        "skill_metrics": {
            "career_readiness": gaps["overall_readiness_percentage"],
            "skill_coverage": gaps["skill_coverage_percentage"],
            "missing_high_priority": [s["skill_name"] for s in gaps["skill_gaps"] if s["priority"] == "High" and s["is_missing"]][:4],
            "top_skills_acquired": gaps["existing_skills"][:5]
        },
        "top_recommendations": recs["top_recommendations"],
        "prerequisite_alerts": len(recs["prerequisite_blocked_courses"]),
        "weekly_hours_logged": prog["current_week_hours"],
        "weekly_hours_target": prog["weekly_goal_hours"]
    }
