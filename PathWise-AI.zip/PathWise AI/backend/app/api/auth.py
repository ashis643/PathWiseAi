from fastapi import APIRouter, HTTPException, status, Depends
from datetime import datetime, timezone
from bson import ObjectId
from app.schemas.auth import UserRegister, UserLogin, Token, UserResponse
from app.core.security import get_password_hash, verify_password, create_access_token
from app.database.connection import get_database
from app.services.profile_service import ProfileService
from app.api.deps import get_current_user

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
def register(user_in: UserRegister):
    """Registers a new student account, hashes password securely with bcrypt, and initializes default profile."""
    db = get_database()
    email_clean = user_in.email.strip().lower()
    
    existing = db.users.find_one({"email": email_clean})
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email already exists. Please log in."
        )

    now = datetime.now(timezone.utc)
    hashed_pwd = get_password_hash(user_in.password)
    user_doc = {
        "email": email_clean,
        "hashed_password": hashed_pwd,
        "full_name": user_in.full_name.strip(),
        "role": user_in.role or "student",
        "created_at": now,
        "updated_at": now
    }
    
    result = db.users.insert_one(user_doc)
    user_id = str(result.inserted_id)
    user_doc["id"] = user_id

    # Automatically initialize student profile
    ProfileService.get_or_create_profile(user_id, email_clean, user_in.full_name.strip())

    token = create_access_token(subject=user_id, role=user_doc["role"])
    
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user_id,
            "email": user_doc["email"],
            "full_name": user_doc["full_name"],
            "role": user_doc["role"],
            "created_at": user_doc["created_at"]
        }
    }

@router.post("/login", response_model=Token)
def login(credentials: UserLogin):
    """Authenticates user with email and password, returning signed JWT bearer token."""
    db = get_database()
    email_clean = credentials.email.strip().lower()
    
    user = db.users.find_one({"email": email_clean})
    if not user or not verify_password(credentials.password, user.get("hashed_password", "")):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password combination."
        )

    user_id = str(user["_id"])
    token = create_access_token(subject=user_id, role=user.get("role", "student"))

    # Ensure profile exists
    ProfileService.get_or_create_profile(user_id, email_clean, user.get("full_name", "Student"))

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user_id,
            "email": user["email"],
            "full_name": user.get("full_name", ""),
            "role": user.get("role", "student"),
            "created_at": user.get("created_at")
        }
    }

@router.get("/me", response_model=UserResponse)
def get_me(current_user: dict = Depends(get_current_user)):
    """Returns currently authenticated user account details."""
    return {
        "id": current_user["id"],
        "email": current_user["email"],
        "full_name": current_user["full_name"],
        "role": current_user.get("role", "student"),
        "created_at": current_user.get("created_at")
    }
