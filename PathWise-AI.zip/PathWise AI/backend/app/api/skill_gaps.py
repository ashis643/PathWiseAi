from fastapi import APIRouter, Depends, Query
from typing import Optional, List, Dict, Any
from app.schemas.skill_gap import SkillGapAnalysisResponse
from app.services.profile_service import ProfileService
from app.services.skill_gap_service import SkillGapService
from app.api.deps import get_current_user

router = APIRouter(prefix="/skill-gaps", tags=["Skill Gaps & Career Readiness"])

@router.get("", response_model=SkillGapAnalysisResponse)
@router.get("/", response_model=SkillGapAnalysisResponse)
def get_skill_gap_analysis(
    career_override: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user)
):
    """
    Analyzes student's skill coverage against target career competencies,
    identifying high-priority missing skills and gap-closing courses.
    """
    user_id = current_user["id"]
    profile = ProfileService.get_or_create_profile(
        user_id=user_id,
        email=current_user["email"],
        full_name=current_user["full_name"]
    )
    return SkillGapService.analyze_student_gaps(profile, career_override=career_override)

@router.get("/careers")
def get_career_profiles():
    """Returns transparent career skill definitions for industry benchmarks."""
    return SkillGapService.get_career_profiles()
