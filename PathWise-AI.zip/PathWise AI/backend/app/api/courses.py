from fastapi import APIRouter, HTTPException, status, Depends, Query
from typing import Optional, List
from app.schemas.course import CourseResponse, CourseCreate, CourseUpdate
from app.services.course_service import CourseService
from app.api.deps import get_optional_current_user, get_current_admin

router = APIRouter(prefix="/courses", tags=["Courses"])

@router.get("", response_model=None)
@router.get("/", response_model=None)
def list_courses(
    search: Optional[str] = None,
    category: Optional[str] = None,
    difficulty: Optional[str] = None,
    skills: Optional[List[str]] = Query(None),
    max_duration: Optional[int] = None,
    sort_by: Optional[str] = "relevance",
    page: int = Query(1, ge=1),
    page_size: int = Query(12, ge=1, le=100),
    current_user: Optional[dict] = Depends(get_optional_current_user)
):
    """Browses course catalog with keyword search, category, difficulty, duration filtering, and sorting."""
    user_id = current_user["id"] if current_user else None
    return CourseService.get_courses(
        search=search,
        category=category,
        difficulty=difficulty,
        skills=skills,
        max_duration=max_duration,
        sort_by=sort_by,
        page=page,
        page_size=page_size,
        user_id=user_id
    )

@router.get("/{course_id}")
def get_course_detail(course_id: str, current_user: Optional[dict] = Depends(get_optional_current_user)):
    """Retrieves single course details with prerequisite dependencies and skills gained."""
    user_id = current_user["id"] if current_user else None
    course = CourseService.get_course_by_id(course_id, user_id=user_id)
    if not course:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Course not found")
    return course

@router.post("", status_code=status.HTTP_201_CREATED)
@router.post("/", status_code=status.HTTP_201_CREATED)
def create_course(course_in: CourseCreate, admin_user: dict = Depends(get_current_admin)):
    """Admin-only endpoint to add a new course to the catalog."""
    existing = CourseService.get_course_by_id(course_in.course_id)
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Course ID already exists.")
    return CourseService.create_course(course_in.model_dump())

@router.put("/{course_id}")
def update_course(course_id: str, course_in: CourseUpdate, admin_user: dict = Depends(get_current_admin)):
    """Admin-only endpoint to update or activate/deactivate an existing course."""
    updated = CourseService.update_course(course_id, course_in.model_dump(exclude_unset=True))
    if not updated:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Course not found.")
    return updated
