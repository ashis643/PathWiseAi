from fastapi import APIRouter, Depends, HTTPException, status
from app.schemas.progress import CourseStatusUpdate, StudyLogCreate, ProgressSummaryResponse
from app.services.progress_service import ProgressService
from app.api.deps import get_current_user

router = APIRouter(prefix="/progress", tags=["Progress Tracking"])

@router.get("/summary", response_model=ProgressSummaryResponse)
def get_progress_summary(current_user: dict = Depends(get_current_user)):
    """Retrieves current student study hours, completed courses, and roadmap statistics."""
    user_id = current_user["id"]
    return ProgressService.get_progress_summary(user_id)

@router.post("/status")
def update_course_status(req: CourseStatusUpdate, current_user: dict = Depends(get_current_user)):
    """Updates course status (not_started, in_progress, completed) and synchronizes with completed_courses."""
    user_id = current_user["id"]
    return ProgressService.update_course_status(
        user_id=user_id,
        course_id=req.course_id,
        status=req.status,
        hours_spent=req.hours_spent,
        notes=req.notes
    )

@router.post("/log-hours")
def log_study_hours(req: StudyLogCreate, current_user: dict = Depends(get_current_user)):
    """Records a study session duration and notes for a specific course."""
    user_id = current_user["id"]
    return ProgressService.log_study_hours(
        user_id=user_id,
        course_id=req.course_id,
        hours=req.hours,
        notes=req.notes or "",
        study_date=req.study_date
    )
