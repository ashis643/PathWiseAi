from fastapi import APIRouter, HTTPException, status, Depends
from app.schemas.profile import StudentProfileResponse, StudentProfileUpdate
from app.services.profile_service import ProfileService
from app.api.deps import get_current_user

router = APIRouter(prefix="/profiles", tags=["Student Profiles"])

@router.get("/me", response_model=StudentProfileResponse)
def get_my_profile(current_user: dict = Depends(get_current_user)):
    """Retrieves authenticated student profile and completion percentage."""
    user_id = current_user["id"]
    profile = ProfileService.get_or_create_profile(
        user_id=user_id,
        email=current_user["email"],
        full_name=current_user["full_name"]
    )
    return profile

@router.put("/me", response_model=StudentProfileResponse)
def update_my_profile(profile_in: StudentProfileUpdate, current_user: dict = Depends(get_current_user)):
    """Updates student profile fields, technical skills, career target, and study availability."""
    user_id = current_user["id"]
    update_data = profile_in.model_dump(exclude_unset=True)
    
    updated = ProfileService.update_profile(user_id, update_data)
    return updated
