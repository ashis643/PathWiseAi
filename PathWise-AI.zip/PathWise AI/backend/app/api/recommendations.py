from fastapi import APIRouter, Depends, Query
from app.schemas.recommendation import RecommendationResponse
from app.services.profile_service import ProfileService
from app.services.course_service import CourseService
from app.services.recommendation_service import RecommendationService
from app.api.deps import get_current_user

router = APIRouter(prefix="/recommendations", tags=["Recommendations"])

@router.get("", response_model=RecommendationResponse)
@router.get("/", response_model=RecommendationResponse)
def get_recommendations(
    limit: int = Query(10, ge=1, le=50),
    current_user: dict = Depends(get_current_user)
):
    """
    Computes explainable, content-based course recommendations tailored to
    the student's target career, skill gaps, interests, prerequisites, and study schedule.
    """
    user_id = current_user["id"]
    profile = ProfileService.get_or_create_profile(
        user_id=user_id,
        email=current_user["email"],
        full_name=current_user["full_name"]
    )
    all_courses = CourseService.get_all_active_courses()
    
    recommendation_result = RecommendationService.calculate_recommendations(
        profile=profile,
        courses=all_courses,
        limit=limit
    )
    return recommendation_result
