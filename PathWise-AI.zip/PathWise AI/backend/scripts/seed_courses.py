import os
import sys
from datetime import datetime, timezone

# Add backend directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.database.connection import db_manager

SEED_COURSES = [
    # 1. Programming Fundamentals
    {
        "course_id": "CS101",
        "title": "Introduction to Computer Science & Python",
        "short_description": "Master algorithmic problem solving, computational thinking, and core Python programming fundamentals.",
        "category": "Programming Fundamentals",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["Python", "Algorithmic Thinking", "Debugging", "Modular Programming"],
        "career_relevance": ["Software Engineer", "AI/ML Engineer", "Data Analyst", "Cloud/DevOps Engineer", "Cybersecurity Analyst"],
        "learning_objectives": ["Write clean Python code", "Understand variables, control flow, functions", "Handle files and basic exceptions"],
        "course_type": "Foundational",
        "learning_resource_url": "https://docs.python.org/3/tutorial/",
        "is_active": True
    },
    {
        "course_id": "CS102",
        "title": "Object-Oriented Programming & Software Design",
        "short_description": "Learn encapsulation, inheritance, polymorphism, design patterns, and clean code principles in Python and Java.",
        "category": "Programming Fundamentals",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 40,
        "prerequisite_course_ids": ["CS101"],
        "required_skills": ["Python"],
        "skills_gained": ["Object-Oriented Design", "Design Patterns", "Unit Testing", "UML"],
        "career_relevance": ["Software Engineer", "Cloud/DevOps Engineer", "AI/ML Engineer"],
        "learning_objectives": ["Implement SOLID principles", "Structure complex codebases", "Write robust object architectures"],
        "course_type": "Core",
        "learning_resource_url": "https://refactoring.guru/design-patterns",
        "is_active": True
    },
    {
        "course_id": "CS103",
        "title": "Systems Programming in C and Memory Management",
        "short_description": "Deep dive into low-level computer architecture, pointers, dynamic memory allocation, and POSIX threads.",
        "category": "Programming Fundamentals",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["CS101"],
        "required_skills": ["Algorithmic Thinking"],
        "skills_gained": ["C Programming", "Pointers & Memory", "Concurrency", "Linux System Calls"],
        "career_relevance": ["Software Engineer", "Cybersecurity Analyst", "Cloud/DevOps Engineer"],
        "learning_objectives": ["Manage raw memory safely", "Debug segfaults with GDB/Valgrind", "Understand machine execution models"],
        "course_type": "Core",
        "learning_resource_url": "https://en.cppreference.com/w/c",
        "is_active": True
    },

    # 2. Data Structures and Algorithms
    {
        "course_id": "DSA201",
        "title": "Data Structures Essentials",
        "short_description": "Foundational structures: arrays, linked lists, stacks, queues, hash maps, and binary search trees with complexity analysis.",
        "category": "Data Structures and Algorithms",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["CS101"],
        "required_skills": ["Python", "Algorithmic Thinking"],
        "skills_gained": ["Data Structures", "Big-O Analysis", "Hash Tables", "Binary Trees"],
        "career_relevance": ["Software Engineer", "AI/ML Engineer", "Data Analyst"],
        "learning_objectives": ["Analyze time and space complexity", "Choose optimal data structures", "Implement recursion and trees"],
        "course_type": "Core",
        "learning_resource_url": "https://opendsa-server.cs.vt.edu/",
        "is_active": True
    },
    {
        "course_id": "DSA202",
        "title": "Advanced Algorithms & Optimization",
        "short_description": "Graph algorithms (Dijkstra, A*), dynamic programming, divide-and-conquer, greedy algorithms, and NP-completeness.",
        "category": "Data Structures and Algorithms",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 50,
        "prerequisite_course_ids": ["DSA201"],
        "required_skills": ["Data Structures", "Big-O Analysis"],
        "skills_gained": ["Graph Algorithms", "Dynamic Programming", "Greedy Techniques", "Combinatorial Optimization"],
        "career_relevance": ["Software Engineer", "AI/ML Engineer"],
        "learning_objectives": ["Formulate dynamic programming state transitions", "Traverse complex graphs", "Prove algorithmic correctness"],
        "course_type": "Specialization",
        "learning_resource_url": "https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/",
        "is_active": True
    },

    # 3. Database Management
    {
        "course_id": "DB201",
        "title": "Relational Databases & SQL Mastery",
        "short_description": "Relational schema design, ACID properties, normalization (1NF-BCNF), complex joins, indexing, and PostgreSQL performance.",
        "category": "Database Management",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 30,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["SQL", "Relational Modeling", "PostgreSQL", "Database Indexing"],
        "career_relevance": ["Data Analyst", "Software Engineer", "AI/ML Engineer", "Cloud/DevOps Engineer"],
        "learning_objectives": ["Write advanced multi-table queries", "Design normalized database schemas", "Optimize query execution plans"],
        "course_type": "Core",
        "learning_resource_url": "https://www.postgresql.org/docs/current/tutorial.html",
        "is_active": True
    },
    {
        "course_id": "DB202",
        "title": "NoSQL Systems, MongoDB & Distributed Data",
        "short_description": "Document-oriented databases, MongoDB aggregation pipelines, Redis caching, Cassandra distributed storage, and CAP theorem.",
        "category": "Database Management",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": ["DB201"],
        "required_skills": ["SQL"],
        "skills_gained": ["MongoDB", "NoSQL", "Distributed Caching", "Data Partitioning"],
        "career_relevance": ["Software Engineer", "Cloud/DevOps Engineer", "Data Analyst"],
        "learning_objectives": ["Design non-relational document schemas", "Build real-time aggregation queries", "Apply distributed caching"],
        "course_type": "Specialization",
        "learning_resource_url": "https://www.mongodb.com/docs/manual/",
        "is_active": True
    },

    # 4. Mathematics for Computing
    {
        "course_id": "MATH101",
        "title": "Discrete Mathematics & Logic",
        "short_description": "Propositional and predicate logic, set theory, combinatorics, proof techniques, graph theory, and Boolean algebra.",
        "category": "Mathematics for Computing",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["Mathematical Proofs", "Discrete Structures", "Logic Formulation", "Combinatorics"],
        "career_relevance": ["Software Engineer", "AI/ML Engineer", "Cybersecurity Analyst"],
        "learning_objectives": ["Write inductive and deductive proofs", "Formulate formal boolean logic", "Model discrete computational problems"],
        "course_type": "Foundational",
        "learning_resource_url": "https://ocw.mit.edu/courses/6-042j-mathematics-for-computer-science-spring-2015/",
        "is_active": True
    },
    {
        "course_id": "MATH201",
        "title": "Linear Algebra for Machine Learning",
        "short_description": "Vector spaces, matrix decomposition, eigenvalues, eigenvectors, SVD, and principal component analysis concepts.",
        "category": "Mathematics for Computing",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 40,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["Linear Algebra", "Matrix Computations", "Eigenvalues & SVD", "Vector Calculus"],
        "career_relevance": ["AI/ML Engineer", "Data Analyst"],
        "learning_objectives": ["Perform matrix transformations", "Compute singular value decompositions", "Understand geometric projections for ML"],
        "course_type": "Foundational",
        "learning_resource_url": "https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/",
        "is_active": True
    },
    {
        "course_id": "MATH202",
        "title": "Probability & Applied Statistics",
        "short_description": "Random variables, probability distributions, Bayes theorem, hypothesis testing, confidence intervals, and regression analysis.",
        "category": "Mathematics for Computing",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 40,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["Probability Theory", "Inferential Statistics", "Bayesian Reasoning", "Hypothesis Testing"],
        "career_relevance": ["Data Analyst", "AI/ML Engineer", "Cybersecurity Analyst"],
        "learning_objectives": ["Calculate probability distributions", "Conduct statistical hypothesis tests", "Evaluate statistical significance"],
        "course_type": "Foundational",
        "learning_resource_url": "https://www.khanacademy.org/math/statistics-probability",
        "is_active": True
    },

    # 5. Data Science and Analytics
    {
        "course_id": "DS201",
        "title": "Data Analysis with Python, Pandas & NumPy",
        "short_description": "Data wrangling, cleaning missing values, grouping, aggregation, exploratory data analysis, and numerical vectorization.",
        "category": "Data Science and Analytics",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": ["CS101"],
        "required_skills": ["Python"],
        "skills_gained": ["Pandas", "NumPy", "Data Wrangling", "Exploratory Data Analysis"],
        "career_relevance": ["Data Analyst", "AI/ML Engineer"],
        "learning_objectives": ["Clean messy real-world datasets", "Filter and transform tabular data with Pandas", "Perform vectorized computation with NumPy"],
        "course_type": "Core",
        "learning_resource_url": "https://pandas.pydata.org/docs/user_guide/index.html",
        "is_active": True
    },
    {
        "course_id": "DS202",
        "title": "Data Visualization & Business Intelligence",
        "short_description": "Visual storytelling with Matplotlib, Seaborn, interactive dashboards with Plotly, Tableau concepts, and executive presentation.",
        "category": "Data Science and Analytics",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 30,
        "prerequisite_course_ids": ["DS201"],
        "required_skills": ["Pandas"],
        "skills_gained": ["Data Visualization", "Seaborn", "Plotly", "Executive Dashboards"],
        "career_relevance": ["Data Analyst", "Software Engineer"],
        "learning_objectives": ["Create publication-ready visual charts", "Tell compelling stories with data", "Design interactive BI dashboards"],
        "course_type": "Core",
        "learning_resource_url": "https://seaborn.pydata.org/tutorial.html",
        "is_active": True
    },
    {
        "course_id": "DS301",
        "title": "Big Data Engineering with Apache Spark & Kafka",
        "short_description": "Distributed data processing at scale, resilient distributed datasets (RDDs), Spark DataFrames, stream ingestion with Kafka.",
        "category": "Data Science and Analytics",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["DS201", "DB201"],
        "required_skills": ["Pandas", "SQL"],
        "skills_gained": ["Apache Spark", "PySpark", "Stream Processing", "ETL Pipelines"],
        "career_relevance": ["Data Analyst", "Cloud/DevOps Engineer", "AI/ML Engineer"],
        "learning_objectives": ["Build distributed ETL data pipelines", "Process terabyte-scale data with PySpark", "Handle real-time event streams"],
        "course_type": "Specialization",
        "learning_resource_url": "https://spark.apache.org/docs/latest/",
        "is_active": True
    },

    # 6. Machine Learning
    {
        "course_id": "ML301",
        "title": "Supervised Machine Learning & Scikit-Learn",
        "short_description": "Regression, classification, decision trees, random forests, SVM, model validation, cross-validation, and bias-variance tradeoff.",
        "category": "Machine Learning",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["CS101", "MATH201", "MATH202"],
        "required_skills": ["Python", "Linear Algebra", "Probability Theory"],
        "skills_gained": ["Scikit-Learn", "Supervised Learning", "Feature Engineering", "Model Evaluation"],
        "career_relevance": ["AI/ML Engineer", "Data Analyst"],
        "learning_objectives": ["Train and tune predictive models", "Engineer high-signal features", "Evaluate precision, recall, and ROC curves"],
        "course_type": "Core",
        "learning_resource_url": "https://scikit-learn.org/stable/user_guide.html",
        "is_active": True
    },
    {
        "course_id": "ML302",
        "title": "Unsupervised Learning & Clustering",
        "short_description": "K-means, hierarchical clustering, DBSCAN, dimensionality reduction with PCA and t-SNE, anomaly detection algorithms.",
        "category": "Machine Learning",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": ["ML301"],
        "required_skills": ["Scikit-Learn", "Supervised Learning"],
        "skills_gained": ["Clustering", "PCA", "Anomaly Detection", "Dimensionality Reduction"],
        "career_relevance": ["AI/ML Engineer", "Data Analyst", "Cybersecurity Analyst"],
        "learning_objectives": ["Discover latent clusters in unlabelled data", "Reduce high-dimensional feature spaces", "Detect novel outliers and anomalies"],
        "course_type": "Specialization",
        "learning_resource_url": "https://scikit-learn.org/stable/modules/clustering.html",
        "is_active": True
    },
    {
        "course_id": "ML401",
        "title": "Deep Learning & Neural Networks with PyTorch",
        "short_description": "Perceptrons, backpropagation, gradient descent variants, convolutional networks (CNNs), recurrent networks (RNNs/LSTMs), and PyTorch tensors.",
        "category": "Machine Learning",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 55,
        "prerequisite_course_ids": ["ML301"],
        "required_skills": ["Scikit-Learn", "Linear Algebra"],
        "skills_gained": ["PyTorch", "Deep Learning", "CNNs", "Neural Architectures"],
        "career_relevance": ["AI/ML Engineer"],
        "learning_objectives": ["Build deep neural networks in PyTorch", "Train convolutional networks for image classification", "Prevent overfitting with regularizers"],
        "course_type": "Specialization",
        "learning_resource_url": "https://pytorch.org/tutorials/",
        "is_active": True
    },
    {
        "course_id": "ML402",
        "title": "MLOps: Machine Learning Operations & Deployment",
        "short_description": "Model serving with FastAPI/Docker, experiment tracking with MLflow, CI/CD pipelines for models, data drift monitoring in production.",
        "category": "Machine Learning",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 40,
        "prerequisite_course_ids": ["ML301", "DEV201"],
        "required_skills": ["Scikit-Learn", "Docker"],
        "skills_gained": ["MLOps", "Model Deployment", "MLflow", "Model Monitoring"],
        "career_relevance": ["AI/ML Engineer", "Cloud/DevOps Engineer"],
        "learning_objectives": ["Serve ML models with low latency APIs", "Automate training pipelines and versioning", "Monitor model accuracy and feature drift"],
        "course_type": "Specialization",
        "learning_resource_url": "https://ml-ops.org/",
        "is_active": True
    },

    # 7. Artificial Intelligence
    {
        "course_id": "AI301",
        "title": "Foundations of Artificial Intelligence",
        "short_description": "State-space search, heuristic search (A*), minimax with alpha-beta pruning, constraint satisfaction, and knowledge representation.",
        "category": "Artificial Intelligence",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 40,
        "prerequisite_course_ids": ["CS101", "DSA201"],
        "required_skills": ["Python", "Data Structures"],
        "skills_gained": ["Search Algorithms", "Game Playing AI", "Constraint Satisfaction", "Knowledge Representation"],
        "career_relevance": ["AI/ML Engineer", "Software Engineer"],
        "learning_objectives": ["Implement heuristic search agents", "Develop adversarial game-playing algorithms", "Solve constraint satisfaction problems"],
        "course_type": "Core",
        "learning_resource_url": "https://aima.cs.berkeley.edu/",
        "is_active": True
    },
    {
        "course_id": "AI401",
        "title": "Natural Language Processing & LLM Architecture",
        "short_description": "Tokenization, word embeddings (Word2Vec), Transformer attention mechanism, BERT, GPT architectures, and fine-tuning with HuggingFace.",
        "category": "Artificial Intelligence",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 50,
        "prerequisite_course_ids": ["ML401"],
        "required_skills": ["PyTorch", "Deep Learning"],
        "skills_gained": ["NLP", "Transformers", "Large Language Models", "Hugging Face"],
        "career_relevance": ["AI/ML Engineer"],
        "learning_objectives": ["Implement multi-head self-attention", "Fine-tune Transformer models for text tasks", "Build semantic search and RAG pipelines"],
        "course_type": "Specialization",
        "learning_resource_url": "https://huggingface.co/learn/nlp-course/chapter1/1",
        "is_active": True
    },
    {
        "course_id": "AI402",
        "title": "Computer Vision & Visual Intelligence",
        "short_description": "Image filtering, edge detection, OpenCV, object detection (YOLO), semantic segmentation, and generative models.",
        "category": "Artificial Intelligence",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["ML401"],
        "required_skills": ["PyTorch", "Deep Learning"],
        "skills_gained": ["Computer Vision", "OpenCV", "Object Detection", "Image Segmentation"],
        "career_relevance": ["AI/ML Engineer"],
        "learning_objectives": ["Process video streams in real-time with OpenCV", "Train state-of-the-art object detectors", "Perform visual semantic segmentation"],
        "course_type": "Specialization",
        "learning_resource_url": "https://opencv.org/get-started/",
        "is_active": True
    },

    # 8. Web Development
    {
        "course_id": "WEB101",
        "title": "Modern Frontend Development with HTML, CSS & JavaScript",
        "short_description": "Semantic HTML5, CSS Flexbox and Grid, modern ES6+ JavaScript, DOM manipulation, responsive design, and accessible interfaces.",
        "category": "Web Development",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["HTML5", "CSS3", "JavaScript", "Responsive Design"],
        "career_relevance": ["Software Engineer"],
        "learning_objectives": ["Structure accessible websites", "Style modern layouts with CSS Flex/Grid", "Manipulate the browser DOM dynamically"],
        "course_type": "Core",
        "learning_resource_url": "https://developer.mozilla.org/en-US/docs/Learn",
        "is_active": True
    },
    {
        "course_id": "WEB201",
        "title": "Modern React.js & TypeScript Application Architecture",
        "short_description": "React functional components, hooks (useState, useEffect, useMemo), state management, React Router, TypeScript type safety, and Tailwind CSS.",
        "category": "Web Development",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["WEB101"],
        "required_skills": ["JavaScript", "HTML5"],
        "skills_gained": ["React", "TypeScript", "Tailwind CSS", "SPA Architecture"],
        "career_relevance": ["Software Engineer"],
        "learning_objectives": ["Build production-ready single page applications", "Ensure strict type safety with TypeScript", "Manage complex application states"],
        "course_type": "Core",
        "learning_resource_url": "https://react.dev/learn",
        "is_active": True
    },
    {
        "course_id": "WEB202",
        "title": "Backend Engineering with FastAPI & Node.js",
        "short_description": "RESTful API design, authentication with JWT, asynchronous I/O, middleware, request validation with Pydantic, and database integration.",
        "category": "Web Development",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 40,
        "prerequisite_course_ids": ["CS101", "DB201"],
        "required_skills": ["Python", "SQL"],
        "skills_gained": ["FastAPI", "REST APIs", "JWT Authentication", "Async Programming"],
        "career_relevance": ["Software Engineer", "Cloud/DevOps Engineer", "AI/ML Engineer"],
        "learning_objectives": ["Design secure and scalable RESTful endpoints", "Implement token-based authentication", "Connect backend APIs to databases"],
        "course_type": "Core",
        "learning_resource_url": "https://fastapi.tiangolo.com/tutorial/",
        "is_active": True
    },
    {
        "course_id": "WEB301",
        "title": "Full-Stack Microservices Architecture",
        "short_description": "Service decomposition, API gateways, message queues (RabbitMQ), gRPC communication, service discovery, and end-to-end integration.",
        "category": "Web Development",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 50,
        "prerequisite_course_ids": ["WEB201", "WEB202"],
        "required_skills": ["React", "FastAPI"],
        "skills_gained": ["Microservices", "API Gateways", "Event-Driven Design", "gRPC"],
        "career_relevance": ["Software Engineer", "Cloud/DevOps Engineer"],
        "learning_objectives": ["Architect scalable distributed web applications", "Implement asynchronous inter-service messaging", "Handle distributed transactions safely"],
        "course_type": "Specialization",
        "learning_resource_url": "https://microservices.io/",
        "is_active": True
    },

    # 9. Cloud Computing
    {
        "course_id": "CLOUD101",
        "title": "Cloud Computing Fundamentals & AWS Core Services",
        "short_description": "Cloud deployment models (IaaS, PaaS, SaaS), AWS EC2 compute, S3 object storage, VPC networking, IAM security, and pricing models.",
        "category": "Cloud Computing",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 30,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["Cloud Computing", "AWS", "IAM Security", "Virtual Private Clouds"],
        "career_relevance": ["Cloud/DevOps Engineer", "Software Engineer", "Cybersecurity Analyst"],
        "learning_objectives": ["Deploy virtual machines in the cloud", "Configure IAM policies and secure buckets", "Design basic highly available cloud topologies"],
        "course_type": "Core",
        "learning_resource_url": "https://aws.amazon.com/getting-started/",
        "is_active": True
    },
    {
        "course_id": "CLOUD201",
        "title": "Serverless Computing & Cloud Native Architectures",
        "short_description": "AWS Lambda, API Gateway, DynamoDB, event-driven architectures with EventBridge, auto-scaling, and micro-billing optimization.",
        "category": "Cloud Computing",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": ["CLOUD101", "CS101"],
        "required_skills": ["AWS", "Python"],
        "skills_gained": ["Serverless", "AWS Lambda", "Event-Driven Architecture", "DynamoDB"],
        "career_relevance": ["Cloud/DevOps Engineer", "Software Engineer"],
        "learning_objectives": ["Build cost-effective serverless backends", "Handle event streams without server management", "Design auto-scaling architectures"],
        "course_type": "Specialization",
        "learning_resource_url": "https://docs.aws.amazon.com/lambda/latest/dg/welcome.html",
        "is_active": True
    },
    {
        "course_id": "CLOUD301",
        "title": "Multi-Cloud Strategy & Cloud Security Architecture",
        "short_description": "Cross-cloud governance (AWS, Azure, GCP), hybrid cloud networking, zero-trust cloud security, encryption at rest/transit, and compliance.",
        "category": "Cloud Computing",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["CLOUD101", "SEC201"],
        "required_skills": ["AWS", "Network Security"],
        "skills_gained": ["Multi-Cloud", "Cloud Security", "Zero Trust", "Cloud Compliance"],
        "career_relevance": ["Cloud/DevOps Engineer", "Cybersecurity Analyst"],
        "learning_objectives": ["Implement defense-in-depth across cloud environments", "Configure cross-cloud interconnects and VPNs", "Enforce continuous compliance audits"],
        "course_type": "Specialization",
        "learning_resource_url": "https://cloud.google.com/learn/what-is-multi-cloud",
        "is_active": True
    },

    # 10. DevOps
    {
        "course_id": "DEV101",
        "title": "Linux Administration, Bash Scripting & Git Workflow",
        "short_description": "Command line mastery, file permissions, process management, shell automation scripts, Git branching strategies, and SSH keys.",
        "category": "DevOps",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 30,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["Linux", "Bash Scripting", "Git", "Command Line"],
        "career_relevance": ["Cloud/DevOps Engineer", "Software Engineer", "Cybersecurity Analyst", "AI/ML Engineer"],
        "learning_objectives": ["Automate repetitive server tasks with Bash", "Manage Git repositories and pull request workflows", "Administer users and system daemons"],
        "course_type": "Foundational",
        "learning_resource_url": "https://linuxjourney.com/",
        "is_active": True
    },
    {
        "course_id": "DEV201",
        "title": "Containerization with Docker & Compose",
        "short_description": "Writing Dockerfiles, multi-stage builds, container isolation, volume mounts, bridge networking, and local multi-service orchestration.",
        "category": "DevOps",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": ["DEV101"],
        "required_skills": ["Linux", "Command Line"],
        "skills_gained": ["Docker", "Containers", "Docker Compose", "Multi-Stage Builds"],
        "career_relevance": ["Cloud/DevOps Engineer", "Software Engineer", "AI/ML Engineer"],
        "learning_objectives": ["Package applications into lightweight images", "Isolate microservice dependencies", "Orchestrate multi-container environments locally"],
        "course_type": "Core",
        "learning_resource_url": "https://docs.docker.com/get-started/",
        "is_active": True
    },
    {
        "course_id": "DEV202",
        "title": "CI/CD Pipelines with GitHub Actions & Automated Testing",
        "short_description": "Continuous integration, automated linting and unit test execution, secret management, Docker image publishing, and deployment workflows.",
        "category": "DevOps",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 30,
        "prerequisite_course_ids": ["DEV101", "DEV201"],
        "required_skills": ["Git", "Docker"],
        "skills_gained": ["CI/CD", "GitHub Actions", "Automated Testing", "Artifact Publishing"],
        "career_relevance": ["Cloud/DevOps Engineer", "Software Engineer"],
        "learning_objectives": ["Automate build and test pipelines on git push", "Prevent bad code merges with branch protection", "Deploy container images automatically"],
        "course_type": "Core",
        "learning_resource_url": "https://docs.github.com/en/actions",
        "is_active": True
    },
    {
        "course_id": "DEV301",
        "title": "Kubernetes Container Orchestration at Scale",
        "short_description": "Pods, Deployments, Services, Ingress controllers, ConfigMaps, persistent storage, Helm charts, and cluster monitoring with Prometheus.",
        "category": "DevOps",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 50,
        "prerequisite_course_ids": ["DEV201", "CLOUD101"],
        "required_skills": ["Docker", "Cloud Computing"],
        "skills_gained": ["Kubernetes", "Container Orchestration", "Helm", "Cluster Monitoring"],
        "career_relevance": ["Cloud/DevOps Engineer", "Software Engineer"],
        "learning_objectives": ["Deploy resilient workloads across Kubernetes nodes", "Manage zero-downtime rolling updates", "Configure declarative ingress and auto-scaling"],
        "course_type": "Specialization",
        "learning_resource_url": "https://kubernetes.io/docs/tutorials/",
        "is_active": True
    },
    {
        "course_id": "DEV302",
        "title": "Infrastructure as Code with Terraform & Ansible",
        "short_description": "Declarative cloud provisioning with Terraform, state management, remote backends, configuration management, and server hardening with Ansible.",
        "category": "DevOps",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 40,
        "prerequisite_course_ids": ["CLOUD101", "DEV101"],
        "required_skills": ["AWS", "Linux"],
        "skills_gained": ["Terraform", "Infrastructure as Code", "Ansible", "Cloud Automation"],
        "career_relevance": ["Cloud/DevOps Engineer"],
        "learning_objectives": ["Write modular Terraform code for cloud stacks", "Manage collaborative infrastructure state files", "Configure servers automatically with Ansible"],
        "course_type": "Specialization",
        "learning_resource_url": "https://developer.hashicorp.com/terraform/tutorials",
        "is_active": True
    },

    # 11. Cybersecurity
    {
        "course_id": "SEC101",
        "title": "Cybersecurity Foundations & Information Security",
        "short_description": "CIA triad (Confidentiality, Integrity, Availability), threat actors, attack vectors, basic cryptography, hashing, and security policies.",
        "category": "Cybersecurity",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 30,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["Security Principles", "Cryptography Basics", "Threat Modeling", "Risk Management"],
        "career_relevance": ["Cybersecurity Analyst", "Software Engineer", "Cloud/DevOps Engineer"],
        "learning_objectives": ["Understand core information security principles", "Analyze potential attack surfaces", "Apply basic cryptographic hashing and encryption"],
        "course_type": "Foundational",
        "learning_resource_url": "https://www.cisa.gov/cybersecurity-basics",
        "is_active": True
    },
    {
        "course_id": "SEC201",
        "title": "Network Security & Packet Analysis",
        "short_description": "TCP/IP protocol vulnerabilities, Wireshark packet analysis, firewalls, IDS/IPS configuration, VPNs, and man-in-the-middle attacks.",
        "category": "Cybersecurity",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 40,
        "prerequisite_course_ids": ["SEC101"],
        "required_skills": ["Security Principles"],
        "skills_gained": ["Network Security", "Wireshark", "Firewalls", "Protocol Analysis"],
        "career_relevance": ["Cybersecurity Analyst", "Cloud/DevOps Engineer"],
        "learning_objectives": ["Inspect and analyze raw network packets with Wireshark", "Configure firewall and intrusion prevention rules", "Identify rogue network traffic and port scans"],
        "course_type": "Core",
        "learning_resource_url": "https://www.wireshark.org/docs/",
        "is_active": True
    },
    {
        "course_id": "SEC202",
        "title": "Web Application Security & OWASP Top 10",
        "short_description": "SQL injection, Cross-Site Scripting (XSS), CSRF, insecure deserialization, broken authentication, and secure coding defenses.",
        "category": "Cybersecurity",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": ["WEB101", "SEC101"],
        "required_skills": ["HTML5", "Security Principles"],
        "skills_gained": ["Application Security", "OWASP Top 10", "Penetration Testing Basics", "Secure Coding"],
        "career_relevance": ["Cybersecurity Analyst", "Software Engineer"],
        "learning_objectives": ["Exploit and remediate OWASP Top 10 vulnerabilities", "Implement defensive sanitization and parameterized queries", "Perform security code audits"],
        "course_type": "Core",
        "learning_resource_url": "https://owasp.org/www-project-top-ten/",
        "is_active": True
    },
    {
        "course_id": "SEC301",
        "title": "Ethical Hacking & Penetration Testing",
        "short_description": "Reconnaissance with Nmap, vulnerability exploitation with Metasploit, privilege escalation, reporting, and responsible disclosure.",
        "category": "Cybersecurity",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 50,
        "prerequisite_course_ids": ["SEC201", "DEV101"],
        "required_skills": ["Network Security", "Linux"],
        "skills_gained": ["Penetration Testing", "Metasploit", "Nmap", "Privilege Escalation"],
        "career_relevance": ["Cybersecurity Analyst"],
        "learning_objectives": ["Conduct structured ethical penetration tests", "Identify exploitable software vulnerabilities", "Write professional security assessment findings"],
        "course_type": "Specialization",
        "learning_resource_url": "https://tryhackme.com/",
        "is_active": True
    },
    {
        "course_id": "SEC302",
        "title": "Security Operations (SOC) & Incident Response",
        "short_description": "SIEM log analysis (Splunk/ELK), incident response lifecycle (NIST), digital forensics fundamentals, and malware triage.",
        "category": "Cybersecurity",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["SEC201"],
        "required_skills": ["Network Security"],
        "skills_gained": ["SIEM", "Incident Response", "Digital Forensics", "Log Analysis"],
        "career_relevance": ["Cybersecurity Analyst"],
        "learning_objectives": ["Analyze security events in SIEM platforms", "Execute containment and eradication strategies", "Preserve digital evidence for forensic analysis"],
        "course_type": "Specialization",
        "learning_resource_url": "https://www.sans.org/white-papers/incident-response/",
        "is_active": True
    },

    # 12. Communication and Professional Skills
    {
        "course_id": "COMM101",
        "title": "Technical Writing & Engineering Documentation",
        "short_description": "Creating clear API documentation, READMEs, technical specifications, architecture decision records (ADRs), and markdown mastery.",
        "category": "Communication and Professional Skills",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 20,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["Technical Writing", "Documentation", "API Documentation", "Communication"],
        "career_relevance": ["Software Engineer", "AI/ML Engineer", "Data Analyst", "Cloud/DevOps Engineer", "Cybersecurity Analyst"],
        "learning_objectives": ["Write concise technical specifications", "Document software APIs clearly for developers", "Author Architecture Decision Records"],
        "course_type": "Core",
        "learning_resource_url": "https://developers.google.com/tech-writing",
        "is_active": True
    },
    {
        "course_id": "COMM102",
        "title": "Agile Methodologies & Collaborative Project Management",
        "short_description": "Scrum ceremonies (sprints, standups, retrospectives), Kanban boards, user stories, sprint planning, and team collaboration dynamics.",
        "category": "Communication and Professional Skills",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 20,
        "prerequisite_course_ids": [],
        "required_skills": [],
        "skills_gained": ["Agile Methodology", "Scrum", "Teamwork", "Project Management"],
        "career_relevance": ["Software Engineer", "Cloud/DevOps Engineer", "Data Analyst", "AI/ML Engineer", "Cybersecurity Analyst"],
        "learning_objectives": ["Participate effectively in Scrum ceremonies", "Break down business requirements into user stories", "Manage team deliverables on Kanban boards"],
        "course_type": "Core",
        "learning_resource_url": "https://www.scrumguides.org/",
        "is_active": True
    },
    {
        "course_id": "COMM201",
        "title": "Engineering Leadership & Stakeholder Presentation",
        "short_description": "Translating technical metrics to executive business value, presenting data insights, conflict resolution, and technical leadership.",
        "category": "Communication and Professional Skills",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 25,
        "prerequisite_course_ids": ["COMM101"],
        "required_skills": ["Technical Writing"],
        "skills_gained": ["Leadership", "Stakeholder Management", "Executive Presentation", "Negotiation"],
        "career_relevance": ["Software Engineer", "Data Analyst", "Cloud/DevOps Engineer", "AI/ML Engineer", "Cybersecurity Analyst"],
        "learning_objectives": ["Present technical roadmaps to non-technical stakeholders", "Lead engineering discussions and design reviews", "Balance technical debt with business priorities"],
        "course_type": "Elective",
        "learning_resource_url": "https://hbr.org/topic/subject/leadership-development",
        "is_active": True
    }
]

def seed_database():
    """Seeds the courses collection with 40+ structured realistic courses."""
    db_manager.connect()
    db = db_manager.db
    courses_col = db.courses
    
    count_before = courses_col.count_documents({})
    print(f"Courses before seeding: {count_before}")
    
    seeded_count = 0
    updated_count = 0
    
    now = datetime.now(timezone.utc)
    for course_data in SEED_COURSES:
        course_id = course_data["course_id"]
        existing = courses_col.find_one({"course_id": course_id})
        
        doc = dict(course_data)
        doc["updated_at"] = now
        
        if existing:
            courses_col.update_one({"course_id": course_id}, {"$set": doc})
            updated_count += 1
        else:
            doc["created_at"] = now
            courses_col.insert_one(doc)
            seeded_count += 1
            
    total_courses = courses_col.count_documents({})
    print(f"Seeding completed successfully! Inserted: {seeded_count}, Updated: {updated_count}, Total in catalog: {total_courses}")
    db_manager.close()

if __name__ == "__main__":
    seed_database()
