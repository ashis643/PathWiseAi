import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.database.connection import db_manager
from app.core.security import get_password_hash
from app.services.profile_service import ProfileService

def seed_users():
    db_manager.connect()
    db = db_manager.db
    now = datetime.now(timezone.utc)

    # 1. Admin User
    admin_email = "admin@pathwise.ai"
    if not db.users.find_one({"email": admin_email}):
        admin_res = db.users.insert_one({
            "email": admin_email,
            "hashed_password": get_password_hash("AdminPass123!"),
            "full_name": "PathWise Administrator",
            "role": "admin",
            "created_at": now,
            "updated_at": now
        })
        print(f"Created admin user: {admin_email} / AdminPass123!")
    else:
        print(f"Admin user {admin_email} already exists.")

    # 2. Demo Student User: Alex Chen
    student_email = "student@pathwise.ai"
    existing_student = db.users.find_one({"email": student_email})
    if not existing_student:
        student_res = db.users.insert_one({
            "email": student_email,
            "hashed_password": get_password_hash("StudentPass123!"),
            "full_name": "Alex Chen",
            "role": "student",
            "created_at": now,
            "updated_at": now
        })
        s_id = str(student_res.inserted_id)
        
        # Populate rich profile for Alex Chen (targeting AI/ML Engineer)
        ProfileService.get_or_create_profile(s_id, student_email, "Alex Chen")
        ProfileService.update_profile(s_id, {
            "university": "State University of Technology",
            "degree_program": "B.S. in Computer Science",
            "department": "Computer Science & Engineering",
            "current_semester": 4,
            "current_cgpa": 3.82,
            "technical_skills": ["Python", "Git", "Algorithmic Thinking", "SQL"],
            "soft_skills": ["Analytical Thinking", "Team Collaboration", "Problem Solving"],
            "areas_of_interest": ["Machine Learning", "Artificial Intelligence", "Deep Learning"],
            "completed_courses": ["CS101", "DB201", "MATH101"],
            "target_career": "AI/ML Engineer",
            "target_skills": ["Scikit-Learn", "PyTorch", "Deep Learning", "Linear Algebra"],
            "preferred_difficulty": "Intermediate",
            "available_study_hours_per_week": 16,
            "preferred_learning_pace": "Balanced",
            "is_onboarding_completed": True
        })
        print(f"Created demo student user: {student_email} / StudentPass123!")
    else:
        print(f"Demo student user {student_email} already exists.")

    db_manager.close()

if __name__ == "__main__":
    seed_users()
