import pytest
from app.services.recommendation_service import RecommendationService

SAMPLE_COURSES = [
    {
        "course_id": "CS101",
        "title": "Intro to Computer Science & Python",
        "category": "Programming Fundamentals",
        "difficulty_level": "Beginner",
        "estimated_duration_hours": 35,
        "prerequisite_course_ids": [],
        "skills_gained": ["Python", "Algorithmic Thinking"],
        "career_relevance": ["Software Engineer", "AI/ML Engineer", "Data Analyst"],
        "course_type": "Foundational"
    },
    {
        "course_id": "DSA201",
        "title": "Data Structures Essentials",
        "category": "Data Structures and Algorithms",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["CS101"],
        "skills_gained": ["Data Structures", "Big-O Analysis"],
        "career_relevance": ["Software Engineer", "AI/ML Engineer"],
        "course_type": "Core"
    },
    {
        "course_id": "ML301",
        "title": "Supervised Machine Learning",
        "category": "Machine Learning",
        "difficulty_level": "Intermediate",
        "estimated_duration_hours": 45,
        "prerequisite_course_ids": ["CS101"],
        "skills_gained": ["Scikit-Learn", "Supervised Learning"],
        "career_relevance": ["AI/ML Engineer", "Data Analyst"],
        "course_type": "Core"
    },
    {
        "course_id": "ML401",
        "title": "Deep Learning & Neural Networks",
        "category": "Machine Learning",
        "difficulty_level": "Advanced",
        "estimated_duration_hours": 55,
        "prerequisite_course_ids": ["ML301"],
        "skills_gained": ["PyTorch", "Deep Learning"],
        "career_relevance": ["AI/ML Engineer"],
        "course_type": "Specialization"
    }
]

def test_completed_course_exclusion():
    profile = {
        "completed_courses": ["CS101"],
        "technical_skills": ["Python"],
        "target_skills": ["Supervised Learning"],
        "areas_of_interest": ["Machine Learning"],
        "target_career": "AI/ML Engineer",
        "preferred_difficulty": "Intermediate",
        "available_study_hours_per_week": 15
    }
    result = RecommendationService.calculate_recommendations(profile, SAMPLE_COURSES)
    recommended_ids = [c["course_id"] for c in result["top_recommendations"]]
    
    # CS101 must NOT be recommended since it is already completed
    assert "CS101" not in recommended_ids
    # ML301 should be recommended as eligible since its prerequisite CS101 is met
    assert "ML301" in recommended_ids

def test_prerequisite_filtering_and_blocked_separation():
    profile = {
        "completed_courses": [],  # Nothing completed yet
        "technical_skills": [],
        "target_skills": ["Deep Learning"],
        "areas_of_interest": ["Machine Learning"],
        "target_career": "AI/ML Engineer",
        "preferred_difficulty": "Intermediate",
        "available_study_hours_per_week": 15
    }
    result = RecommendationService.calculate_recommendations(profile, SAMPLE_COURSES)
    eligible_ids = [c["course_id"] for c in result["top_recommendations"]]
    blocked_ids = [c["course_id"] for c in result["prerequisite_blocked_courses"]]

    # CS101 has no prerequisites, so it is immediately eligible
    assert "CS101" in eligible_ids

    # ML401 requires ML301 which requires CS101 -> must be in blocked list
    assert "ML401" in blocked_ids
    blocked_ml401 = next(c for c in result["prerequisite_blocked_courses"] if c["course_id"] == "ML401")
    assert blocked_ml401["is_prerequisite_met"] is False
    assert "ML301" in blocked_ml401["missing_prerequisites"]

def test_career_and_skill_relevance_scoring():
    aiml_profile = {
        "completed_courses": ["CS101"],
        "technical_skills": ["Python"],
        "target_skills": ["Scikit-Learn", "Supervised Learning"],
        "areas_of_interest": ["Machine Learning"],
        "target_career": "AI/ML Engineer",
        "preferred_difficulty": "Intermediate",
        "available_study_hours_per_week": 20
    }
    result = RecommendationService.calculate_recommendations(aiml_profile, SAMPLE_COURSES)
    top_course = result["top_recommendations"][0]
    
    # ML301 matches target career AI/ML and target skills
    assert top_course["course_id"] == "ML301"
    assert top_course["recommendation_score"] > 70.0
    assert "Directly relevant to your target career as an AI/ML Engineer" in top_course["explanation"]
