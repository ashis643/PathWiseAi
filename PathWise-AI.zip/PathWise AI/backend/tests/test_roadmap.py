import pytest
from app.services.roadmap_service import RoadmapService

def test_topological_sort_valid_dag():
    course_map = {
        "CS101": {"course_id": "CS101", "prerequisite_course_ids": []},
        "DSA201": {"course_id": "DSA201", "prerequisite_course_ids": ["CS101"]},
        "DSA202": {"course_id": "DSA202", "prerequisite_course_ids": ["DSA201"]},
        "ML301": {"course_id": "ML301", "prerequisite_course_ids": ["CS101"]},
    }
    course_ids = ["DSA202", "ML301", "DSA201", "CS101"]
    
    sorted_order, has_cycle = RoadmapService.detect_cycles_and_sort(course_ids, course_map)
    
    assert has_cycle is False
    assert len(sorted_order) == 4
    # CS101 must come before DSA201 and ML301
    assert sorted_order.index("CS101") < sorted_order.index("DSA201")
    assert sorted_order.index("CS101") < sorted_order.index("ML301")
    # DSA201 must come before DSA202
    assert sorted_order.index("DSA201") < sorted_order.index("DSA202")

def test_circular_dependency_detection():
    # Setup a cycle: A -> B -> C -> A
    course_map = {
        "COURSE_A": {"course_id": "COURSE_A", "prerequisite_course_ids": ["COURSE_C"]},
        "COURSE_B": {"course_id": "COURSE_B", "prerequisite_course_ids": ["COURSE_A"]},
        "COURSE_C": {"course_id": "COURSE_C", "prerequisite_course_ids": ["COURSE_B"]},
    }
    course_ids = ["COURSE_A", "COURSE_B", "COURSE_C"]
    
    sorted_order, has_cycle = RoadmapService.detect_cycles_and_sort(course_ids, course_map)
    
    assert has_cycle is True
