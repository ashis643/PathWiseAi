import pytest
from app.services.skill_gap_service import SkillGapService, CAREER_PROFILES

def test_career_profiles_exist():
    profiles = SkillGapService.get_career_profiles()
    assert len(profiles) >= 5
    titles = [p["title"] for p in profiles]
    assert "AI/ML Engineer" in titles
    assert "Data Analyst" in titles
    assert "Software Engineer" in titles
    assert "Cloud/DevOps Engineer" in titles
    assert "Cybersecurity Analyst" in titles

def test_skill_gap_analysis_calculation():
    profile = {
        "target_career": "AI/ML Engineer",
        "technical_skills": ["Python", "Linear Algebra"],
        "completed_courses": []
    }
    result = SkillGapService.analyze_student_gaps(profile)
    
    assert result["career_goal"] == "AI/ML Engineer"
    assert "Python" in result["existing_skills"]
    assert "Linear Algebra" in result["existing_skills"]
    assert "PyTorch" in result["missing_skills"]
    assert result["skill_coverage_percentage"] > 0
    assert result["overall_readiness_percentage"] > 0
    assert len(result["top_gap_closing_courses"]) > 0
