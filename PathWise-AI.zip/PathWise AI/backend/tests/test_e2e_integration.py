import pytest
import httpx

def test_full_student_journey_api():
    client = httpx.Client(base_url="http://127.0.0.1:8000")

    # 1. Login
    login_res = client.post(
        "/api/auth/login",
        json={"email": "student@pathwise.ai", "password": "StudentPass123!"}
    )
    assert login_res.status_code == 200
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # 2. Get Profile
    profile_res = client.get("/api/profiles/me", headers=headers)
    assert profile_res.status_code == 200
    p = profile_res.json()
    assert p["target_career"] == "AI/ML Engineer"

    # 3. Explore Courses with Filters
    courses_res = client.get("/api/courses?category=Machine%20Learning", headers=headers)
    assert courses_res.status_code == 200
    catalog = courses_res.json()
    assert catalog["total_count"] >= 3

    # 4. Get Explainable Recommendations
    recs_res = client.get("/api/recommendations", headers=headers)
    assert recs_res.status_code == 200
    recs = recs_res.json()
    assert len(recs["top_recommendations"]) > 0
    assert recs["top_recommendations"][0]["recommendation_score"] > 50.0

    # 5. Get Academic Roadmap
    roadmap_res = client.get("/api/roadmaps", headers=headers)
    assert roadmap_res.status_code == 200
    roadmap = roadmap_res.json()
    assert len(roadmap["phases"]) >= 2
    assert roadmap["total_hours"] > 0

    # 6. Get Skill Gap Analysis
    gaps_res = client.get("/api/skill-gaps", headers=headers)
    assert gaps_res.status_code == 200
    gaps = gaps_res.json()
    assert gaps["overall_readiness_percentage"] > 0
    assert len(gaps["skill_gaps"]) >= 5

    # 7. Log Study Session
    log_res = client.post(
        "/api/progress/log-hours",
        json={"course_id": "CS101", "hours": 2.0, "notes": "Review session"},
        headers=headers
    )
    assert log_res.status_code == 200

    # 8. Get Dashboard Overview
    dash_res = client.get("/api/dashboard/overview", headers=headers)
    assert dash_res.status_code == 200
    dash = dash_res.json()
    assert dash["user"]["full_name"] == "Alex Chen"
    assert len(dash["top_recommendations"]) > 0
