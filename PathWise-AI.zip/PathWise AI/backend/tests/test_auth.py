import pytest
from app.core.security import get_password_hash, verify_password, create_access_token, decode_access_token

def test_password_hashing_and_verification():
    raw_password = "SuperSecurePassword123!"
    hashed = get_password_hash(raw_password)
    
    assert hashed != raw_password
    assert verify_password(raw_password, hashed) is True
    assert verify_password("WrongPassword123!", hashed) is False

def test_jwt_token_generation_and_decode():
    subject_id = "test_user_67890"
    role = "student"
    token = create_access_token(subject=subject_id, role=role)
    
    payload = decode_access_token(token)
    assert payload["sub"] == subject_id
    assert payload["role"] == role
    assert "exp" in payload
